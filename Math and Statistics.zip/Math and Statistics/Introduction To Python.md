``` python
import numpy as np
import matplotlib.pyplot as plt 
import pandas as pd 
import scipy.stats as stats 
import statsmodels.api as sm 
import statsmodels.formula.api as smf 
import statsmodels.stats.power as smp 
import statsmodels.stats.proportion as smprop
```

``` python
x = np.arange(10) 
print(x) 

[0 1 2 3 4 5 6 7 8 9]
```

> [!important for python]
> ```python
> import numpy as np
>
> np.mean(x)                         # Mean
> np.median(x)                       # Median
>
> np.var(x, ddof=1)                  # Sample variance (note: ddof=1)
> np.std(x, ddof=1)                  # Sample standard deviation
>
> np.percentile(
>     x, p, method='averaged_inverted_cdf'
> )                                  # pth percentile(s), e.g. p = [25, 75]
>
> np.cov(x, y, ddof=1)               # Covariance between x and y
> np.corrcoef(x, y)                  # The correlation
> ```

****
#### **Sample Mean and Median**
``` python
x = np.array([168, 161, 167, 179, 184, 166, 198, 187, 191, 179]) 

np.mean(x) 

np.float64(178.0) 

np.median(x) 

np.float64(179.0)
```
#### **Sample variance and standard deviation**
``` python
np.var(x, ddof=1) 

np.float64(149.11111111111111) 

np.sqrt(np.var(x, ddof=1)) 

np.float64(12.211106056009468) 

np.std(x, ddof=1) 

np.float64(12.211106056009468)
```

#### **Sample percentiles**
``` python
np.percentile(x, [0,25,50,75,100], method=’averaged_inverted_cdf’) 

array([161.000, 167.000, 179.000, 187.000, 198.000])
```

The option **“method=’averaged_inverted_cdf’”** makes sure that the percentiles found by the function is found using the definition given in [[Measures of centrality|Quantiles and percentiles]]

****
# Plotting

#### **A histogram of the heights**
``` python
plt.hist(x) 
plt.show()
```
![[Pasted image 20250604114936.png|600]]

#### **A density histogram or empirical density of the heights**
``` python
plt.hist(x, bins=8, edgecolor=’black’, color=’red’, alpha=0.7, density=True) plt.show()
```
![[Pasted image 20250604115026.png|600]]

#### **Cumulative distribution plot**
``` python
plt.ecdf(x) 
plt.show()
```
![[Pasted image 20250604115120.png|600]]

#### **Box plot**
``` python
plt.boxplot(x) 
plt.show()
```
![[Pasted image 20250604115159.png|600]]

### **Extreme**
![[Pasted image 20250604150242.png]]

****

**With different / manual inputs**
![[Pasted image 20250604115316.png|600]]
``` python
data = pd.DataFrame({ 
	’males’: [152, 171, 173, 173, 178, 179, 180, 180, 182, 182, 182, 185, 185, 185, 185, 185, 186, 187, 190, 190, 192, 192, 197], 

	’females’:[159, 166, 168, 168, 171, 171, 172, 172, 173, 174, 175, 175, 175, 175, 175, 177, 178, np.nan, np.nan, np.nan, np.nan, np.nan, np.nan]
}) 

data.boxplot()
plt.show()
```
![[Pasted image 20250604115409.png|600]]

****

# Inside .csv / excel

![[Pasted image 20250604115459.png|600]]

**The data can now be imported into Python using the Pandas function read_cs**
``` python
studentheights = pd.read_csv(’studentheights.csv’, sep=’;’)
```

#### **Good to use**
``` python
# Have a look at the first 6 rows of the data
studentheights.head()
```
![[Pasted image 20250604115624.png]]

``` python
# Get an overview 
studentheights.info(verbose=True)
```
![[Pasted image 20250604115655.png]]

``` python
# Get a summary of each column/variable in the data 
studentheights.describe(include=’all’)
```
![[Pasted image 20250604115719.png]]

****

# Scatter Plot

``` python
# get mtcars data as a DataFrame 
mtcars = sm.datasets.get_rdataset(’mtcars’).data type(mtcars) 

# To make 2 plots 
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(8,4)) 

# First the default version 
mtcars.plot.scatter(’wt’, ’mpg’, ax=ax1) 

# Then a nicer version 
mtcars.plot.scatter(’wt’, ’mpg’, c=’drat’, colormap=’viridis’, title=’Inverse fuel usage vs. size’, xlabel = ’Car Weight (1000lbs)’, ylabel=’Miles per Galon’, grid=True, ax=ax2)
```
![[Pasted image 20250604115938.png|600]]

****

# Bar plots and Pie charts

``` python
studentheights.groupby(’Gender’).size()
```
![[Pasted image 20250604120137.png]]
``` python
# Barplot and Pie chart 
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(8,4)) studentheights.groupby(’Gender’).size().plot(kind=’bar’, ax=ax1, rot=0) studentheights.groupby(’Gender’).size().plot(kind=’pie’, ax=ax2)
```
![[Pasted image 20250604120158.png|600]]

## Adding a normal distribution
``` python
## Plot the standard normal distribution

xseq = np.linspace(-4, 4, 1000)

yseq = stats.norm.pdf(xseq)

plt.plot(xseq, yseq)

  

## Add the vertical line at the 0.975 quantile

plt.axvline(stats.norm.ppf(0.975), color='orange')

plt.show()
```
