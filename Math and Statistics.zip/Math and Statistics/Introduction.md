**Definition 1.1:** *Sample and Population*

![[Pasted image 20250604110254.png|500]]

**Notations:**
1. µ : Is the **mean** for the whole population
2. x : Is the sample **mean** for the selected sample

![[Pasted image 20250604110412.png|500]]

![[Pasted image 20250604110544.png]]

Meaning the **sample** is the 20 different values of height, the **population** is the height value of all people in Denmark, **observational unit** is a person.

#### **Different wordings:**

**Measures of centrality:**
- Mean
- Median
- Quantiles

**Measures of “spread”:**
- Variance
- Standard deviation
- Coefficient deviation
- Inter Quartile Range *(IQR)*

**Measures of relation (between two variables):**
- Covariance
- Correlation

## Default Equations:

>[!warning]
>
>Mean: $μ = n*p$
>Variation: $σ^2 = μ(1 − p)$
>PMF: $$ P(X=k) = \binom{n}{k} \cdot p^k \cdot (1-p)^{n-k} $$
>
>Mean:
>For a **population**: $μ=\frac{∑xi}{N}$


>[!definition]+ Distribution
>**Definition:**
>A distribution shows the frequency or probability of each possible value or range of values within a dataset

>[!note]
>
>pdf: Probability Density Function
>cdf: Cumulative Distribution Function

>[!info]
>
>|Term|Symbol|Meaning|Units|
|---|---|---|---|
|Sample variance|$σ^2$|Variability of data points|Squared units|
|Sample std. dev.|$\hat{σ}$|Spread of data|Same as data|
|Std. error|$SE = \hat{σ} / \sqrt{n}$|Spread of sample means|Same as data|
