>[!info]
> ![[Pasted image 20250619130857.png]]

****
### Paired t-test as an LM

>[!info]
>The paired t-test can be written as a two-way anova model as:
>![[Pasted image 20250619130957.png]]
>![[Pasted image 20250619131042.png]]

****
### Two-way anova as an LM
![[Pasted image 20250619132756.png|600]]
![[Pasted image 20250619132811.png|600]]
![[Pasted image 20250619132824.png|600]]

>[!definition]+ 9.48 Balanced design
>A design matrix is said to be balanced if the number of observations for any given combination of factors is the same fixed number.

>[!theorem]+ 9.49 Equivalence between Type I and Type III
>
>For two-way ANOVA with balanced design, the Type I and Type III partitioning of variation is equivalent.

