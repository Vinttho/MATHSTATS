## **The F-Distribution**

![[Pasted image 20250619133044.png]]
![[Pasted image 20250619133055.png]]
![[Pasted image 20250619133102.png]]
![[Pasted image 20250619133112.png]]
![[Pasted image 20250619133120.png]]
![[Pasted image 20250619143917.png]] **Critical Value Test in Anova**
****
## **One-way ANOVA**

>[!info]
>
>![[Pasted image 20250619131226.png|600]]
>![[Pasted image 20250619131236.png|600]]
>![[Pasted image 20250619131244.png|600]]
>![[Pasted image 20250619131254.png|600]]
>![[Pasted image 20250619131307.png|600]]
>![[Pasted image 20250619131314.png|600]]

****
### Data structure and model
![[Pasted image 20250619122819.png|600]]
![[Pasted image 20250619122952.png|600]]
![[Pasted image 20250619123000.png|600]]

>[!example]+ 8.1 Basic example
>
>The data used for Figure 8.1 is given by:
>![[Pasted image 20250619123019.png]]
>The question is of course: is there a difference in the means of the groups (A, B and C)? We start by having a look at the observations:
>
>``` python
>y = np.array([2.8, 3.6, 3.4, 2.3, 5.5, 6.3, 6.1, 5.7, 5.8, 8.3, 6.9, 6.1]) 
>treatm = pd.Categorical([1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3]) 
>D = pd.DataFrame({’y’: y, ’treatm’: treatm}) 
>D.boxplot(by=’treatm’, grid=False) 
>
>plt.title(’Boxplots by categories’) 
>plt.suptitle(’’) 
>
># Removing automatic titles 
>plt.xlabel(’’) 
>plt.show()
>```
>
>![[Pasted image 20250619123104.png|600]]
>
>By using pd.Categorical the treatments are not considered as numerical values by Python, but rather as factors (or grouping variables), and we can get the boxplot of the within group variation. This plot gives information about the location of data and variance homogeneity (the model assumption), of course with only 4 observations in each group it is difficult to asses this assumption. Now we can calculate the parameter estimates (µˆ and αˆi ) by
>
>``` python
>mu = np.mean(y) 
>muis = D.groupby(’treatm’,observed=True)[’y’].mean() 
>alpha = muis - mu 
>
>print(mu) 
>5.233333333333333 
>
>print(muis) 
>treatm 
>1 3.025 
>2 5.900 
>3 6.775 
>
>Name: y, dtype: float64 
>
>print(alpha) 
>treatm 
>1 -2.208333 
>2 0.666667 
>3 1.541667 
>
>Name: y, dtype: float64
>```
>
>So our estimate of the overall mean is µˆ = 5.23, and the group levels (offsets from the overall sample mean) are αˆ 1 = −2.21, αˆ 2 = 0.67 and αˆ 3 = 1.54. The question we need to answer is: how likely is it that the observed differences in group means are random variation? If this is very unlikely, then it can be concluded that at least one of them is significantly different from zero. 
>
>The shown use of the pandas function groupby function is a convenient way of finding the mean of y for each level of the factor treatm. By the way if the mean is substituted by any other function, e.g. the variance, we could similarly find the sample variance within each group (we will have a closer look at these later):
>
>``` python
>D.groupby(’treatm’,observed=True)[’y’].var() 
>
>treatm 
>1 0.349167 
>2 0.133333 
>3 1.249167 
>
>Name: y, dtype: float64
>```

LSD
![[Pasted image 20250619172921.png]]
![[Pasted image 20250619172930.png]]

****
### Decomposition of variability, the ANOVA table

>[!info]
>For the one-way ANOVA presented in this section the total variation, that is, the variation calculated across all the data completely ignoring the fact that the data falls in different groups, can be decomposed into two components: a component expressing the group differences and a component expressing the (average) variation within the groups:

>[!theorem]+ 8.2 Variability decomposition
>
>![[Pasted image 20250619123700.png|600]]

>[!info]
>
>SST: expresses the total variation
>**Treatment sum of squares (SS(Tr))**: variation _between_ group means, the first row
>**Error sum of squares (SSE)**: variation _within_ groups (Residuals), second row
>
>![[Pasted image 20250619142841.png|600]]
>
>
>We can see that if the sample variance formula is applied to the the yijs joined into a single sample (i.e. a single index counts through all the n observations), then the sample variance is simply SST divided by n − 1. The sample variance expresses then the average variation per observation. Therefore, we have
>
>$SST = (n-1)*s^2_y$
>
>Then $s^2_y$ is the sample variance for all the $y_{ij}s$
>
>The group mean differences are quantified by the SS(Tr) (it can alternatively be expressed by deviations $\hat{α}_i$)
>
>![[Pasted image 20250619124041.png]]

![[Pasted image 20250619124101.png|600]]

>[!theorem]+ 8.4 Within group variability
>
>The sum of squared errors SSE divided by n − k, also called the residual mean square MSE = SSE/(n − k) is the weighted average of the sample variances from each group
>
>![[Pasted image 20250619124224.png|600]]

>[!info]
>
>![[Pasted image 20250619132943.png|600]]

>[!example]+ 8.5
>
>![[Pasted image 20250619124245.png|600]]
>
>![[Pasted image 20250619124301.png|600]]

>[!theorem]+ 8.6
>
>![[Pasted image 20250619124321.png|600]]
>

>[!note]
>Mean Sum of Squares and others
>![[Pasted image 20250619124354.png]]

>[!example]+ 8.7
>
>![[Pasted image 20250619124414.png|600]]

****
### Post hoc comparisons

>[!info]
>
>![[Pasted image 20250619124551.png]]

****

>[!method]+ 8.9 Post hoc pairwise confidence intervals
>
>A single planned comparison of the difference between treatment i and j is found by:
>![[Pasted image 20250619124715.png]]
>where t1−α/2 is from the t-distribution with n−k degrees of freedom.

>[!note]
>Fewer degrees of freedom, since more parameters are estimated in calculating $MSE = SSE/(n−k) = s^2_p$ (the pooled variance estimate)
>### The problem:
>
>If you do many comparisons, the chance of making **at least one Type I error** (false positive) increases. So, we use **Bonferroni correction** to keep the _overall_ (familywise) error rate at your desired level (say, 0.05)
>To **control the overall Type I error rate**, Bonferroni correction says: instead of using your normal α (like 0.05) for each CI, you use a smaller one $αBonferroni​=\frac{α}{M}​$

****

>[!method]+ LSD Method
>The LSD method is one of the simplest post hoc tests. It is appropriate when:
>
>1. **Equal sample sizes** – as noted, each year has 6 observations.
 >   
>2. **You want to compute confidence intervals for pairwise differences**.
  >  
>3. You apply **Bonferroni correction**

>[!method]+ 8.10 Post hoc pairwise hypothesis tests
>
>For a single planned hypothesis test
>![[Pasted image 20250619125500.png|600]]
>a t-test with n−k degrees of freedom can be used with test statistic
>
>![[Pasted image 20250619125510.png|600]]
>![[Pasted image 20250619125519.png|600]]

>[!example]+ 8.11
>
>Returning to our small example we get the pairwise confidence intervals. If the comparison of A and B was specifically planned before the experiment was carried out, we would find the 95%-confidence interval as:
>
>``` python
>print(muis[0] - muis[1] + np.array([-1, 1]) * stats.t.ppf(1 - 0.05 / 2, 12 - 3) * np.sqrt(SSE / (12 - 3) * (1/4 + 1/4))) 
>
>[-4.090 -1.660]
>```
>
>and we can hence also conclude that treatment A is different from B. The p-value supporting this claim is found as:
>
>``` python
>tobs = (muis[0] - muis[1]) / np.sqrt(SSE / (12 - 3) * (1/4 + 1/4)) 
>print(2 * (1 - stats.t.cdf(np.abs(tobs), 12 - 3)))
>
>0.0004613963065729365
>```
>
>If we do all three possible comparisons, M = 3 · 2/2 = 3, and we will use an overall α = 0.05, we do the above three times, but using each time αBonferroni = 0.05/3 = 0.016667:
>
>``` python
>alpha_bonf = 0.05 / 3 
># A-B 
>print(alpha[0] - alpha[1] + np.array([-1, 1]) * stats.t.ppf(1-alpha_bonf/2, 12 - 3) * np.sqrt(SSE/(12 - 3) * (1/4 + 1/4))) 
>
>[-4.451 -1.299] 
>
># A-C 
>print(alpha[0] - alpha[2] + np.array([-1, 1]) * stats.t.ppf(1-alpha_bonf/2, 12 - 3) * np.sqrt(SSE/(12 - 3) * (1/4 + 1/4))) 
>
>[-5.326 -2.174] 
>
># B-C 
>print(alpha[1] - alpha[2] + np.array([-1, 1]) * stats.t.ppf(1-alpha_bonf/2, 12 - 3) * np.sqrt(SSE/(12 - 3) * (1/4 + 1/4))) 
>
>[-2.451 0.701]
>```
>
>and we conclude that treatment A is different from B and C, while we cannot reject that B and C are equal. The p-values for the last two comparisons could also be found, but we skip that now.

**The so-called Bonferroni correction done above, when we do all possible post hoc comparisons, has the effect that it becomes more difficult (than without the correction) to claim that two treatments have different means.**

>[!example]+ 8.12
>
>The 0.05/3-critical value with 9 degrees of freedom is $t_{0.9917}$ = 2.933 whereas the 0.05-critical value is $t_{0.975}$ = 2.262:
>
>``` python
>print(stats.t.ppf(1 - alpha_bonf / 2, 12 - 3), stats.t.ppf(1 - 0.05 / 2, 12 - 3)) 
>2.9333240883739897 2.2621571628540993
>```
>
>So two treatment means would be claimed different WITH the Bonferroni correction
>
>![[Pasted image 20250619130014.png|600]]

****
### Model control

>[!method]+ 8.15 Normality control in one-way ANOVA
>
>![[Pasted image 20250619130435.png|600]]

>[!example]+ 8.16
>
>For the basic example we get the normal q-q plot of the residuals by
>
>``` python
>sm.qqplot(fit.resid.values, line=’q’,a=1/2) 
>plt.tight_layout() 
>plt.show()
>```
>
>![[Pasted image 20250619130526.png|600]]

****
### **Full Example:**

**Plastic types for lamps**:
On a lamp two plastic screens are to be mounted. It is essential that these plastic screens have a good impact strength. Therefore an experiment is carried out for 5 different types of plastic. 6 samples in each plastic type are tested. The strengths of these items are determined. The following measurement data was found (strength in kJ/m2 ):

![[Pasted image 20250619130607.png]]

![[Pasted image 20250619130622.png|600]]
![[Pasted image 20250619130635.png|600]]
![[Pasted image 20250619130656.png|600]]
Or using the idea of comparing with repeated plots on the standardized residuals: (See Section 3.1.8)
![[Pasted image 20250619130715.png|600]]
And then we want to construct the M = 5 · 4/2 = 10 different confidence intervals
![[Pasted image 20250619130729.png|600]]

****
## Easily calculate SST
![[Pasted image 20250619142446.png]]

****
### Extra Notes

>[!note]
>![[Pasted image 20250619174442.png]]
>
>![[Pasted image 20250619174641.png]]
>#### **Here m = $n_i$**
