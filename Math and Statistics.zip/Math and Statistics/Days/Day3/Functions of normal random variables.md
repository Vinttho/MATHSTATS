# The χ2-distribution
The χ2-distribution (chi-square) is defined by:

>[!definition]
>![[Pasted image 20250610105029.png|600]]

An alternative definition (here formulated as a theorem) of the χ2-distribution
is:

>[!definition]+ Theorem
> ![[Pasted image 20250610105103.png|600]]

>[!example]+ Simulation of χ2-distribution
>
>``` python
> # Simulate 10 realizations from a standard normal distributed variable
n = 10
stats.norm.rvs(loc=0, scale=1, size=n)
># Now repeat this 200 times and calculate the sum of squares each time
># Note: the use of the function replicate: it repeats the
># expression in the 2nd argument k times, see ?replicate
x = [np.sum(stats.norm.rvs(loc=0, scale=1, size=n)**2) for _ in range(200)]
x = np.array(x)
># Plot the epdf of the sums and compare to the theoretical chisquare pdf
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(8,4))
ax1.hist(x, density=True, label=’epdf’)
ax1.plot(range(0,31), stats.chi2.pdf(range(0,31), df=n), color="red", label=’pdf’)
># and the ecdf compared to the cdf
stats.ecdf(x).cdf.plot(ax2, label=’ecdf’)
ax2.plot(range(0,31), stats.chi2.cdf(range(0,31), df=n), color="red", label=’cdf’)
>```
>
>![[Pasted image 20250610105225.png|600]]

>[!definition]+ Theorem
>
>Given a sample of size n from the normal distributed random variables Xi
with variance σ2, then the sample variance S2 (viewed as random variable)
>can be transformed into
>$$X^2 = \frac{(n-1)S^2}{σ^2}$$
which follows the **χ2**-distribution with degrees of freedom **v = n − 1**.

>[!example]+ Milk Dose Machines
>
>A manufacture of machines for dosing milk claims that their machines can dose with
a precision defined by the normal distribution with a standard deviation less than
**2%** of the dose volume in the operation range. A sample of **n = 20** observations was
taken to check if the precision was as claimed. The sample standard deviation was
calculated to **s = 0.03.**
Hence the claim is that **σ ≤ 0.02**, thus we want to answer the question: if **σ = 0.02**
(i.e. the upper limit of the claim), what is then the probability of getting the sampling
>deviation **s ≥ 0.03**?
>
>``` python
># Chi-square milk dosing precision
># The sample size
n = 20
># The claimed deviation
sigma = 0.02
># The observed sample standard deviation
s = 0.03
># Calculate the chi-square statistic
chiSq = (n-1)*s**2 / sigma**2
># Use the cdf to calculate the probability of getting the observed
># sample standard deviation or higher
1 - stats.chi2.cdf(chiSq, df=n-1)
np.float64(0.0014022691601097703)
>```
>
>It seems very unlikely that the standard deviation is below 0.02 since the probability
of obtaining the observed sample standard deviation under this condition is very
small. The probability we just found will be termed a p-value in later chapters - the
p-value a very fundamental in testing of hypothesis.

>[!definition]+ Theorem, Mean and variance
>
>Let **X ∼ χ2(ν)** then the mean and variance of **X** is
>$$E(x)=v; V(x) = 2v$$

>[!example]
>
>![[Pasted image 20250610110044.png|600]]

>[!example]+ Pooled variance
>
>![[Pasted image 20250610110107.png|600]]
>
>![[Pasted image 20250610110118.png|600]]

