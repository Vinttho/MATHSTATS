>[!definition]+ Multivariate probability density functions
>
>![[Pasted image 20250610102307.png|600]]

>[!definition]+ Second order moment representation
>
>![[Pasted image 20250610102344.png|600]]

>[!info]
>
>![[Pasted image 20250610102426.png|600]]

>[!definition]+ Theorem, Covariance calculation rules
>
>![[Pasted image 20250610102513.png|600]]

>[!definition]+ Independence of random vectors
>![[Pasted image 20250610102543.png|600]]

>[!info]
>The definition imply that if **Y1** and **Y2** are independent then **Cov[Y1, Y2] = 0**.

****
# Error Propagation

>[!info]
>
>![[Pasted image 20250610103037.png|600]]

>[!example]+ Body Mass Index
>
>![[Pasted image 20250610103105.png|600]]
>
>``` python
>mu
height 180.774671
weight 78.351891
dtype: float64
h = mu["height"]
w = mu["weight"]
J = np.array([-2 * w / h**3 * 10000, 1 / h**2 * 10000])
J @ dat.cov() @ J.T
np.float64(5.804464687904143)
>```
>hence the variance is approximated by **5.8 kg2/m4** or a standard deviation of **2.4**
>**kg/m2**.

****
# The multivariate Gaussian distribution

>[!info]
>A common definition of the multivariate normal distribution is that the pdf of
>the random variable **Y ∈ Rn** is:
>
>![[Pasted image 20250610103245.png|600]]
>
>We will sometimes omit the subscript n if it is clear from context (or if it is not
>important)

>[!example]
>
>The ellipsoids in the figure in [[Matrix Formulation of summary statistics|Example 9.1]] are level curves in a 2-dimensional nor-
>mal with mean value equal the observed average and variance-covariance equal the
>observed variance-covariance matrix (see [[Matrix Formulation of summary statistics|Example 9.2]])

>[!definition]+ #Theorem-Independence-of-normal-random-variables
>If $Y = [Y_1^T, Y_2^T]^T ~ N(μ, Σ)$ and
>$$Cov[Y_1, Y_2] = 0,$$
>then **Y1** and **Y2** are independent.

>[!note]
>Note that the assumption of the joint distribution is important in #Theorem-Independence-of-normal-random-variables  
>i.e. it is not enough that the marginal distribution of the random variables in
>the vector are normal. The next example illustrate the point.

>[!example]
>
>![[Pasted image 20250610104405.png|600]]

>[!definition]+ Theorem, Normalization of normal random vectors
>![[Pasted image 20250610104453.png|600]]

>[!definition]+ Multivariate normal distribution
>
> ![[Pasted image 20250610104543.png|600]]

>[!info]
>The definition imply that any linear combination of a multivariate normal ran-
dom vector is also a multivariate normal random vector and further if the co-
variance between two elements of a multivariate normal vector is zero the they
are independent.
As an example suppose we have n iid. standard normal random variables **(Zi)**
and form the average of those $\overline{Z}$ and consider the difference between the averages
> and the individual random variables (we denote these as residuals, r)
> 
> ![[Pasted image 20250610104908.png|600]]
> 
> ![[Pasted image 20250610104918.png|600]]

