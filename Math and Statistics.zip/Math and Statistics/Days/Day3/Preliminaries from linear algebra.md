
> [!Eigenvalue decomposition of symmmetric matrices]
> ![[Pasted image 20250608124014.png|600]]

#### **Calculate eigenvalues and vects**
``` python
Eigen = eig(S) 

Eigvals, Eigvectors = eig(S) 

print(Eigvals) 
[ 23.821 138.108] 

print(Eigvectors)
[[-0.861 -0.508] [ 0.508 -0.861]]
```
![[Pasted image 20250604124228.png|600]]

 >[!Permutation in traces]
 >For matrices **A**, **B** and **C** such that that the products **ABC**, **BCA** and **CAB** can be formed then **Trace(ABC) = Trace(BCA) = Trace(CAB).**

#### **Rank-1 update of matrix inverse**
![[Pasted image 20250604124536.png|600]]

#### **Rank-1 update of projection matrix**
![[Pasted image 20250604124608.png|600]]

