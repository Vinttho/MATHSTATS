>[!example]+ Rectangular plates
>
>A company produces rectangular plates. The length of plates (in meters), **X** is assumed to follow a normal distribution **N(2, 0.012)** and the width of the plates (in
meters), **Y** are assumed to follow a normal distribution **N(3, 0.022)**. We’re hence
dealing with plates of size **2 × 3** meters, but with errors in both length and width.
Assume that these errors are completely independent. We are interested in the area
of the plates which of course is given by **A = XY**. This is a non-linear function of **X**
and **Y**, and actually it means that we, with the theoretical tools we presented so far
in the material, cannot figure out what the mean area really is, and not at all what
the standard deviation would be in the areas from plate to plate, and we would definitely not know how to calculate the probabilities of various possible outcomes. For
example, how often such plates have an area that differ by more than **0.1 m2** from
the targeted **6 m2**? One statement summarizing all our lack of knowledge at this
point: we do not know the probability distribution of the random variable **A** and
we do not know how to find it! With simulation, it is straightforward: one can find
all relevant information about **A** by just simulating the **X** and **Y** a high number of
times, and from this compute **A** just as many times, and then observe what happens
> to the values of **A**. The first step is then given by:
> 
> ``` python
> # Number of simulations
>k = 10000
># Simulate X and Y, then A
>X = stats.norm.rvs(loc=2,scale=0.012,size=k)
>Y = stats.norm.rvs(loc=3,scale=0.022,size=k)
>A = X * Y
>```
>The Python object **A** now contains **10.000** observations of **A**. The expected value
>and the standard deviation for **A** are simply found by calculating the average and
>standard deviation for the simulated **A**-values:
>
>``` python
># The mean and std. deviation of the simulated values
>print(A.mean())
>6.000707518857636
>print(A.std(ddof=1))
>0.050187379229233574
>```
>
>and the desired probability, $P(|A − 6| > 0.1) = 1 − P(5.9 ≤ A ≤ 6.1)$ is found by
>counting how often the incident actually occurs among the k outcomes of **A**:
>
>``` python
>1*(abs(A-6) > 0.1).mean()
>np.float64(0.0454)
>```
>The code abs(A-6) > 0.1 creates an array with values TRUE or FALSE depending on
whether the absolute value of A − 6 is greater than 0.1 or not. When you multiply
by 1 the TRUE is automatically translated into 1 and FALSE automatically translated
to 0. To find the probability, we sum these binary values and divide by number
of simulations k. This is equivalent to finding the mean of the binary values, and
therefore we use the mean method.

****
## Propagation of error

>[!info]
>
>An error propagation problem is a question about how
>the standard deviation of some function of the measurements depends on the
>standard deviations for the individual measurement
>
>(When you measure quantities and then **combine them** (e.g., by adding, multiplying, or applying any function), the **uncertainty (or error)** in the final result depends on the uncertainties in the original measurements.)
$$σ_{f(X_1,...,X_n)}^2 = V(f(X_1,...,X_n))$$

>[!important]+ Remark
>For the thoughtful reader: Measurement errors, errors and variances] Al-
though we motivate this entire treatment by the measurement error termi-
nology, often used in chemistry and physics, actually everything is valid
for any kind of errors, be it “time-to-time” production errors, or “substance-
to-substance” or “tube-to-tube” errors. What the relevant kind of er-
rors/variabilities are depends on the situation and may very well be mixed
together in applications. But, the point is that as long as we have a relevant
error variance, we can work with the concepts and tools here. It does not
have to have a “pure measurement error” interpretation.

>[!note]
>
>Actually, we have already in this course seen the linear error propagation rule,
>in Theorem in 2.56, which then can be restated here as:
>
>$$f(X_1,...,X_n) = \sum_{i=1}^n{a_i}{X_i}$$ then $$σ_{f(X_1,...,X_n)}^2 = \sum_{i=1}^n{a_i^2}{σ_i^2}$$

>[!important]+ Method: The non-linear approximative error propagation rule
>
>![[Pasted image 20250610093137.png|600]]

>[!important]+ Method: Non-linear error propagation by simulation
>
>![[Pasted image 20250610093244.png|600]]

>[!example]
>
>![[Pasted image 20250610093316.png|600]]
>![[Pasted image 20250610093327.png|600]]

>[!important]
>
>S is just a simulation
>
>Where we have $S_p^2$ is the pooled sample variance
>$σ^2$ is the **true population variance**

![[Pasted image 20250611100745.png|600]]
![[Pasted image 20250611101430.png|600]]
![[Pasted image 20250611101542.png|600]]
