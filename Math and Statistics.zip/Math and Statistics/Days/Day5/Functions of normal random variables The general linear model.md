## **The multivariate normal and the χ 2 -distribution**

>[!info]
>From the definition of the χ 2 -distribution
>we know that, if Z ∼ Nn(0, I) then
>$$Z^TZ ∼ X^2(n)$$

>[!corollary]
>With Y ∈ Rn as in Theorem 9.16 then
>$$(Y - µ)^T Σ^{-1} (Y - µ) ∼ X^2(n)$$

>[!info]
>![[Pasted image 20250612104656.png|600]]

>[!Example]+ 9.19
>
>In Example 9.1 we saw level curves of the Gaussian pdf, these are described by curves where
>![[Pasted image 20250612104727.png|600]]
>with µ equal the observed average of height and weight, and Σ equal the observed variance-covariance (see Example 9.4). Also the values of α is set at 0.5, 0.05 and 0.005 respectively for the three curves. Hence the length of the red arrow in the plot of Example 9.1 is
>
>![[Pasted image 20250612104748.png|600]]
>
>![[Pasted image 20250612104802.png|600]]

>[!example]+ 9.20
>
>![[Pasted image 20250612104826.png|600]]

The derivations above is a special case of Cochran’s theorem, which we will state below, but first we need the concept of orthogonal projection matrices, as stated in the next definition.

>[!definition]+ Orthogonal projections
>A matrix P is an orthogonal projection matrix if and only if 
>- P is symmetric, i.e. P = P^T 
>- P is idempotent, i.e. P^2 = P

>[!note]
>If P is a projection matrix then so is I − P, this is easily shown by

>[!lemma]+ 9.22 Properties of orthogonal projection matrices
> If P is an orthogonal projection matrix, then 
> - 1. The eigenvalues λi of P are either 0 or 1, and Rank(P) = ∑i λi . 
> - 2. Rank(P) = Trace(P).

![[Pasted image 20250612110840.png]]

>[!theorem]+ 9.22 Cochran's theorem
>![[Pasted image 20250612110953.png|600]]

>[!info]
>
>As we will see in later sections Cochran’s theorem is useful for constructing test statistics and determine their distributions. We prove the theorem in Section 9.4.1 below. The independence condition in Theorem 9.23 is equivalent to
>
>![[Pasted image 20250612111044.png|600]]
>
>In the simple example in eps. (9-48) we have
>![[Pasted image 20250612111103.png|600]]
>
>and it is easy to show that Cov[H1Z, H2Z] = 0 (see Exercise 9)
>
>![[Pasted image 20250612111121.png|600]]

****
### Proof of Cochran’s Theorem

![[Pasted image 20250612111203.png|600]]
![[Pasted image 20250612111218.png|600]]
![[Pasted image 20250612111230.png|600]]

****
****

## **The general linear model**

>[!info]
>
>The models covered in Chapter 3, 5, 6, and 8 can all be written as
>![[Pasted image 20250612111325.png|600]]
>
>Any model that can be written in the form (9-85) is called a general linear model. Y is the outcome of interest, the known matrix X is called the design matrix, β is the mean value parameters that we should estimate based on the design matrix and the outcomes, e is the residual errors, with variance σ 2 , and further we assume that all residuals are iid. In this section we will cover the general linear model in very general terms, and in later sections we will present different examples (including the model covered in Chapters 3, 5, 6, and 8). As we do not know the mean parameter we will have to rely on estimates/estimators of them, i.e. we observe
>
>![[Pasted image 20250612111340.png|600]]
>
>where r is the observed residuals (i.e. the realized version of e), Σ depend on design matrix (X) and $σ^2$ . Now define the residual sum of squares as
>![[Pasted image 20250612111416.png|600]]
>
>from the perspective of RSS the best estimator is
>
>![[Pasted image 20250612111429.png|600]]
>
>the result of this minimization problem is given in the next theorem:

>[!theorem]+ 9.24, Least square estimator
>
>![[Pasted image 20250612111459.png|600]]

>[!note]
>
>Throughout this document we will assume that X TX is invertible, and if this is not the case then we will discuss the action needed to me make X TX invertible (basically removing columns in the design matrix). Cases where one for some reason insist (which may be relevant) on a design matrix where X TX is not invertible will not be discussed here.
>
>For any reasonable design matrices this imply that V[βˆ ] → 0 as the number of observation go to infinity, implying that the estimator is consistent.

>[!definition]+ 9.25, Orthogonal parametrization
>
>A parametrization is called orthogonal if (X^T * X)_ij = 0 for i 6= j.

>[!info]
>
>An orthogonal parametrization imply that the covariance between parameters is zero. We will see later on in this chapter that the same model can be parameterized in different, but equivalent ways, implying that different design matrices may be associated with the same model. Orthogonal design is (given everything equal) preferable as changes in one parameter does not changes other parameters. Also one way of dealing with multicollinarity is orthogonalization of the desing matrix.

****
### **Estimators or estimates**

>[!info]
>
>In the derivations above we have considered the observation as a random variables (and hence used Y), and in that setting βˆ is also a random variable. When we have actual observation of the system we denote the observation by y (this not a random vector) and then βˆ = (X TX) −1X Ty is also a vector of actual numbers (not a random vector) that is refereed to as an estimate. In the following we will need both interpretations of βˆ , but it should be clear from the context which we are referring to. In general we can say that what we actually observe are estimates, but when constructing appropriate test statistic we consider the estimator. For example the distribution used in the partial ttest is derived using the estimator, βˆ , while when we calculate the test statistic in a specific problem (which is used for calculating a p-value or compared to a critical value), we use the estimate β

****
### **Geometric interpretation of the general linear model (LM)**

![[Pasted image 20250612113006.png|600]]
![[Pasted image 20250612113020.png|600]]

>[!example]+ 9.26, Items on a balance
>
>![[Pasted image 20250612113049.png|600]]
>
>![[Pasted image 20250612113100.png|600]]

>[!note]
>![[Pasted image 20250612113119.png|600]]

