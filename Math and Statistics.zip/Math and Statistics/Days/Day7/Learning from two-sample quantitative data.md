### 3.2 Learning from Two-Sample Quantitative Data  
#### **Key Concepts**  
> [!info]  
>- **Two-sample setup**: Compares means of two independent populations (e.g., treatment vs. control).  
>- **Paired design**: Compares measurements from the *same subjects* under two conditions (e.g., pre-test vs. post-test).  
>- **Welch’s t-test**: Default method for unequal variances; uses adjusted degrees of freedom.  
>- **Pooled t-test**: Assumes equal variances; uses combined variance estimate.  
>- **Overlapping CIs**: Individual group confidence intervals **cannot** reliably determine group differences; always use CI for the *mean difference*.  

---

#### **Definitions & Theorems**  
> [!definition] **Pooled Variance Estimate (Method 3.52)**  
> Under equal variances ($(\sigma_1^2 = \sigma_2^2$)):  
>$$
> s_p^2 = \frac{(n_1-1)s_1^2 + (n_2-1)s_2^2}{n_1 + n_2 - 2}
> $$  
> **Use case**: Required for pooled t-test.  

> [!theorem] **Welch’s t-Test Statistic (Method 3.50)**  
> For $(H_0: \delta = \mu_2 - \mu_1 = 0)$:  
>$$
> t_{\text{obs}} = \frac{(\bar{x}_1 - \bar{x}_2) - \delta_0}{\sqrt{\frac{s_1^2}{n_1} + \frac{s_2^2}{n_2}}}
> $$
> **Degrees of freedom (\(\nu\))**:  
>$$
> \nu = \frac{\left( \frac{s_1^2}{n_1} + \frac{s_2^2}{n_2} \right)^2}{\frac{(s_1^2/n_1)^2}{n_1-1} + \frac{(s_2^2/n_2)^2}{n_2-1}}
>$$ 
> **Advantage**: Robust to unequal variances; preferred over pooled test.  

> [!theorem] **Paired t-Test**  
> For paired data (e.g., same subjects under two conditions):  
> 1. Compute differences $(d_i = x_i - y_i$).  
> 2. Apply **one-sample t-test** to $(d_i)$.  
> **Key benefit**: Reduces variability by accounting for subject-specific effects.  

>[!theorem]+ 3.54, The distribution of the pooled two-sample t-test statistic
>
>![[Pasted image 20250616153608.png|600]]

---

#### **Examples**  
> [!example] **Nutrition Study (Example 3.46)**  
> - **Goal**: Compare energy usage (MJ) between nurses from Hospital A (\(n=9\)) and Hospital B (\(n=9\)).  
> - **Data**:  
> - $$
>   - (\bar{x}_A = 8.293), (\bar{x}_B = 10.298)  
>   - (\hat{\delta} = \mu_B - \mu_A = 2.005)  $$
> - **95% CI for \(\delta\)**: \([0.59, 3.42]\) (excludes 0 → significant difference).  
> - **Welch’s t-test**:  
>   - $(t_{\text{obs}} = 3.01)$, $(\nu = 15.99)$, $(p\text{-value} = 0.0083)$ → $reject (H_0)$.  
> - **Python**:  
>   ```python
>   stats.ttest_ind(xB, xA, equal_var=False)  # Welch’s test
>   ```  

> [!example] **Sleeping Medicine Paired Test (Example 3.60)**  
> - **Goal**: Compare two sleeping drugs using 10 subjects who tried both.  
> - **Analysis**:  
>   - Use paired t-test on differences $(d_i = B_i - A_i)$.  
>   - **Python**:  
>     ```python
>     stats.ttest_rel(xB, xA)  # Paired test (same as one-sample test on differences)
>     ```  
>   - **Result**: $(t_{\text{obs}} = 4.67)$, $(p\text{-value} = 0.0012)$ → significant difference.  
> - **Wrong independent test**: $(p\text{-value} = 0.069)$ (misses significance due to ignored pairing).  
>   
>``` python
> # Read the samples 
>x1 = np.array([0.7, -1.6, -0.2, -1.2, -1.0, 3.4, 3.7, 0.8, 0.0, 2.0]) 
>x2 = np.array([1.9, 0.8, 1.1, 0.1, -0.1, 4.4, 5.5, 1.6, 4.6, 3.4]) 
>  
># Take the differences 
>dif = x2 - x1 
>  
># t-test on the differences 
>test = stats.ttest_1samp(dif,popmean=0) 
>  
>print(test.statistic,test.pvalue,test.df) 
>4.671645978656774 0.0011658764685528319 9 
>  
>stats.ttest_1samp(dif,popmean=0).confidence_interval(0.95)
> ```

> [!example] **Overlapping CIs Pitfall (Example 3.58)**  
> - **Scenario**: Individual 95% CIs for Hospitals A and B:  
>   - A: \([7.20, 9.39]\), B: \([9.22, 11.37]\) (overlap slightly).  
> - **Fallacy**: Overlap ≠ non-significant group difference.  
> - **Correct approach**: CI for *mean difference* $((\delta))$ is $([0.59, 3.42])$ (excludes 0).  
> 
> ``` python
> # The confidence intervals 
> CIA = stats.ttest_1samp(xA,popmean=0).confidence_interval(0.95) 
> CIB = stats.ttest_1samp(xB,popmean=0).confidence_interval(0.95) 
> 
> # Barplots with error bars 
> fig, ax = plt.subplots(1, 1) 
> 
> ax.bar(x=[0,1],height=[xA.mean(),xB.mean()], yerr=[(CIA[1]-CIA[0])/2,(CIB[1]-CIB[0])/2],capsize=20,color=("r","g")) 
> 
> ax.set(xlabel="Hospital",ylabel="Energy usage") 
> ax.set_xticks([0,1],("A","B")) 
> plt.tight_layout() 
> plt.show()
> ```
> 
> ![[Pasted image 20250616153842.png|600]]

---

### 3.3 Planning a Study: Precision and Power  
#### **Key Concepts**  
>[!info]  
>- **Margin of Error (ME)**: Half-width of a confidence interval.  
>- **Statistical power**: Probability of rejecting \(H_0\) when \(H_0\) is false.  
>- **Type I error $((\alpha))$**: False positive rate.  
>- **Type II error $((\beta))$**: False negative rate; $(\text{Power} = 1 - \beta)$.  
>- **Effect size**: Standardized difference (e.g., $(\delta / \sigma))$.  

---

#### **Formulas & Methods**  
> [!definition] **Sample Size for Precision (Method 3.63)**  
> For a one-sample CI with margin of error \(ME\):  
> $$
> n = \left( \frac{z_{1-\alpha/2} \cdot \sigma}{ME} \right)^2
> $$
> **Requirements**: Guess for $(\sigma)$, normal approximation $((n \geq 30))$.  

> [!definition] **Sample Size for Power (Method 3.65)**  
> For one-sample t-test (detect difference $(\delta = |\mu_0 - \mu_1|))$:  
> $$
> n = \left( \sigma \frac{z_{1-\beta} + z_{1-\alpha/2}}{\delta} \right)^2
> $$ 
> **Python**:  
> ```python
> from statsmodels.stats.power import TTestPower, TTestIndPower
> # One-sample
> TTestPower().solve_power(effect_size=δ/σ, alpha=α, power=0.8)
> # Two-sample
> TTestIndPower().solve_power(effect_size=δ/σ, alpha=α, power=0.8, ratio=1)
> ```  

---

#### **Examples**  
> [!example] **Student Heights (Example 3.64)**  
> - **Goal**: 95% CI with $(ME = 3)$ cm, $(\sigma \approx 12.2)$ (pilot data).  
> - **Sample size**:  
> $$
>   n = \left( \frac{1.96 \cdot 12.21}{3} \right)^2 \approx 64
>  $$ 

> [!example] **Power Analysis for Student Heights (Example 3.67)**  
> - **Test**: $(H_0: \mu = 180)$ vs. $(H_1: \mu \neq 180)$.  
> - **Parameters**: $(\alpha=0.05)$, $(\delta=4)$ cm, $(\sigma=12.21)$, power $(=0.8)$.  
> - **Sample size**:  
>   - By formula: $(n \approx 74)$.  
>   - Python: `TTestPower().solve_power(effect_size=4/12.21, power=0.8) → 76`.  
>     
>![[Pasted image 20250616154159.png|600]]
>![[Pasted image 20250616154209.png|600]]

> [!example] **Two-Sample Power (Example 3.68)**  
> - **Goal**: Detect group difference $(\delta=2)$ with $(\sigma=1)$, $(\alpha=0.05)$, power $(=0.9)$.  
> - **Sample size per group**:  
>   ```python
>   TTestIndPower().solve_power(effect_size=2/1, power=0.9, ratio=1) → 7
>   ```  
> - **Detectable effect for \(n=10\) per group**:  
>   ```python
>   effect = TTestIndPower().solve_power(nobs1=10, power=0.9)  
>   delta = effect * σ  # → 1.53 (if σ=1)
>   ```  
>   
>   ![[Pasted image 20250616154248.png|600]]



---

#### **Summary Workflow**  
1. **Precision planning**: Use CI width (\(ME\)) to determine \(n\).  
2. **Power planning**: Define $(\alpha)$, $(\delta)$, $(\sigma)$, power → solve for $(n)$.  
3. **Two-sample tests**: Always prefer Welch’s t-test unless variances are known equal.  
4. **Paired data**: Analyze differences to increase power.  
5. **Python tools**:  
   - `stats.ttest_ind(equal_var=False)` for Welch’s test.  
   - `stats.ttest_rel()` for paired test.  
   - `TTestPower()` / `TTestIndPower()` for power calculations.