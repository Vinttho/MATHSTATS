# Two sample t-test as a LM

>[!corollary]+ 9.29, Two-sample t-test as a projection
>
>![[Pasted image 20250616142021.png|600]]

>[!corollary]+ 9.30, Variance estimator
>
>With Y and the projections as in Corollary 9.29, then a central estimator for $\hat{\sigma}^2$ is
>
>$$\hat{\sigma}^2 = \frac{Y^T (I - H_1)Y}{n-2}$$
>
>the estimator is equal the pooled variance estimator presented in Example 2.85, furthermore the variance of the estimator is
>
>$$V[\hat{\sigma}^2] = \frac{2*\sigma^2}{n - 2}$$

>[!info]
>
>### Understanding What the Parameters Mean
>
>The two ways of writing the model (called encoding (9-137) and (9-138)) lead to different 
>meanings for the numbers (parameters) the model estimates:
>- In **encoding (9-137)**:  
>		Each parameter tells you the **average (mean)** value for a group.  
> 	   The confidence intervals you get are for the **average within each group**, assuming both
> 	   groups have the same amount of variability.
  >  
>- In **encoding (9-138)**:  
    >The first parameter still refers to the average of one group (often the reference group), but
    > the **second parameter tells you the difference** between the two group averages.  
    > 
    >The confidence interval for this second parameter shows how certain we are about the 
   > **difference** between the group means, again assuming equal variability.
>
> (Exercise 15 shows another way you can set up the parameters, which gives a different interpretation.)
