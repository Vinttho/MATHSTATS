>[!info]
>
>The normality assumption can be checked by a normal q-q plot, and the constant variance assumption may be checked by plotting the residuals as a function of the fitted values

>[!example]+ 5.27 Residuals analysis
>
>![[Pasted image 20250618131109.png|600]]
>
>``` python
>np.random.seed(134) 
>n = 100 
>x1 = np.linspace(1, 10, n) 
>y = x1 + np.random.normal(0, 1, size=n) 
>
>D = pd.DataFrame({’x’: x1, ’y’: y}) 
>fit = smf.ols(formula = ’y ~ x’, data=D).fit() 
>
># Get the predictions (fitted values) 
>ypred = fit.predict(D) # or fit.fittedvalues 
>
># Plot the Q-Q plot and the residuals vs. fitted values 
>fig, ax = plt.subplots(1,2) 
>
># Q-Q plot of the residuals 
>sm.qqplot(y - ypred, line="q", a=1/2, ax=ax[0]) 
>ax[0].set_title("Q-Q plot") 
>
># Scatter 
>plot ax[1].scatter(ypred, y - ypred) 
>ax[1].set_xlabel("Fitted values") 
>ax[1].set_ylabel("Residuals") 
>ax[1].set_title("Residuals vs Fitted values") 
>
>plt.tight_layout() 
>plt.show()
>```
>
>![[Pasted image 20250618131228.png|600]]
>
>``` python
>np.random.seed(134) 
>n = 100 
>
>x1 = np.linspace(1, 10, n) 
>x2 = x1**2 y = x1 + 0.5 * x2 + stats.norm.rvs(loc = 0, scale = 1, size=n) 
>
>D = pd.DataFrame({’x’: x1, ’y’: y}) 
>fit = smf.ols(formula = ’y ~ x’, data=D).fit()
>```
>
>![[Pasted image 20250618131311.png|600]]
>
>The third model (with β0 = 0, β1 = 1, β2 = 0.5 and σ 2 = 1) is simulated, estimated and analysed by (plot function omitted):
>
>``` python
>np.random.seed(134)
>n = 100 x1 = np.linspace(4, 10, n) 
>y = np.exp( 0.2 * x1 + np.random.normal(0, 0.15, size=n)) 
>
>D = pd.DataFrame({’x’: x1, ’y’: y}) 
>fit = smf.ols(formula = ’y ~ x’, data=D).fit()
>```
>
>![[Pasted image 20250618131404.png|600]]
>
>``` python
>np.random.seed(134) 
>n = 100 
>x1 = np.linspace(4, 10, n) 
>y = np.exp( 0.2 * x1 + np.random.normal(0, 0.15, size=n)) 
>
>y = np.log(y) 
>D = pd.DataFrame({’x’: x1, ’y’: y}) 
>fit = smf.ols(formula = ’y ~ x’, data=D).fit()
>```
>
>![[Pasted image 20250618131439.png|600]]

>[!method]+ 5.28 Model validation (or residual analysis)
>- 1. Check the normality assumption with a q-q plot of the residuals 
>- 2. Check the systematic behaviour by plotting the residuals ei as a function of fitted values $\hat{y_i}$

>[!note]+ Remark 5.29 
>Independence In general independence should also be checked, while there are ways to do this we will not discuss them here.

