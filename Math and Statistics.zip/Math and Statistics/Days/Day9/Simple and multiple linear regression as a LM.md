![[Pasted image 20250618143447.png|600]]

>[!theorem]+ 9.35 Partial t-test and Type III partitioning of variation
>
>![[Pasted image 20250618124229.png|600]]

### 📘 What is this about?

This text explains how **linear regression** works when you have **more than one variable** (or "regressor") that helps predict something — not just one like in basic regression.

---

### ✅ Basic linear regression (1 variable):

In Chapter 5, we looked at this type of model:

$Yi=β0+β1xi+εiY_i = \beta_0 + \beta_1 x_i + \varepsilon_iYi​=β0​+β1​xi​+εi​$

- $YiY_iYi$​: the value we're trying to predict (like someone's height)
    
- $xix_ixi$​: the variable we use to predict it (like age)
    
- $β0,β1\beta_0, \beta_1β0​,β1$​: the model’s constants (intercept and slope)
    
- $εi\varepsilon_iεi$​: the random error (the difference between the actual value and what the model predicts)
    

---

### 🔁 Now we go beyond 1 variable

What if **more than one thing affects** YYY?  
For example, maybe height depends on **age**, **diet**, and **exercise**.

Then we write the model like this:

$Yi=β0+β1x1,i+β2x2,i+⋯+βpxp,i+εiY_i = \beta_0 + \beta_1 x_{1,i} + \beta_2 x_{2,i} + \cdots + \beta_p x_{p,i} + \varepsilon_iYi​=β0​+β1​x1,i​+β2​x2,i​+⋯+βp​xp,i​+εi​$

- Each $xj,ix_{j,i}xj,i$​ is one of the variables (like age, diet, etc.)
    
- The model has **multiple slopes** (one for each variable)
    
- This is called a **multiple linear regression** or a **general linear model (GLM)**
    

We still assume the errors εi\varepsilon_iεi​ are:

- random
    
- normally distributed
    
- with mean 0
    
- and constant spread (variance σ2\sigma^2σ2)
    

---

### 🎯 Goal: Find the best-fitting line (or surface!)

To figure out the best values of $β0,β1,...,βp\beta_0, \beta_1, ..., \beta_pβ0​,β1​,...,βp​$,, we try to **minimize the total prediction error**, called the **Residual Sum of Squares (RSS)**:

$RSS=∑i=1n(Yi−(β0+β1x1,i+⋯+βpxp,i))2RSS = \sum_{i=1}^{n} \left( Y_i - (\beta_0 + \beta_1 x_{1,i} + \cdots + \beta_p x_{p,i}) \right)^2RSS=i=1∑n​(Yi​−(β0​+β1​x1,i​+⋯+βp​xp,i​))2$

This just means: “Add up how far off your predictions are — and try to make that number as small as possible.”

---

### 🔍 What does the solution look like?

The best-fit prediction looks like:

$Y^i=β^0+β^1x1,i+⋯+β^pxp,i\hat{Y}_i = \hat{\beta}_0 + \hat{\beta}_1 x_{1,i} + \cdots + \hat{\beta}_p x_{p,i}Y^i​=β^​0​+β^​1​x1,i​+⋯+β^​p​xp,i​$

We use **hats ( ˆ )** to show these are **estimated values** — not the true unknown ones.

The actual value is:

$Yi=Y^i+eiY_i = \hat{Y}_i + e_iYi​=Y^i​+ei​$

...where $eie_iei$​ is the prediction error for that observation.

---

### 🔄 Bonus: We can also handle **nonlinear shapes** by transforming variables.

Later in the chapter, they’ll show how to make this kind of model fit things that **aren’t straight lines** by using curves, functions, or other tricks.