
## **Type I partitioning of variation**

>[!info]
>![[Pasted image 20250618123628.png|600]]
>
>![[Pasted image 20250618123655.png|600]]

****

>[!theorem]+ 9.31 Type I partioning and tests
>![[Pasted image 20250618124335.png|600]]

>[!important]
>![[Pasted image 20250618123303.png|600]]

>[!example]+ 9.32 Items on a scale
>
>We continue the example with items on a scale, again two items are put on scale and weighted first separately then together. In this example we assume that the recorded values are differences to a nominal value, hence the null hypothesis is that the expected difference is zero for both item. There is in this case a fairly obvious hierarchy of hypothesis: $H0 : µ1 = µ2 = 0$, $H1 : µ1 = µ2 = µ$ and the full model $H_M$ that allow different expected values for the two items (which is also assumed to be sufficient). In this case the design matrices could be
>![[Pasted image 20250618123405.png|600]]
>
>![[Pasted image 20250618123418.png|600]]

****
## **Type III partitioning of variation**

>[!theorem]+ 9.33 Type III partioning and test
>
>![[Pasted image 20250618124349.png|600]]

****

## **Variance estimator**

Having estimated the mean value parameters, we also need an estimator for the variance, given the discussion above, the answer is quite straight forward, and given in the theorem below:

>[!Corollary]+ 9.34 Variance estimator
>
>![[Pasted image 20250618123844.png|600]]

****

## **Type I or Type III?**

>[!important]
>Even though there are situations where the Type I partitioning is relevant, we recommend the Type III partitioning, in some of the situation covered here the two partitioning actually agree for all levels.

****
### Test for total homogeneity
>[!info]
>
>Often a test for total homogeneity will be reported along with the partial t-test a discussed above, referring to (9-183) this correspond to the test
>![[Pasted image 20250618124423.png]]
>against the alternative that at least one variable have a significant effect (i.e. reduce the sum of squares) in the output.

>[!example]+ 9.36 Temperature anomali
>
>As an example we look at the so-called global temperature anomali, which is defined as the global average temperature of a year minus the average global temperature over the period 1900-2000. In the data the period covered is 1850-2023. The result of a simple linear regression model is given below
>
>![[Pasted image 20250618124624.png|600]]
>
>From the summary it is clear that there is a significant increase of temperature, according to the model the increase is around 0.0062 degrees per year. We will get back to the validity of the model in the following sections. The p-values for intercept and slope are both reported as 0 (of course it just mean that the are very small). The test statistics for total homogeneity is 263.2, since this is a simple linear regression model is equals the squared rest statistics for the slope (16.2242 = 263.2), and in this case the numerical value of the p-value is actually given (1.65 · 10−36).

****
## **Linear transformation of regressors (input)**

>[!info]+ Example
>
>![[Pasted image 20250618124953.png|600]]
>
>Hence the models are equivalent as long as the intercept is included. This property (that model are invariant to linear transformations) is also the reason that it is usually not recommended to remove the intercept in model selection steps, and in the above example the models would not be equivalent if the intercept would have been removed as part of a model selection procedure.

>[!example]+ 9.37 Temperature anomali
>
>In the temperature example above it seems reasonable to use either the mid-point of the years ((1850 + 2023)/2 = 1936), or the the midpoint of the reference period (1950) as reference. If we denote that point (i.e. either 1936 or 1950) as xre f , then the transformation matrix would be
>
>![[Pasted image 20250618125043.png]]
>
>here X is a matrix with the first column a vector of ones and the second column a vector with the years. If $x_{ref}$ = 1936 then the parametrization is orthogonal and otherwise it is not.

### **The general linear model**
![[Pasted image 20250618125203.png|600]]

### **The partial t-test and ANOVA**
![[Pasted image 20250618125216.png|600]]

### **Test for total homogeneity**
![[Pasted image 20250618125241.png|600]]

****
## **Residual analysis**

>[!info]
>
>![[Pasted image 20250618125312.png|600]]

>[!definition]+ Standardized residuals
>Standardized residuals are defined as
>![[Pasted image 20250618125338.png]]

>[!definition]+ 9.39 Studentized residuals
>![[Pasted image 20250618125428.png|600]]

>[!theorem]+ 9.40 Distribution of studentized residuals
>![[Pasted image 20250618125454.png|600]]

>[!example]+ 9.41 Temperature anomali
>
>The standardized and Studentized residuals can be calculated in Python by
>
>``` python
>n = len(GlobalTemp["Year"]) 
>X = np.array([np.repeat(1,n), GlobalTemp["Year"]]).T 
>H = X @ np.linalg.inv(X.T @ X) @ X.T 
>
>h = H.diagonal(0) 
>r = fitTemp.resid 
>sigma = np.sqrt(fitTemp.scale) 
>rstandard = r / (sigma * (np.sqrt(1 - h))) 
>rstudent = fitTemp.outlier_test() 
>
>rstudent
>```
>
>![[Pasted image 20250618125606.png|350]]
>
>The outlier_test method include p-values for each of the residuals, either based directly on the t-distribution of a Bonferroni adjusted version (in this case we do 174 tests). Here we focus on the visual inspection, implying residual vs. fitted and qq-plot of the residuals
>
># Graph
>
>``` python
>ypred = fitTemp.predict(GlobalTemp) 
>fig, ax = plt.subplots(1,2)
>fig = sm.qqplot(rstudent["student_resid"], stats.t, distargs=(174-2-1,),line="q",a=1/2,ax=ax[0])
>
>ax[0].set_title("Q-Q plot - Studentized res.") 
>ax[1].scatter(ypred, rstandard) 
>ax[1].set_xlabel("Fitted values") 
>ax[1].set_ylabel("Standardized Residuals") 
>ax[1].set_title("Residuals vs Fitted values") 
>plt.tight_layout() 
>plt.show()
>```
>![[Pasted image 20250618125906.png|600]]
>
>It is clear that the fit is not satisfactory, the Studentized residual does not follow a t-distribution with 171 degrees of freedom and is seems that at least a quadratic term is needed.

>[!important]
>Studentized are hence more suited for QQ-plots.

****
### **Influencial observations**
![[Pasted image 20250618125959.png|600]]

>[!example]+ 9.42 Temperature anomali
>
>The leverage corresponding to the explanatory variable (year) in the temperature data is plotted below (left). We see that the leverage is smaller for observation close to the center of the observed explanatory variables and somewhat higher at the endpoints in the interval. The right plot is constructed imagining we have an observation of the temperature anomaly in year 1700, this is a quite extreme value compared to the other observed years, and resulting in a very high leverage, and hence an observation there would have the potential to greatly influence the model.
>
>![[Pasted image 20250618130037.png|600]]

****
## **Multicollinarity**

>[!example]+ Perfect collinearity
>![[Pasted image 20250618130129.png|600]]

>[!example]+ 9.43 An ill-conditioned problem
>
>To illustrate the multicollinarity problem consider the data
>
>![[Pasted image 20250618130209.png|600]]
>
>x1, x2, and x3 are constructed such that the average of each of them is zero, and hence the correlation between (not to be confused with the correlation between the parameters) them can be calculate by
>
>![[Pasted image 20250618130222.png|600]]
>
>here there are no very strong correlation, however the condition number is
>![[Pasted image 20250618130235.png|600]]
>
>which is extremely large. In this case the result of Type I and Type III partitioning of variation will also be very different.
>
>![[Pasted image 20250618130247.png|600]]
>
>hence we see that from the Type I analysis we should remove x3 (because it was entered last), while the Type III analysis show that we can actually remove any of the 3 regressors.

>[!note]
>The example illustrate that there might be big differences in conclusion depending on the chosen partitioning and a natural question is if there are situations where conclusions is aligned, the answer is given in the next theorem.

>[!theorem]+ 9.44 Orthogonal parameters and and partioning
>
>With an orthogonal parametrization (see Definition 9.25) then Type I and Type III partitioning is equivalent.

****
## **Polynomial and basis function regression**

>[!info]
>
>![[Pasted image 20250618130503.png|600]]
>
>![[Pasted image 20250618130548.png|600]]

>[!example]+ 9.45 Temperature anomali
>
>The analysis in Example 9.41 suggest that at least a quadratic term should be included. As a starting point we might included a forth order polynomial, in the summary below pj_raw is short for (Yeari/max(Year))j , from the partial t-test it seems that none of coefficient are significant. However it is also clear from the test of total homogeneity that at least one of the terms are significant. Further it is noted in the summary that the smallest eigenvalue is 2 · 10−e13 indicating very strong multicollinarity.
>
>![[Pasted image 20250618130622.png|600]]
>
>In addition to the notes made above we also see very large coefficient (the output is plus minus a few degrees and the coefficient are above 104 ). Of course we can in this case just check third and second degree order polynomials
>
>![[Pasted image 20250618130658.png|600]]

>[!important]
>
| **Term**     | **Estimate**     | **Standard Error** | **t-statistic**                        | **p-value**                            | **95% Confidence Interval**               |
|--------------|------------------|--------------------|----------------------------------------|----------------------------------------|-------------------------------------------|
| Intercept    | $\beta_0$        | $SE_0$             | $t_0 = \frac{\beta_0}{SE_0}$           | $P_0 = P(\vert T \vert > \vert t_0 \vert)$ | $[\beta_0 \pm t^* SE_0]$                   |
| $x$          | $\beta_1$        | $SE_1$             | $t_1 = \frac{\beta_1}{SE_1}$           | $P_1 = P(\vert T \vert > \vert t_1 \vert)$ | $[\beta_1 \pm t^* SE_1]$                   |
| $x^2$        | $\beta_2$        | $SE_2$             | $t_2 = \frac{\beta_2}{SE_2}$           | $P_2 = P(\vert T \vert > \vert t_2 \vert)$ | $[\beta_2 \pm t^* SE_2]$                   |

### **Construction of orthogonal polynomials**
>[!example]+ 9.46 Temperature anomali
>![[Pasted image 20250618130800.png|600]]
>
>The result of fitting the 4’th order orthogonal polynomials to data is given in the summary table below, the overall statistics (test for total homogeneity, and R 2 ) are the same, but we can now directly from the output see that the 3’rd order polynomial should be included (using the usual 5%) level, but that the 4’th order should not. Also the extreme values of the parameters are no longer present.
>
>![[Pasted image 20250618130812.png|600]]
>
>For completeness we include a more complete residual and model analysis of the final 3’rd order polynomial regression model. The figure below show that the model follow the data quite well, and there are no systematic behavior in the standardized residuals vs. fitted values (of course there are many observations of small fitted values, but that is the nature of data). Also the qq-plot of Studentized residuals does not raise any concerns, there is one quite large Studentized residual of about 4, which is caused by the unusually high temperature around the year 1880. The last plot is used for assessing the independence assumption and is based on the standardized residuals. The data is given as a time-series and therefore it is reasonable to check the correlation between observations at time t and time t + 1, even though weak there seem to be some positive temporal correlation in the residuals.
>
>![[Pasted image 20250618130832.png|600]]
>
>For a more precise statement on the correlation between $r^{rs}_i$ i and $r^{rs}_{i+1}$ we can calculate it in Python by
>
>![[Pasted image 20250618130921.png|600]]
>
>hence an estimated correlation of about 0.234, which by (9-130) (on page 31), should be compared with a N(0, 1/(n − 1)) distribution, the resulting test statistics is z = 0.234/√ 1/173 = 3.08, and hence there is a significant autocorrelation in the residuals. Even though there is a significant autocorrelation it is small in this case and not expected to affect the estimation results greatly in this case.



