>[!example]+ 6.15 Residuals analysis
>
>Consider the model in the Python script below, the true model is
>$$y_i = x_1 + 2x_2^2 + ε_i$$, $$εi ∼ N(0, 0.125^2)$$
>
>in a real application the true model is of course hidden to us and we would start by a multiple linear model with the two effects x1 and x2. Looking at the plots below also suggests that this might be a good model:
>
>``` python
>np.random.seed(200) 
>n = 100
>x1 = np.random.uniform(size = n) 
>x2 = np.random.uniform(size = n) 
>y = x1 + 2*x2**2 + + np.random.normal(0, 0.125,size=n) 
>
>df_sim = pd.DataFrame({’y’: y,’x1’ : x1, ’x2’ : x2}) 
>
>fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(8,4)) 
>ax1.scatter(x1,y) 
>ax2.scatter(x2,y)
>```
>
>![[Pasted image 20250618131853.png|600]]
>
>``` python
>fit_sim = smf.ols(formula = ’y ~ x1 + x2’, data = df_sim).fit()
>res = y - fit_sim.fittedvalues 
>fig, (ax1, ax2, ax3) = plt.subplots(1, 3, figsize=(8,4)) 
>
>ax1.scatter(fit_sim.fittedvalues,res) 
>ax2.scatter(x1,res) ax3.scatter(x2,res)
>```
>
>![[Pasted image 20250618131945.png|600]]
>
>The left plot does however not suggest where the dependence comes from. Now looking at the residuals as a function of x1 and x2 (centre and left plot) reveal that the residuals seem to be quadratic in x2, and we should therefore include x 2 2 in the model
>
>``` python
>x3 = x2**2 
>df_sim = pd.DataFrame({’y’: y,’x1’ : x1, ’x2’ : x2,’x3’: x3}) 
>fit_sim = smf.ols(formula = ’y ~ x1 + x2 +x3’, data = df_sim).fit() 
>res = y - fit_sim.fittedvalues 
>
>fig, (ax1, ax2, ax3) = plt.subplots(1, 3, figsize=(8,4)) 
>ax1.scatter(fit_sim.fittedvalues,res) 
>ax2.scatter(x1,res) ax3.scatter(x2,res)
>```
>
>![[Pasted image 20250618132044.png|600]]
>![[Pasted image 20250618132053.png|600]]

