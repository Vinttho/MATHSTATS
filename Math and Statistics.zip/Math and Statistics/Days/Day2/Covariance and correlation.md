>[!note]
>In this chapter we have discussed mean and variance (or standard deviation),
and the relation to the sample mean and sample variance, see Section 2.2.2. In
Chapter 1 Section 1.4.3 we discussed the sample covariance and sample correla-
tion, these two measures also have theoretical justification, namely covariance
and correlation, which we will discuss in this section. We start by the definition
of covariance.

>[!definition]+ Covariance
>
>![[Pasted image 20250606092159.png|600]]

>[!important]+ Remark
>![[Pasted image 20250606092217.png|600]]

An important concept in statistics is independence (see Section 2.9 for a formal
definition). We often assume that realizations (random variables) are indepen-
dent. If two random variables are independent then their covariance will be
zero, the reverse is however not necessarily true (see also the discussion on
sample correlation in Section 1.4.3).
The following calculation rule apply to covariance between two random variables X and Y:

>[!definition]+ Theorem, Covariance between linear combinations
>
>![[Pasted image 20250606092309.png|600]]

>[!example]
>![[Pasted image 20250606092329.png|600]]

>[!definition]+ Correlation
>
>![[Pasted image 20250606092535.png|600]]

>[!important]+ Remark
>The correlation is a number between -1 and 1

>[!example]
>
>![[Pasted image 20250606092643.png|600]]

