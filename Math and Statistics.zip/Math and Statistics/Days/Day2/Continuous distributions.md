## Uniform distribution

>[!info]
>A **uniform distribution** is a type of probability distribution where **every outcome in a specific range is equally likely**.
>
>The term **"equal density"** means that the **probability density function (PDF)** is constant across the interval.
>
>Imagine rolling a fair die with outcomes from 1 to 6. Each number has an equal chance (1/6) of occurring. That’s a **discrete** uniform distribution. The **continuous** version is like picking a real number at random from the interval [0, 1], where any subinterval of equal length is equally likely to contain the value.

>[!definition]+ Uniform distribution
>
>![[Pasted image 20250606082843.png|600]]

>[!definition]+ Mean and variance of the uniform distribution
>
>![[Pasted image 20250606082944.png|600]]
### Figure:
![[Pasted image 20250606083002.png|600]]

****
## **Normal Distribution**

>[!info]
>
>Also called the Gaussian distribution, and is used in extremely
many applications

>[!definition]+ Normal distribution
>
>![[Pasted image 20250606083141.png|600]]

>[!definition]+ Mean and variance
>
>The mean of a Normal distributed random variable is
>$$μ$$
>and the variance is
>$$σ2$$
>Hence simply the two parameters defining the distribution.

>[!example]+ The normal pdf
>
>``` python
># Play with the normal distribution
># The mean and standard deviation
>muX = 0
>sigmaX = 1 # σ
>
># A sequence of x values
>xSeq = np.arange(-6, 6.1, 0.1)
>
>##
>pdfX = 1/(sigmaX*np.sqrt(2*np.pi)) * np.exp(-(xSeq-muX)**2/(2*sigmaX**2))
>
># Plot the pdf
>plt.plot(xSeq, pdfX)
>plt.ylabel(’f(x)’)
>```
>
>![[Pasted image 20250606083556.png|600]]

>[!definition]+ Linear combinations of normal random variables
>
>![[Pasted image 20250606084037.png|600]]

>[!example]
>Consider wo normal distributed random variables
>
>![[Pasted image 20250606084105.png|600]]

****
## **Standard normal distribution**

>[!definition]+ Standard normal distribution
>
>The standard normal distribution is the normal distribution with zero mean and unit variance
>$$Z ∼ N(0, 1),$$
>where Z is the standardized normal random variable.

> [!definition] Theorem, Transformation to the standardized normal random variable
> 
> A normal distributed random variable X can be transformed into a standardized normal random variable by
> $$Z = \frac{X - μ}{σ}$$

>[!example]+ Quantiles in the standard normal distribution
>
>The most used quantiles (or percentiles) in the standard normal distribution are
>![[Pasted image 20250606084527.png|600]]

>[!note]
>Note that the values can be considered as standard deviations (i.e. for **Z** the standardized normal then **σZ = 1**), which holds for any normal distribution. The most used quantiles are marked on the plot

>[!example]
>![[Pasted image 20250606084614.png||600]]

>[!note]
>Note that the units on the x-axis is in standard deviations.

****
## Normal pdf details
>[!note]
>
>Normal pdf details:
>In order to get insight into how the normal distribution is formed consider the following steps. In Figure 2.4 the result of each step is plotted:
>
>1. Take the distance to the mean: **x − μ**
>2. Square the distance: **(x − μ)^2**
>3. Make it negative and scale it: $\frac{-(x-μ)^2}{2*σ^2}$
>4. Take the exponential: $e^{\frac{-(x-μ)^2}{2*σ^2}}$
>5. Finally, scale it to have an area of one: $\frac{1}{σ*\sqrt{2*\pi}}*e^{\frac{-(x-μ)^2}{2*σ^2}}$

![[Pasted image 20250606085139.png|600]]

>[!example]+ Python functions for the normal distribution
>In Python functions to generate values from many distributions are implemented. For the normal distribution the following functions are available
>``` python
># Do it for a sequence of x values
xSeq = np.arange(-3, 4)
># The pdf
stats.norm.pdf(xSeq, 0, 1)
array([0.004, 0.054, 0.242, 0.399, 0.242, 0.054, 0.004])
># The cdf
stats.norm.cdf(xSeq, 0, 1)
array([0.001, 0.023, 0.159, 0.500, 0.841, 0.977, 0.999])
># The quantiles
stats.norm.ppf([0.01,0.025,0.05,0.5,0.95,0.975,0.99], 0, 1)
array([-2.326, -1.960, -1.645, 0.000, 1.645, 1.960, 2.326])
># Generate random normal distributed realizations
stats.norm.rvs(0, 1, size=10)
array([-1.043, 0.050, -0.592, -0.840, 0.460, 0.150, 0.021, -1.221,
-0.638, -1.024])
># Calculate the probability that the outcome of X is between a and b
a = 0.2
b = 0.8
stats.norm.cdf(b, 0, 1) - stats.norm.cdf(a, 0, 1)
np.float64(0.20888489197750038)
># See more details in online documentation for scipy.stats.norm
>```

****
### **Log-Normal distribution**
If a random variable is log-normal distributed then its logarithm is normally
distributed.

>[!definition]+ Log-Normal distribution
>
>![[Pasted image 20250606085511.png|600]]

>[!definition]+ Theorem, Mean and variance of log-normal distribution
>
>![[Pasted image 20250606085533.png|600]]

The log-normal distribution occurs in many fields, in particular: biology, finance and many technical applications

>[!definition]+ Exponential distribution
>![[Pasted image 20250606085619.png|600]]

>[!definition]+ Theorem, Mean and variance of exponential distribution
>
>![[Pasted image 20250606085652.png|600]]

>[!example]+ Exponential distributed time intervals
>Simulate a so-called Poisson process, which has exponential distributed time interval between events
>``` python
># Simulate exponential waiting times
># The rate parameter: events per time
>lamb = 4
># Number of realizations
>n = 1000
># Simulate
>wait_times = stats.expon.rvs(loc=0, scale=1/lamb, size=n)
># The empirical pdf
>plt.hist(wait_times, density=True)
># Add the pdf to the plot
>x = np.arange(0,1.4,0.01)
>plt.plot(x, stats.expon.pdf(x, loc=0, scale=1/lamb), color=’red’) 
>plt.show()
>```
>![[Pasted image 20250606085831.png|600]]
>
>Furthermore check that by counting the events in fixed length intervals that they
follow a Poisson distribution.
>``` python
># Check the relation to the Poisson distribution
># by counting the events in each interval
># Sum up to get the running time
running_times = np.cumsum(wait_times)
># Use the hist function to count in intervals between the breaks,
># here 0,1,2,...
counts, bin_edges = np.histogram(running_times, bins=np.arange(np.ceil(running_times.ma
plt.bar(np.arange(len(np.bincount(counts))), np.bincount(counts)/len(counts),color=’black'))
># Add the Poisson pdf to the plot
poisson_pmf = stats.poisson.pmf(np.arange(0, 16), lamb)
>plt.bar(np.arange(0, 16), poisson_pmf, color=’red’, width=0.1, label=’pdf’)
>```
>![[Pasted image 20250606090139.png|600]]

![[Pasted image 20250606090251.png|600]]

>[!danger]+ Continuous distributions : overview
>
>![[Pasted image 20250606092445.png|600]]

