
## **Continuous random variables**
If an experiment or problem poses a an outcome where it takes a continuous value, for example a weight and distance a temperature, precipitations. Then we use a continuous random variable

>[!definition]+ Density and probabilities
>
>![[Pasted image 20250606081316.png|600]]

> [!warning]
> The probability for a continuous random variable to be realized at a single
> number P(X = x) is zero.
### **Normal Distribution**
![[Pasted image 20250606081420.png|600]]

>[!definition]+ Distribution
>![[Pasted image 20250606081526.png|600]]
>
>We have the relation between the cdf and pdf is:
>
>$P(a < X ≤ b) = F(b) − F(a) = \int_a^b f(x)dx,$
>
>Therefore the pdf becomes the derivative of cdf:
>
>$f(x) = \frac{d}{dx}*F(x)$

### Probability of the specified outcome
![[Pasted image 20250606081939.png|600]]
>[!info]
>The probability of observing the outcome of X in the range between
a and b is the distance between F(a) and F(b).

****
## **Mean and Variance**

>[!definition]+ Mean and variance
>
>![[Pasted image 20250606082110.png|600]]

>[!info]
>
>The differences between the discrete and the continuous case can be summed up in two points:
>- In the continuous case integrals are used, in the discrete case sums are used.
>- In the continuous case the probability of observing a single value is always zero. In the discrete case it can be positive or zero

