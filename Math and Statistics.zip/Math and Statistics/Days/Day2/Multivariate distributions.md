We will focus the multivariate normal distribution, but start by some general
definitions and results, related to multivariate distributions.

>[!definition]+ Multivariate probability density functions
>
>![[Pasted image 20250606093748.png|600]]

>[!example]
>
>![[Pasted image 20250606094138.png|600]]
>
>$\int_0^1 * \int k*y_1*y_2$ $dy_1dy_2$
>$k*\int y_1 * \int *y_2$  $dy_2dy_1$
>$-> \frac{k}{4} => k=4$
>
>$f_y1 = 4 * \int y_1 * y_2$ $dy2 = 4*y_1 * 1/2 = 2y_1$ 
>$f_y2 = ... = 2y_2$

The density function is the fundamental property of a random variable that
describe everything about the random variable, here we are mostly interested
in the second order moment representation (mean, variance and covariance).

>[!definition]+ Second order moment representation
>
>![[Pasted image 20250606093816.png|600]]

>[!note]
>
>![[Pasted image 20250606093830.png|600]]

>[!definition]+ Theorem, Covariance calculation rules
>
>![[Pasted image 20250606093853.png|600]]

In addition to the second order moment representation, independence is a very
important concept in statistics, the formal definition is:

>[!definition]+ Independence of random vectors
>
>![[Pasted image 20250606093923.png|600]]

>[!note]
>
>The definition imply that if Y1 and Y2 are independent then Cov[Y1, Y2] = 0.
In general the opposite is not true (i.e. no correlation does not imply indepen-
dence).
Section 9.3.1 below consider the matrix formulation of error propagation. It is
not used in the further development but included for completeness of matrix
formulations.
