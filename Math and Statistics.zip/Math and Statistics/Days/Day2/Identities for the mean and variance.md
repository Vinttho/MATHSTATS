>[!info]
>Rules for calculation of the mean and variance of linear combinations of in-
dependent random variables are introduced here. They are valid for both the
discrete and continuous case.

>[!definition]+ Theorem, Mean and variance of linear functions
>
>![[Pasted image 20250606091659.png|600]]

Random variables are often scaled (i.e. **aX**) for example when shifting units:

>[!example]
>![[Pasted image 20250606091725.png|600]]

>[!definition]+ Theorem, Mean and variance of linear combinations
>
>![[Pasted image 20250606091801.png|600]]

>[!example]
>
>![[Pasted image 20250606092055.png|600]]
>
>This is simply because when applying the sum to many random outcomes, then
the high and low outcomes will even out each other, such that the variance will be
smaller for a sum than for a scaling

