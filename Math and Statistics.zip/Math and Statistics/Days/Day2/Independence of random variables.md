>[!note]
>In statistics the concept of independence is very important, and in order to
give a formal definition of independence we will need the definition of two-
dimensional random variables. The probability density function of a two-dimensional
discrete random variable, called the joint probability density function, is,

>[!definition]+ Joint **pdf** of two-dimensional discrete random variables
>
>The pdf of a two-dimensional discrete random variable **[X, Y]** is
>![[Pasted image 20250606092808.png|600]]

>[!important]+ Remark
>
>**P(X = x, Y = y)** should be read: the probability of **X = x** and **Y = y**.

>[!example]
>Imagine two throws with an fair coin: the possible outcome of each throw is either
head or tail, which will be given the values 0 and 1 respectively. The complete set of
outcomes is (0,0), (0,1), (1,0), and (1,1) each with probability 1/4. And hence the pdf
>is
>
>![[Pasted image 20250606092923.png|600]]

**The formal definition of independence for a two dimensional discrete random
variable is**

>[!definition]+ Independence of discrete random variables
>
>Two discrete random variables **X** and **Y** are said to be independent if and
>only if
>
>**P(X = x, Y = y) = P(X = x)P(Y = y)**

>[!example]
>
>![[Pasted image 20250606093044.png|600]]
>

>[!example]
>
>![[Pasted image 20250606093059.png|600]]
>![[Pasted image 20250606093107.png|600]]

>[!important]+ Remark
>In the example above it is quite clear that **X** and **Z** cannot be independent.
In real applications we do not know exactly how the outcomes are realized
and therefore we will need to assume independence (or test it).

**To be able to define independence of continuous random variables, we will need
the pdf of a two-dimensional random variable:**

>[!definition]+ **Pdf** of two dimensional continuous random variables
>
>![[Pasted image 20250606093257.png|600]]

Just as for one-dimensional random variables the probability interpretation is
in form of integrals
![[Pasted image 20250606093320.png]]
where A is an area.

>[!example]+ Bivariate normal distribution
>
>![[Pasted image 20250606093443.png|600]]

>[!definition]+ Independence of continous random variables
>
>![[Pasted image 20250606093506.png|600]]

>[!definition]+ Properties of independent random variables
>
>![[Pasted image 20250606093526.png|600]]

>[!important]+ Remark
>
>Note that **Cov(X, Y) = 0** does not imply that **X** and **Y** are independent.
However, if X and Y follow a bivariate normal distribution, then if **X** and **Y**
are uncorrelated then they are also independent.
