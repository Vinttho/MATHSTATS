>[!note]
>The basic concept of simulation was introduced in Section 2.2.1 and we have al-
ready applied the in-built functions in Python for generating random numbers
from any implemented distribution, see how in Section 2.3.1. In this section it
is explained how realizations of a random variable can be generated from any
probability distribution – it is the same technique for both discrete and contin-
uous distributions.
Basically, a computer obviously cannot create a result/number, which is ran-
dom. A computer can give an output as a function of an input. (Pseudo) ran-
dom numbers from a computer are generated from a specially designed algo-
rithm - called a random number generator, which once started can make the
number xi+1 from the number xi. The algorithm is designed in such a way that
when looking at a sequence of these values, in practice one cannot tell the dif-
ference between them and a sequence of real random numbers. The algorithm
needs a start input, called the “seed”, as explained above Remark 2.12. Usually,
you can manage just fine without having to worry about the seed issue since
the program itself finds out how to handle it appropriately. Only if you want to
be able to recreate exactly the same results you need to set seed value.
Actually, a basic random number generator typically generates (pseudo) ran-
dom numbers between 0 and 1 in the sense that numbers in practice follow the
uniform distribution on the interval 0 to 1, see Section 2.35. Actually, there is a
simple way how to come from the uniform distribution to any kind of distribu-
tion:

>[!definition]+ Theorem, 
>
>![[Pasted image 20250606090521.png|600]]

>[!example]+ Random numbers in Python
>
>We can generate 100 normally distributed N(2, 32) numbers similarly the following
>two ways:
>
>``` python
># Generate 100 normal distributed values
random_numbers = stats.norm.rvs(loc=2, scale=3, size=100)
># Similarly, generate 100 uniform distributed values from 0 to 1 and
># # put them through the inverse normal cdf
uniform_random_numbers = stats.uniform.rvs(loc=0, scale=1, size=100)
stats.norm.ppf(uniform_random_numbers, loc=2, scale=3)
>```

>[!example]+ Simulating the exponential distribution
>
>![[Pasted image 20250606090658.png|600]]
>
>``` python
># Three equivalent ways of simulating the exponential distribution
># with lambda=1/2
re1 = -2*np.log(1-stats.uniform.rvs(loc=0, scale=1, size=10000))
re2 = stats.expon.ppf(stats.uniform.rvs(loc=0, scale=1, size=10000), loc=0, scale=2)
re3 = stats.expon.rvs(loc=0, scale=2, size=10000)
># Check the means and variances of each
print(re1.mean(), re2.mean(), re2.mean())
2.0039553521283056 1.9948804494574823 1.9948804494574823
print(re1.var(), re2.var(), re2.var())
3.89520722053301 3.7967058951210935 3.7967058951210935
>```
>
>This can be illustrated by plotting the distribution function (cdf) for the exponential
>distribution with λ = 1/2 and 5 random outcome
>
>![[Pasted image 20250606090747.png|600]]

>[!note]
>But since Python has already done all this for us, we do not really need this
as long as we only use distributions that have already been implemented in
Python

>[!important]
>
>**cdf** is the inverse of **ppf**. Meaning if **cdf(2) = 0.97725** then **ppf(0.97725) = 2**
>Example:
>If you have a normal distribution and you want to find the value below which 95% of the data falls, you would use the PPF to find that value. 
>In Python:
>You can find the PPF using the `ppf()` function in libraries like `scipy.stats`. For example, `scipy.stats.norm.ppf(0.95)` would return the 95th percentile of the standard normal distribution



