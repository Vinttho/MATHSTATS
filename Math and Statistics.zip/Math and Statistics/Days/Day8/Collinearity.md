>[!example]+ 6.13, Simulation
>
>![[Pasted image 20250617185723.png|600]]
>
>![[Pasted image 20250617185742.png|600]]
>
>![[Pasted image 20250617185749.png|600]]

