![[Pasted image 20250617185828.png|600]]

****
# Matrixformulation

>[!theorem]+ 6.17
>
>![[Pasted image 20250617185901.png|600]]

![[Pasted image 20250617185921.png|600]]

