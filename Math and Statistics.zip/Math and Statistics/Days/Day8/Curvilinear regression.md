>[!example]+ 6.11, Simulation of non-linear model
>
>![[Pasted image 20250617185612.png|600]]
>
>![[Pasted image 20250617185629.png|600]]

>[!note]
>
>In general one should be careful when extrapolation models into areas wherethere is no data, and this is in particular true when we use curvilinear regression.



