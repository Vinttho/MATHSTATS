## Chapter 5: Simple Linear Regression (Sections 5.1–5.6)

---

## 5.1 Linear Regression and Least Squares

 >[!info] Introduction
>
Linear regression is about modeling a relationship between a known input $x$ and an observed outcome $y$. We assume that $y$ depends linearly on $x$, which gives us the model:
>
$y=β0+β1xy = \beta_0 + \beta_1 x$
>
But because real data has random variation, we add an error term $\varepsilon_i$:
>
$Yi=β0+β1xi+εiY_i = \beta_0 + \beta_1 x_i + \varepsilon_i$
>
Where:
>
>- $Y_i$ is the outcome
 >   
>- $x_i$ is the input
>    
>- $\beta_0$ is the intercept
  >  
>- $\beta_1$ is the slope
  >  
>- $\varepsilon_i$ is the random error with $E(\varepsilon_i) = 0$ and $Var(\varepsilon_i) = \sigma^2$
>    

The goal is to estimate $\beta_0$ and $\beta_1$ using observed data.

 >[!example] Example 5.1: Car Fuel Consumption
>
A car manufacturer models fuel consumption ($y$) based on speed ($x$):
>
$Yi=β0+β1xi+εiY_i = \beta_0 + \beta_1 x_i + \varepsilon_i$
>
Speed is controlled. Fuel consumption varies with speed and other factors (like weather). The variation not explained by the model is captured by $\varepsilon_i$.

 >[!definition] Residual Sum of Squares (RSS)
>
To find the best fitting line, we minimize the total squared errors:
>
>$$RSS(β0,β1)=∑i=1n(Yi−(β0+β1xi))2RSS(\beta_0, \beta_1) = \sum_{i=1}^n (Y_i 
> -(\beta_0 + \beta_1 
> x_i))^2$$
>
The best estimates $\hat{\beta}_0$, $\hat{\beta}_1$ are the values that minimize this.

---

## 5.2 Parameter Estimates and Estimators

 >[!theorem] Theorem 5.4: Least Squares Estimators
>
>$$β^1=∑i=1n(Yi−Yˉ)(xi−xˉ)∑i=1n(xi−xˉ)2=SxySxx,β^0=Yˉ−β^1xˉ\hat{\beta}_1 = 
>\frac{\sum_{i=1}^n (Y_i - \bar{Y})(x_i - \bar{x})}{\sum_{i=1}^n (x_i - \bar{x})^2} = 
>\frac{S_{xy}}{S_{xx}}, \quad \hat{\beta}_0 = \bar{Y} - \hat{\beta}_1 \bar{x}$$
>
Where $S_{xx} = \sum (x_i - \bar{x})^2$.


 >[!example] Example 5.5: Student Height and Weight
>
**Data:**
>
>- Heights ($x$): 168, 161, ..., 179
>    
>- Weights ($y$): 65.5, 58.3, ..., 78.9
 >   
>
**Computed:**
>
>- $\bar{x} = 178$, $\bar{y} = 78.11$, $S_{xx} = 1342$
>    
>- $\hat{\beta}_1 = 1.11$, $\hat{\beta}_0 = -120$
 >   
>
>So the regression line is:
>
$y^i=−120+1.11xi\hat{y}_i = -120 + 1.11 x_i$

>[!definition] Estimates vs Estimators
>
>- **Estimators**: Functions of random variables $Y_i$ before the data is collected.
  >  
>- **Estimates**: Numerical values after observing $y_i$.
   > 

---

## 5.2.1 Estimators are Central

>[!info] What Does "Central" Mean?
>
An estimator $\hat{\beta}_i$ is **unbiased** if its expected value equals the true value:
>
$E[β^1]=β1,E[β^0]=β0E[\hat{\beta}_1] = \beta_1, \quad E[\hat{\beta}_0] = \beta_0$
>

>[!theorem] Proof Idea
>
From the formula of $\hat{\beta}_1$, substitute the model $Y_i = \beta_0 + \beta_1 x_i + \varepsilon_i$ and use $E(\varepsilon_i) = 0$.

---

## 5.3 Variance of Estimators

>[!theorem] Theorem 5.8: Variance Formulas
>
>$$Var[β^0]=σ2(1n+xˉ2Sxx),Var[β^1]=σ2Sxx,Cov[β^0,β^1]=−xˉσ2SxxVar[\hat{\beta}_0] = \sigma^2 \left(\frac{1}{n} + \frac{\bar{x}^2}{S_{xx}}\right), \quad Var[\hat{\beta}_1] = \frac{\sigma^2}{S_{xx}}, \quad Cov[\hat{\beta}_0, \hat{\beta}_1] = -\frac{\bar{x}\sigma^2}{S_{xx}}$$
>
Estimate error variance as:
>
$σ^2=∑(yi−y^i)2n−2=RSSn−2\hat{\sigma}^2 = \frac{\sum (y_i - \hat{y}_i)^2}{n - 2} = \frac{RSS}{n - 2}$
>

 >[!example] Example 5.9: Standard Errors
>
From Example 5.5:
>
>- $\hat{\beta}_0 = -120$, $\hat{\beta}_1 = 1.11$
   > 
>- Compute residuals $e_i = y_i - \hat{y}_i$
   > 
>- $\hat{\sigma} = 3.88$
   > 
>- Standard errors: $\hat{\sigma}_{\beta_0} = 18.9$, $\hat{\sigma}_{\beta_1} = 0.11$
   > 

---

## 5.4 Distribution and Testing of Parameters

>[!definition] Test Statistics (Theorem 5.12)
>
Test whether $\beta_i = \beta_{0,i}$:
>
$$Tβi=β^i−β0,iσ^βi∼t(n−2)T_{\beta_i} = \frac{\hat{\beta}_i - \beta_{0,i}}{\hat{\sigma}_{\beta_i}} \sim t(n - 2)$$

 >[!example] Example 5.13: Hypothesis Test
>
>- $t_{\beta_0} = -6.35$ (Reject $H_0: \beta_0 = 0$)
   > 
>- $t_{\beta_1} = 1.07$ (Do not reject $H_0: \beta_1 = 1$)
   > 


>[!definition] Confidence Intervals (Method 5.15)
>
CI for $βi:β^i±t1−α/2⋅σ^βi\text{CI for } \beta_i: \hat{\beta}_i \pm t_{1 - \alpha/2} \cdot \hat{\sigma}_{\beta_i}$

 >[!example] Example 5.17
>
>- 95% CI for $\beta_0$: $[-163.5, -76.4]$
>    
>- 95% CI for $\beta_1$: $[0.869, 1.36]$
  >  

 >[!definition] Prediction and Confidence Intervals for Line (Method 5.18)
>
For new $x_{new}$:
>
**Confidence Interval** (mean):
>
$$y^new±t1−α/2⋅σ^1n+(xnew−xˉ)2Sxx\hat{y}_{new} \pm t_{1 - \alpha/2} \cdot \hat{\sigma} \sqrt{\frac{1}{n} + \frac{(x_{new} - \bar{x})^2}{S_{xx}}}$$
>
**Prediction Interval** (single point):
>
$$y^new±t1−α/2⋅σ^1+1n+(xnew−xˉ)2Sxx\hat{y}_{new} \pm t_{1 - \alpha/2} \cdot \hat{\sigma} \sqrt{1 + \frac{1}{n} + \frac{(x_{new} - \bar{x})^2}{S_{xx}}}$$

![[Pasted image 20250618152959.png]]


---

## 5.5 Matrix Formulation

 >[!definition] Linear Regression in Matrix Form
\
$Y=Xβ+ε,ε∼N(0,σ2I)\mathbf{Y} = \mathbf{X} \boldsymbol{\beta} + \boldsymbol{\varepsilon}, \quad \boldsymbol{\varepsilon} \sim N(0, \sigma^2 I)$
\
**Estimator:**
\
$β^=(XTX)−1XTY\hat{\boldsymbol{\beta}} = (\mathbf{X}^T \mathbf{X})^{-1} \mathbf{X}^T \mathbf{Y}$
\
**Covariance:**
\
$Σ^β=σ^2(XTX)−1\hat{\Sigma}_\beta = \hat{\sigma}^2 (\mathbf{X}^T \mathbf{X})^{-1}$

>[!theorem]+ 5.23
>
>The estimators of the parameters in the simple linear regression model are given by
>![[Pasted image 20250618155913.png|600]]

>[!example]+ 5.24 Student height and weight
>
>To illustrate how the matrix formulation works in student height and weight data is worked through below:
>
>``` python
># Data 
>y = student[’y’] 
>n = len(student[’y’]) 
>X = np.array([np.repeat(1,n),student[’x’]]).T 
>
># Parameter estimates and variance 
>beta = np.linalg.inv(X.T@X)@X.T@y 
>e = y - X@beta 
>s = math.sqrt(np.sum(e**2) / (n - 2)) 
>Vbeta = s**2 * np.linalg.inv(X.T@X) 
>sbeta = np.sqrt(Vbeta.diagonal()) 
>Tstat = beta / sbeta 
>pval = 2 * (1 - stats.t.cdf(np.abs(Tstat), df = n-2)) 
>
># Print the results 
>coefMat = np.array([beta, sbeta, Tstat, pval]).T 
>col_names = ["Estimates","Std.Error","t.value","p.value"] 
>row_names = ["beta0", "beta1"] 
>coefMat = pd.DataFrame(coefMat,columns = col_names, index = row_names) 
>pd.set_eng_float_format(accuracy=3) 
>
>print(coefMat)
>```
>
>![[Pasted image 20250618160042.png|600]]

---

## 5.6 Correlation

 >[!definition] Sample Correlation Coefficient
>
$ρ^=1n−1∑i=1n(xi−xˉsx)(yi−yˉsy)\hat{\rho} = \frac{1}{n - 1} \sum_{i=1}^n \left(\frac{x_i - \bar{x}}{s_x}\right) \left(\frac{y_i - \bar{y}}{s_y}\right)$
>
Also:
>
$ρ^=sxsy⋅β^1\hat{\rho} = \frac{s_x}{s_y} \cdot \hat{\beta}_1$

 >[!definition] Coefficient of Determination ($R^2$)
>
$R2=1−∑(yi−y^i)2∑(yi−yˉ)2R^2 = 1 - \frac{\sum (y_i - \hat{y}_i)^2}{\sum (y_i - \bar{y})^2}$
>
Tells us the proportion of variation in $y$ explained by $x$.

>[!danger]
>
>**Explained Variation**
>Explained Variation is $R^2$, which is how straight the data points are on the graph line. If they are linearly on it is is 1, if they are completely off it is 0.
>
>**Correlation:**
>
>![[Pasted image 20250617192505.png|600]]



