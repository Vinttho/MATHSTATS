>[!theorem]+ 6.2, Hypothesis tests and confidence intervals
>![[Pasted image 20250617185049.png|600]]



>[!example]+ 6.3
>
>![[Pasted image 20250617185112.png|600]]
>
>``` python
># Read data 
>data = { ’x1’ : [0.083, 0.409, 0.515, 0.397, 0.223, 0.292, 0.584, 0.491, 0.923, 0.280, 0.772, 0.857, 0.758, 0.850, 0.409, 0.055, 0.578, 0.745, 0.886, 0.031], ’x2’ : [0.625, 0.604, 0.077, 0.414, 0.343, 0.202, 0.840, 0.266, 0.831, 0.385, 0.821, 0.308, 0.440, 0.865, 0.111, 0.970, 0.192, 0.939, 0.149, 0.318], ’y’ : [0.156, 1.234, 0.490, 1.649, 0.500, 0.395, 1.452, 0.416, 1.390, 0.234, 1.574, 0.349, 1.287, 1.709, 0.323, 1.201, 1.210, 1.787, 0.591, 0.110] } 
>df = pd.DataFrame(data)
>```
>
>``` python
># Parameter estimation 
>fit = smf.ols(formula = ’y ~ x1 + x2’, data = df).fit() 
>
># Summary of 
>fit (parameter estimates, standard error, p-values, etc.) 
>print(fit.summary(slim=True))
>```
>
>The interpretation of the output is exactly the same as in the simple linear regression. The first column gives the parameter estimates (βˆ 0, βˆ 1, βˆ 2), second column gives the standard error of the parameter estimates (σˆβ0 , σˆβ1 , σˆβ2 ), third column gives the tstatistics for the standard hypothesis H0,i : βi = 0, column four gives the p-value for the two-sided alternative, and finally columns 5-6 give 95% confidence intervals. We can therefore conclude that the effect of x1 and x2 are both significant on a 5% confidence level.

### Method 6.4 Level α t-tests for parameters
![[Pasted image 20250617185237.png|600]]

### Method 6.5 Parameter confidence intervals
![[Pasted image 20250617185255.png|600]]

### Remark 6.6 (On finding βˆ i and σβˆ i in methods 6.4 and 6.5)
![[Pasted image 20250617185337.png|600]]

>[!example]+ 6.7
>
>![[Pasted image 20250617185356.png|600]]

****
## Confidence and prediction intervals for the line

>[!example]+ 6.8
>
>![[Pasted image 20250617185436.png|600]]
>
>![[Pasted image 20250617185445.png|600]]
>
>![[Pasted image 20250617185454.png|600]]

![[Pasted image 20250617185507.png|600]]



