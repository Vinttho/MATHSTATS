>[!info]+ Intro:
>
>The simulation method called bootstrapping, which in practice is to simulate many samples, exists in two versions that can handle either of these two challenges:
>1- Parametric bootstrap: simulate multiple samples from the assumed distribution.
>2- Non-parametric bootstrap: simulate multiple samples directly from the data.
>
>As for the theoretical variance deduction above, there are indeed methods for doing such general theoretical derivations, which would make us able to do statistics based on any kind of assumed distribution. The most welknown, and in many ways also optimal, overall approach for this is called maximum likelihood theory.

****
## **One-sample confidence interval for µ**

>[!example]+ 4.6 Confidence interval for the exponential rate or mean
>
>Assume that we observed the following 10 call waiting times (in seconds) in a call center
>$$32.6, 1.6, 42.1, 29.2, 53.4, 79.3, 2.3, 4.7, 13.6, 2.0.$$
>
>If we model the waiting times using the exponential distribution, we can estimate the mean as
>$$\hat{µ} = \bar{x} = 26.08$$
>
>and hence the rate parameter λ = 1/β in the exponential distribution as (cf. 2.48)
>$$\hat{λ} = 1/26.08 = 0.03834356.$$
>
>However, what if we want a 95% confidence interval for either µ = β or λ? We have not been tought the methods, that is, given any formulas for finding this. The following few lines of Python-code, a version of the simulation based error propagation approach from above, will do the job for us:
>
>``` python
># Read the data 
>x = np.array([32.6, 1.6, 42.1, 29.2, 53.4, 79.3, 2.3 , 4.7, 13.6, 2.0]) 
>n = len(x) 
>rate = 1/x.mean() 
>
># Set the number of simulations
> k = 100000 
> 
> # 1. Simulate k samples each with n=10 observations from an 
> # exponential distribution with the estimated rate 
> simsamples = stats.expon.rvs(scale=1/rate, size=(k,n)) 
> 
> # 2. Compute the mean in each of the k samples 
> simsamples = pd.DataFrame(simsamples)
>  simmeans = simsamples.mean(axis=1) 
>  
>  # 3. Find the two relevant quantiles of the k generated means 
>  print(np.quantile(simmeans,[0.025,0.975], method=’averaged_inverted_cdf’)) 
>  
>  [12.575 44.563]
>```
>
>Explanation: we use stats.expon.rvs to generate 100.000 bootstrap samples each with 10 observations from an exponential distribution with the estimated mean value, and the results are collected in a 10 × 100.000 matrix. Then in a single call the 100.000 averages are calculated and subsequently the relevant quantiles found. So the 95%-confidence interval for the mean µ is (in seconds)
>
>$$[12.6, 44.6]$$
>
>And for the rate λ = 1/µ it can be found by a direct transformation (remember that the quantiles are ’invariant’ to monotonic transformations, c.f. Chapter 3)
>
>$$[1/44.6, 1/12.6] ⇔ [0.022, 0.0794].$$
>
>The simulated sampling distribution of means that we use for our statistical analysis can be seen with the histogram:
>
>``` python
># Histogram of the simulated means 
>plt.hist(simmeans, bins=30, edgecolor=’black’, color=’blue’, alpha=0.7) 
>plt.xlabel(’Means’) 
>plt.ylabel(’Frequency’) 
>plt.title(’Histogram of simulated means’) 
>
>plt.tight_layout() 
>plt.show()
>```
>
>![[Pasted image 20250623112355.png|600]]
>
>We see clearly that the sampling distribution in this case is not a normal nor a tdistribution: it has a clear right skewed shape. So n = 10 is not quite large enough for this exponential distribution to make the Central Limit Theorem take over.

****
## **One-sample confidence interval for any feature assuming any distribution**

>[!info]
>
>In the example above, we saw that it was easy to find a confidence interval for the rate λ = 1/µ when assuming an exponential distribution. This worked well because the rate is a simple, monotonic (always increasing or decreasing) function of the mean. As a result, the quantiles of the simulated rates were just straightforward transformations of the quantiles of the simulated means.
>
>But what if we’re interested in a statistic that isn’t a simple function of the mean—like the median, the coefficient of variation, the lower or upper quartile (Q1 or Q3), or the interquartile range (IQR = Q3 − Q1)?
>
>Fortunately, we can still apply a slightly modified version of the same method. To generalize this approach for any type of statistic, we use the Greek letter **θ** to represent a general characteristic of the distribution. For example, θ could be the true median of the population, and we use **$\hat{\theta}$** (theta-hat) to represent the estimate we calculate from the sample—like the sample median.

>[!method]+ 4.7 Confidence interval for any feature θ by parametric bootstrap
>
>Assume we have actual observations x1, . . . , xn and assume that they stem from some probability distribution with density (pdf) f :
>
>![[Pasted image 20250623112710.png|600]]

>[!note]
>Please note again, that you can simply substitute the θ with whatever statistics that you are working with. This then also shows that the method box includes the often occurring situation, where a confidence interval for the mean µ is the aim.

>[!example]+ 4.8 Confidence interval for the median assuming an exponential distribution
>
>Let us look at the exponential data from the previous section and find the confidence interval for the median:
>
>``` python
># Read the data 
>x = np.array([32.6, 1.6, 42.1, 29.2, 53.4, 79.3, 2.3 , 4.7, 13.6, 2.0]) 
>n = len(x) 
>rate = 1/x.mean() 
>
># Set the number of simulations 
>k = 100000 
>
># 1. Simulate k samples each with n=10 observations from an 
># exponential distribution with the estimated rate 
>simsamples = stats.expon.rvs(scale=1/rate, size=(k,n)) 
>
># 2. Compute the median in each of the k samples 
>simsamples = pd.DataFrame(simsamples) 
>simmedians = simsamples.median(axis=1) 
>
># 3. Find the two relevant quantiles of the k generated medians 
>print(np.quantile(simmedians,[0.025,0.975], method=’averaged_inverted_cdf’)) 
>
>[ 7.093 38.333]
>```
>
>The simulated sampling distribution of medians that we use for our statistical analysis can be studied by the histogram:
>
>``` python
># Histogram of the simulated medians 
>plt.hist(simmedians, bins=30, edgecolor=’black’, color=’blue’, alpha=0.7) 
>plt.xlabel(’Medians’) 
>plt.ylabel(’Frequency’) 
>plt.title(’Histogram of simulated medians’) 
>
>plt.tight_layout() 
>plt.show()
>```
>
>![[Pasted image 20250623112935.png|600]]
>
>We see again clearly that the sampling distribution in this case is not a normal nor a t-distribution: it has a clear right skewed shape.

>[!example]+ 4.9 Confidence interval for Q3 assuming a normal distribution
>
>Let us look at the heights data from the previous chapters and find the 99% confidence interval for the upper quartile: (Please note that you will find NO theory nor analytically expressed method boxes in the material to solve this challenge). We proceed like in the previous example:
>
>``` python
># Read the data 
>x = np.array([168, 161, 167, 179, 184, 166, 198, 187, 191, 179]) 
>n = len(x) 
>mu = x.mean() 
>sd = x.std(ddof=1) 
>
># Set the number of simulations 
>k = 100000 
>
># 1. Simulate k samples each with n=10 observations from a 
># normal distribution with the estimated parameters 
>simsamples = stats.norm.rvs(loc=mu, scale=sd, size=(k,n)) 
>
># 2. Compute the upper quartile in each of the k samples 
>simsamples = pd.DataFrame(simsamples) 
>
># A version using the quantile-function from Pandas. 
># Note: Pandas does not use our method of calculating quantiles. 
>simUQs = simsamples.quantile(0.75, axis=1) 
>
># A version using the quantile-function from NumPy. 
>simUQs = np.quantile(simsamples, 0.75, axis=1, method="averaged_inverted_cdf") 
>
># 3. Find the two relevant quantiles of the k generated medians 
>print(np.quantile(simUQs,[0.005,0.995],method=’averaged_inverted_cdf’)) 
>
>[173.481 199.813]
>```
>
>The simulated sampling distribution of upper quartiles that we use for our statistical analysis can be studied by the histogram:
>
>``` python
># Histogram of the simulated medians 
>plt.hist(simmedians, bins=30, edgecolor=’black’, color=’blue’, alpha=0.7) 
>plt.xlabel(’Medians’) 
>plt.ylabel(’Frequency’) 
>plt.title(’Histogram of simulated medians’) 
>
>plt.tight_layout() 
>plt.show()
>```
>
>![[Pasted image 20250623113159.png|600]]
>
>In this case the Q3 of n = 10 samples of a normal distribution appear to be rather symmetric and nicely distributed, so maybe one could in fact use the normal distribution, also as an approximate sampling distribution in this case.

****
## **Two-sample confidence intervals assuming any distributions**

>[!info]
>
>In this section we extend what we learned in the two previous sections to the case where the focus is a comparison between two (independent) samples. We present a method box which is the natural extensions of the method box from above, comparing any kind of feature (hence including the mean comparison):

>[!method]+ 4.10 Two-sample confidence interval for any feature comparison θ1 − θ2 by parametric bootstrap
>
>![[Pasted image 20250623113305.png|600]]

>[!note]
>a (Footnote: And otherwise chosen to match the data as good as possible: some distributions have more than just a single mean related parameter, e.g. the normal or the log-normal. For these one should use a distribution with a variance that matches the sample variance of the data. Even more generally the approach would be to match the chosen distribution to the data by the so-called maximum likelihood approach)

>[!example]+ 4.11 CI for the difference of two means from exponential distributed data
>
>Let us look at the exponential data from the previous section and compare that with a second sample of n = 12 observations from another day at the call center
>
>$$9.6, 22.2, 52.5, 12.6, 33.0, 15.2, 76.6, 36.3, 110.2, 18.0, 62.4, 10.3$$
>
>Let us quantify the difference between the two days and conclude whether the call rates and/or means are any different on the two days:
>
>``` python
># Read the data 
>x = np.array([32.6, 1.6, 42.1, 29.2, 53.4, 79.3, 2.3 , 4.7, 13.6, 2.0]) 
>y = np.array([9.6, 22.2, 52.5, 12.6, 33.0, 15.2, 76.6, 36.3, 110.2, 18.0, 62.4, 10.3]) 
>n1 = len(x) 
>n2 = len(y) 
>rate1 = 1/x.mean() 
>rate2 = 1/y.mean() 
>
># Set the number of simulations 
>k = 100000 
>
># 1. Simulate k samples each with n1=10 observations from an 
># exponential distribution with the estimate rate of X 
>simXsamples = stats.expon.rvs(scale=1/rate1, size=(k,n1))
> simXsamples = pd.DataFrame(simXsamples) 
> 
> # 2. Simulate k samples each with n2=12 observations from an 
> # exponential distribution with the estimated rate of Y 
> simYsamples = stats.expon.rvs(scale=1/rate2, size=(k,n2)) 
> simYsamples = pd.DataFrame(simYsamples) 
> 
> # 3. Compute the difference between the two simulated means - k times 
> simDifmeans = simXsamples.mean(axis=1) - simYsamples.mean(axis=1) 
> 
> # 4. Find the two relevant quantiles of the k generated differences in mean 
> print(np.quantile(simDifmeans,[0.025,0.975], method=’averaged_inverted_cdf’)) 
> 
> [-40.521 14.028]
>```
>
>Thus, although the mean waiting time was higher on the second day (y¯ = 38.24 s), the range of acceptable values (the confidence interval) for the difference in means is [−40.5, 14.0] – a pretty large range and including 0, so we have no evidence of the claim that the two days had different mean waiting times (nor call rates then) based on the current data. Let us, as in previous examples take a look at the distribution of the simulated samples. In a way, we do not really need this for doing the analysis, but just out of curiosity, and for the future it may give a idea of how far from normality the relevant sampling distribution really is:
>
>``` python
># Histogram of the simulated medians 
>plt.hist(simmedians, bins=30, edgecolor=’black’, color=’blue’, alpha=0.7) 
>plt.xlabel(’Medians’) 
>plt.ylabel(’Frequency’) 
>plt.title(’Histogram of simulated medians’) 
>
>plt.tight_layout() 
>plt.show()
>```
>
>![[Pasted image 20250623113600.png|600]]
>
>In this case the differences of means of exponential distributions appears to be rather symmetric and nicely distributed, so maybe one could in fact use the normal distribution, also as an approximate sampling distribution in this case.

>[!example]+ 4.12 Nutrition study: comparing medians assuming normal distributions
>
>Let us compare the median energy levels from the two-sample nutrition data from Example 3.46. And let us do this still assuming the normal distribution as we also assumed in the previous example. First we read in the data:
>
>``` python
># Read the data 
>xA = np.array([7.53, 7.48, 8.08, 8.09, 10.15, 8.4, 10.88, 6.13, 7.9]) 
>xB = np.array([9.21, 11.51, 12.79, 11.85, 9.97, 8.79, 9.69, 9.68, 9.19]) 
>nA = len(xA) 
>nB = len(xB)
>```
>
>Then we do the two-sample median comparison by the parametric, normal based, bootstrap:
>
>``` python
># Set the number of simulations 
>k = 100000 
>
># 1. Simulate k samples each with nA=9 observations from a 
># normal distribution with the estimate parameters for group A 
>simAsamples = stats.norm.rvs(loc=xA.mean(), scale=xA.std(ddof=1) , size=(k,nA))
> simAsamples = pd.DataFrame(simAsamples) 
> 
> # 2. Simulate k samples each with nB=9 observations from a 
> # normal distribution with the estimate parameters for group B 
> simBsamples = stats.norm.rvs(loc=xB.mean(), scale=xB.std(ddof=1) , size=(k,nB)) 
> simBsamples = pd.DataFrame(simBsamples) 
> 
> # 3. Compute the difference between the two simulated medians - k times 
> simDifmedians = simAsamples.median(axis=1) - simBsamples.median(axis=1) 
> 
> # 4. Find the two relevant quantiles of the k generated differences in medians 
> print(np.quantile(simDifmedians,[0.025,0.975], method=’averaged_inverted_cdf’)) 
> 
> [-3.617 -0.401]
>```
>
>Thus, we accept that the difference between the two medians is somewhere between 0.4 and 3.6, and confirming the group difference that we also found in the means, as the 0 is not included in the interval. Note the differences in the Python code compared to the previous bootstrapping example: we use the stats.expon.rvs-function instead of the stats.norm.rvsfunction and change the method from **.mean** to **.median**

>[!note]+ Remark, Hypothesis testing by simulation based confidence intervals
>
>We have also seen that even though the simulation method boxes given are providing confidence intervals: we can also use this for hypothesis testing, by using the basic relation between hypothesis testing and confidence intervals. A confidence interval includes the ’acceptable’ values, and values outside the confidence interval are the ’rejectable’ values.

****
****
