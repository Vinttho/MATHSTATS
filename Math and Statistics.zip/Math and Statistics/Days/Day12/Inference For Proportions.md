# **Categorical data**

Until now we have mainly focused on continuous outcomes such as the height of students. In many applications the outcome that we wish to study is categorical (7.1). For example, one could want to study the proportion of defective components in a sample, hence the outcome has two categories: “defect” and “non-defect”. Another example could be a study of the caffeine consumption among different groups of university students, where the consumption could be measured via a questionnaire in levels: none, 1-3 cups per day, more than 3 cups per day. Hence the categorical variable describing the outcome has three categories. In both examples the key is to describe the proportion of outcomes in each category

>[!info]+ Remark, 7.1
>A variable is categorical if each outcome belongs to a category, which is one of a set of categories.

****
# **Estimation of single proportions**

We want to be able to find estimates of the population category proportions (i.e. the “true” proportions). We sometimes refer to such a proportion as the probability of belonging to the category. This is simply because the probability that a randomly sampled observation from the population belongs to the category, is the proportion of the category in the population.

>[!example]+ 7.2
>
>In a survey in the US in 2000, 1154 people answered the question whether they would be willing to pay more for petrol to help the environment. Of the 1154 participants 518 answered that they would be willing to do so. Our best estimate of the proportion of people willing to pay more (p) is the observed proportion of positive answers
>
>![[Pasted image 20250623121114.png]]
>
>This means that our best estimate of the proportion of people willing to pay more for petrol to help the environment is 44.89%.

In the above example we can think of n = 1154 trials, where we each time have a binary outcome (yes or no), occurring with the unknown probability p. The random variable X counts the number of times we get a yes to the question, hence X follows a binomial distribution B(n, p) with the probability of observing x successes given by:
![[Pasted image 20250623121141.png|600]]
![[Pasted image 20250623121157.png|600]]

>[!method]+ 7.3, Proportion estimate and confidence interval
>
>The best estimate of the probability **p** of belonging to a category (the population proportion) is the sample proportion
>
>![[Pasted image 20250623121225.png|600]]

>[!info]+ Remark, 7.4
>
>As a rule of thumb the normal distribution is a good approximation of the binomial distribution if np and n(1 − p) are both greater than 15.

>[!example]+ 7.5
>
>In the figure below we have some examples of binomial distributions. When we reach a size where np ≥ 15 and n(1 − p) ≥ 15 it seems reasonable that the bellshaped normal distribution will be a good approximation.
>
>![[Pasted image 20250623121308.png|600]]

>[!example]+ 7.6
>
>If we return to the survey in Example 7.2, we can now calculate the 95% confidence interval for the probability (i.e. the proportion willing to pay more for petrol to help the environment).
>We found the estimate of p by the observed proportion to $\hat{p} = \frac{518}{1154} = 0.45$. The standard error of the proportion estimate is
>
>![[Pasted image 20250623121415.png]]
>
>From this we can now conclude that our best estimate of the proportion willing to pay more for petrol to protect the environment is 0.45, and that the true proportion with 95% certainty is between 0.42 and 0.48. We see that 0.5 is not included in the confidence interval, hence we can conclude that the proportion willing to pay more for petrol is less than 0.5 (using the usual α = 0.05 significance level). We will cover hypothesis testing for proportions more formally below.

>[!note]+ Remark, 7.7 What about small samples then?
>
>There exist several ways of expressing a valid confidence interval for p in small sample cases, that is, when either np ≤ 15 or n(1 − p) ≤ 15. We mention three of these here - only for the last one we give the explicit formula: 
>- Continuity correction 
> 	 The so-called continuity correction is a general approach to making the best approximation of discrete probabilities (in this case the binomial probabilities) using a continuous distribution, (in this case the normal distribution). We do not give any details here.
> 	 
>- Exact intervals 
> 	 Probably the most well known of such small sample ways of obtaining a valid confidence interval for a proportion is the so-called exact method based on actual binomial probabilities rather than a normal approximation. It is not possible to give a simple formula for these confidence limits, and we will not explain the details here, but simply note that they can be obtained by the Python function stats.binomtest. These will be valid no matter the size of n and p. 
> 	 
>- “Plus 2”-approach
> 	  Finally, a simple approach to a good small sample confidence interval for a proportion, will be to us the simple formula given above in Method 7.3, but applied to $x˜ = x + 2$ and $n˜ = n + 4$.

>[!note]+ Remark, 7.8 Confidence intervals for single proportions in
>
>In Python we can either use the function **smprop.proportions_ztest** or **stats.binomtest** to find the confidence interval of a single proportion (and some hypothesis testing information to be described below). The **stats.binomtest** function uses the exact approach. The **smprop.proportions_ztest** does not use continuity correction, but assumes normality. Therefore: none of these intervals calculated by Python coincides exactly with the formula given in Method 7.3, neither applied to **x** and **n** nor applied to **x˜ = x + 2** and **n˜ = n + 4.** And vice versa: the exact computational details of the different intervals calculated by Python are not given in the text here.

****
### **Testing Hypothesis**

>[!info]
Hypothesis testing for a single proportion (or probability) p is presented in this section. The first step is to formulate the null hypothesis and the alternative as well as choosing the level of significance α. The null hypothesis for a proportion has the form
![[Pasted image 20250623121715.png]]
where p0 is a chosen value between 0 and 1. In Example 7.2, we could be interested in testing whether half of the population, from which the sample was taken, would be willing to pay more for petrol, hence p0 = 0.5. The alternative hypothesis is the two-sided alternative
![[Pasted image 20250623121721.png]]

>[!note]+ Remark, 7.9
>
>As for the t-tests presented in Chapter 3, we can also have one-sided tests for proportions, i.e. the “less than” alternative
>
>![[Pasted image 20250623121756.png]]
>
>and the “greater than” alternative
>
>![[Pasted image 20250623121812.png]]
>
>however these are not included further in the material, see the discussion in Section 3.1.7 (from page 144 in the book), which applies similarly here.

The next step is to calculate a test statistic as a measure of how well our data fits the null hypothesis. The test statistic measures how far our estimate pˆ is from the value p0 relative to the uncertainty – under the scenario that H0 is true.
![[Pasted image 20250623121831.png|600]]

>[!theorem]+ 7.10
>
>In the large sample case the random variable Z follows approximately a standard normal distribution
>![[Pasted image 20250623121856.png]]
>
>when the null hypothesis is true. As a rule of thumb, the result will be valid when both np0 > 15 and n(1 − $p_0$) > 15 .

We can use this to make the obvious explicit method for the hypothesis test:
>[!method]+ 7.11 One sample proportion hypothesis test
>
>![[Pasted image 20250623121931.png|600]]
>+
>![[Pasted image 20250623122155.png]]

>[!example]+ 7.12
>![[Pasted image 20250623121948.png|600]]
>
>Since z = −3.47 < −1.96 then we reject H0. The p-value is calculated as the probability of observing zobs or more extreme under the null hypothesis 2 · P(Z ≥ 3.47) = 0.0005. We can get this directly using Python:
>
>![[Pasted image 20250623122016.png|600]]

****
### **Sample size determination**

>[!info]
>
>![[Pasted image 20250623122228.png|600]]

Equation (7-23) to determine the needed sample size in a single proportions setup. Solving for n we get:

>[!method]+ 7.13 Sample size formula for the CI of a proportion
>
>Given some “guess” (scenario) of the size of the unknown p, and given some requirement to the ME-value (required expected precision) the necessary sample size is then
>
>![[Pasted image 20250623122307.png]]
>
>If p is unknown, a worst case scenario with p = 1/2 is applied and necessary sample size is
>
>![[Pasted image 20250623122317.png]]

The expression in Equation (7-25) for n when no information about p is available is due to the fact that p(1 − p) is largest for p = 1/2, so the required sample size will be largest when p = 1/2. Method 7.13 can be used to calculate the sample size for a given choice of ME

****
# **Comparing proportions in two populations**

>[!info]
>For categorical variables we sometimes want to compare the proportions in two populations (groups). Let p1 denote the proportion in group 1 and p2 the proportion in group 2. We will compare the groups by looking at the difference in proportions p1 − p2, which is estimated by pˆ1 − pˆ2.

>[!example]+ 7.14
>
>In a study in the US (1975) the relation between intake of contraceptive pills (birth control pills) and the risk of blood clot in the heart was investigated. The following data were collected from a participating hospital:
>
>![[Pasted image 20250623122442.png|600]]
>
>We have a binary outcome blood clot (yes or no) and two groups (pill or no pill). As in Section 7.2 we find that the best estimates of the unknown probabilities are the observed proportions
>
>![[Pasted image 20250623122456.png|600]]
>
>The difference in probabilities is estimated to be
>
>![[Pasted image 20250623122514.png|600]]

We have the estimate pˆ1 − pˆ2 of the difference in probabilities p1 − p2 and the uncertainty of this estimate can be calculated by:

>[!method]+ 7.15, Large Sample Confidence band
>
>![[Pasted image 20250623122540.png|600]]

>[!note]+ Remark 7.16
>
>The standard error in Method 7.15 can be calculated by
>
>![[Pasted image 20250623122623.png|600]]

>[!example]+ 7.17
>
>![[Pasted image 20250623122646.png|600]]

![[Pasted image 20250623122657.png]]

>[!method]+ 7.18, Two sample proportions hypothesis test
>
>The two-sample hypothesis test for comparing two proportions is given by the following procedure:
>
>![[Pasted image 20250623122727.png|600]]

>[!example]+ 7.19
>
>In Example 7.17 we tested whether the probability of blood clot is the same for the group taking the pills as for the group without pills using the CI. The null hypothesis and alternative are
>
>![[Pasted image 20250623122747.png]]
>
>This time we will test on a 1% significance level (α = 0.01). The pooled estimate of the probability of blood clot under H0 is
>
>![[Pasted image 20250623122801.png|600]]
>
>As the p-value is less than 0.01 we can reject the null hypothesis of equal probabilities in the two groups. Instead of doing all the calculations in steps, we can use the function smprop.proportions_ztest() to test the hypothesis.
>
>``` python
># Testing that the probabilities for the two groups are equal 
>z_obs, p_val = smprop.proportions_ztest([23, 35], [57, 167], value=0, prop_var=0) 
>print(z_obs) 
>2.8859712586466184 
>print(p_val) 
>0.003902077897925702
>```

****
# **Comparing several proportions**

In the previous Section 7.3, we were interested in comparing proportions from two groups. In some cases we might be interested in proportions from two or more groups, or in other words if several binomial distributions share the same parameter p. The data can be setup in a 2 × c table, where "Success" is the response we are studying (e.g. a blood clot occurs) and "Failure" is when the response does not occur (e.g. no blood clot).
![[Pasted image 20250623123636.png]]
We are then interested in testing the null hypothesis
![[Pasted image 20250623123649.png]]

>[!method]+ 7.20, The multi-sample proportions χ 2 -test.
>
>![[Pasted image 20250623123709.png|600]]

The test statistic in Method 7.20 measures the distance between the observed number in a cell and what we would expect if the null hypothesis is true. If the hypothesis is true then χ 2 has a relatively small value, as most of the cell counts will be close to the expected values. If H0 is false, some of the observed values will be far from the expected resulting in a larger χ 2 .

>[!example]+ 7.21
>
>![[Pasted image 20250623123739.png|600]]
>
>![[Pasted image 20250623123750.png|600]]
>
>![[Pasted image 20250623123802.png|600]]
>
>``` python
># Reading the data into Python 
>pill_study = np.array([[23, 35], [34, 132]]) 
>
># Using Pandas 
>pill_study = pd.DataFrame(pill_study, index=[’Blood Clot’, ’No Clot’], columns=[’Pill’....,
>
>print(pill_study) 
>
>```
>
>![[Pasted image 20250623124014.png]]
>
>``` ptyhon
>
># Chi^2 test for testing that the distribution for the two groups are equal 
>chi2, p_val, dof, expected = stats.chi2_contingency(pill_study, correction=False) 
>
># Test Statistic 
>print(chi2) 
>8.328830105734347 
>
># P value 
>print(p_val) 
>0.0039020778979257016 
>
># Degrees of freedom 
>print(dof) 
>1 
>
># Expected frequencies under the null hypothesis 
># Output will not be pandas DataFrame, but we can use pandas to display it nicely 
>print(pd.DataFrame(expected, index=[’Blood Clot’, ’No Clot’], columns=[’Pill’, ’No pill...
>```
>
>![[Pasted image 20250623124022.png]]

![[Pasted image 20250623124031.png]]

****
# Analysis of Contingency Tables

>[!info]
>
>So far, we’ve looked at 2 × c tables, but we can also work with more general **r × c tables**, which come up when we cross-tabulate two categorical variables. These kinds of tables typically arise in two types of studies.
>
The first type involves collecting samples from different groups (like in Section 7.4), but where there are **more than two possible outcomes**. For example, in an opinion poll conducted at three different times, people might be asked whether they support **Candidate 1**, **Candidate 2**, or are **undecided**. This would give us three samples taken at different time points, and we’d be interested in comparing how the distribution of votes changes over time.
>
The second type of study involves a **single sample** where each person is measured on **two related categorical variables** that use the same categories. For instance, imagine we classify students based on their performance in both English and mathematics using the same grading scale—like _good_, _medium_, or _poor_. These types of tables are called **contingency tables**.
>
The key difference between the two setups is how the column totals work:
>
>- In the **first setup**, the column totals are fixed because they represent different sample sizes.
 >   
>- In the **second setup**, the column totals are not fixed—they just count outcomes, and only the overall total number of observations (the grand total) is fixed.
  >  
>
>Even though these setups are different in structure, **we analyze them using the same methods**.

****
### **Comparing several groups**

![[Pasted image 20250623124231.png]]

>[!method]+ 7.22 The r × c frequency table χ^2 -test
>
>![[Pasted image 20250623124253.png|600]]

From Method 7.22, we see that we use the same test statistic as for 2 × c tables measuring the distance between the observed and expected cell counts. The degrees of freedom (r − 1)(c − 1) occurs because only (r − 1)(c − 1) of the expected values eij need to be calculated – the rest can be found by subtraction from the relevant row or column totals

>[!example]+ 7.23
>
>An opinion poll has been made at three time points (4 weeks, 2 weeks and 1 week before the election) each time 200 participants was asked who they would vote for: Candidate 1, Candidate 2 or were undecided. The following data was obtained:
>
>![[Pasted image 20250623124318.png|600]]
>
>Note, that in this poll example the sample sizes are equal (i.e. n1 = n2 = n3 = 200), however that is not a requirement. 
>We want to test the hypothesis that the votes are equally distributed in each of the three polls:
>
>![[Pasted image 20250623124336.png|600]]
>
>![[Pasted image 20250623124348.png|600]]
>
>``` python
># Reading the data into Python 
>poll = np.array([[79, 91, 93], [84, 66, 60], [37, 43, 47]]) 
>poll = pd.DataFrame(poll, index=[’Cand1’, ’Cand2’, ’Undecided’], columns=[’4 weeks’, ’2 weeks’, ’1 week’]) 
>
># testing same distribution in the three populations 
>chi2, p_val, dof, expected = stats.chi2_contingency(poll, correction=False) 
>
># Test statistic 
>print(chi2) 
>6.961978041718169 
>
># p-value 
>print(p_val) 
>0.1379112060673381 
>
># Degrees of Freedom 
>print(dof) 
>4 
>
># Expected frequencies under the null hypothesis 
>print(pd.DataFrame(expected, index=[’Cand1’, ’Cand2’, ’Undecided’], columns=[’4 weeks’, ’2 weeks’, ’1 week’]))
>```
>
>![[Pasted image 20250623124454.png]]
>
>From the χ 2 test we get an observed test statistic of 6.96, and we must now calculate how likely it is to obtain this value or more extreme from a χ 2 -distribution with 4 degrees of freedom. It leads to a p-value of 0.14, so we accept the null hypothesis and find that there is no evidence showing a change in distribution among the three polls.

****
### **Independence between the two categorical variables**

>[!info]
>When the only fixed value is the grand total, then the hypothesis we are interested in concerns independence between the two categorical variables 
>- H0 : "The two variables are independent", 
>- H1 : "The two variables are not independent (they are associated)". (7-59) Using the cell proportions pij the null hypothesis can be written as:

>[!theorem]+ 7.24
>
>To test if two categorical variables are independent the null hypothesis
>
>![[Pasted image 20250623124605.png|600]]

>[!example]+ 7.25
>
>A group of 400 students have had an English test and a mathematics test. The results of each test a categorized as either bad, average or good.
>
>![[Pasted image 20250623124628.png]]
>
>We want to test the hypothesis of independence between results in English and mathematics. First we read the data into Python and calculate proportions and totals:
>
>``` python
># Reading the data into Python 
>results = np.array([[23, 60, 29], [28, 79, 60], [9, 49, 63]]) results_df = pd.DataFrame(results, index=>
>[’EngBad’, ’EngAve’, ’EngGood’], columns=[’MathBad’, ’MathAve’, ’MathGood’])
>
># Percentages 
>prop = results_df/results_df.sum().sum() 
>
>print(prop) 
>```
>![[Pasted image 20250623124824.png]]
>
>``` python
># Row totals 
>print(results_df.sum(axis=1))  
>```
>![[Pasted image 20250623124828.png]]
>
>``` python
># Column totals 
>print(results_df.sum(axis=0)) 
>```
>![[Pasted image 20250623124834.png]]
>
>We want to calculate the expected cell count if H0 is true. Consider the events "good English result" and "good mathematics result" corresponding to cell (3, 3). Under the hypothesis of independence, we have
>
>![[Pasted image 20250623124848.png|600]]
>![[Pasted image 20250623124857.png|600]]
>
>``` python
># Testing independence between english and maths results 
>chi2, p, dof, expected = stats.chi2_contingency(results, correction=False) 
>
># Test statistic 
>print(chi2) 
>20.178903582087926 
>
># p-value 
>print(p) 
>0.00046038041384262443 
>
># Degrees of Freedom 
>print(dof) 
>4 
>
># Expected frequencies under the null hypothesis print(pd.DataFrame(expected, index=[’EngBad’, ’EngAve’, ’EngGood’], columns=[’MathBad’, ’MathAve’, ’MathGood’]))
>```
>
>![[Pasted image 20250623124950.png]]
>
>The χ 2 -test gives a test statistic of 20.18, which under H0 follows a χ 2 -distribution with 4 degrees of freedom leading to a p-value of 0.0005. This means that the hypothesis of independence between English and mathematics results is rejected.

![[Pasted image 20250623125011.png]]



