>[!info]
>In the introduction to the parametric bootstrap, we discussed that one way to avoid having to choose the “correct” distribution is simply not to assume any specific distribution at all. This leads us to a different approach called the **non-parametric bootstrap**, which is explained in this section.
>
>The structure of this section mirrors that of the parametric bootstrap section above, including similar subsections and method boxes. Specifically, there will be two method boxes here: one for one-sample analysis and one for two-sample analysis.
>
>You can think of the non-parametric bootstrap as a version of the parametric bootstrap, except that instead of using a theoretical distribution (like the normal or exponential), we use the **observed distribution of the data**—also known as the **empirical cumulative distribution function (ecdf)**, introduced in Chapter 1.
>
>In practice, we do this by **resampling** the data we already have. To estimate the sampling distribution of the mean (or any other statistic) based on our original sample of size _n_, we repeatedly draw new samples of size _n_ from that original sample. These resamples are taken **with replacement**, meaning that each new “bootstrap sample” can contain some of the original observations more than once, while others might not appear at all.

****
## **One-sample confidence interval for µ**

>[!info]
>We have the sample: x1, . . . , xn. The 100(1 − α)% confidence interval for µ determined by the non-parametric bootstrap is first exemplified:

>[!example]+ 4.14 Women’s cigarette consumption
>
>In a study women’s cigarette consumption before and after giving birth is explored. The following observations of the number of smoked cigarettes per day were observed:
>
>![[Pasted image 20250623120154.png|600]]
>
>This is a typical paired t-test setup, as discussed in Section 3.2.3, which then was handled by finding the 11 differences and thus transforming it into a one-sample setup. First we read the observations into Python and calculate the differences by:
>
>``` python
># Read the data and calculate the difference for each woman before and after 
>x1 = np.array([8, 24, 7, 20, 6, 20, 13, 15, 11, 22, 15]) 
>x2 = np.array([5, 11, 0, 15, 0, 20, 15, 19, 12, 0, 6]) 
>dif = x1-x2 
>
>print(dif) 
>
>[ 3 13 7 5 6 0 -2 -4 -1 22 9]
>```
>
>There is a random-sampling function in the NumPy package (which again is based on a uniform random number generator): np.random.choice. Eg. you can get 5 repeated samples with replacement by: (Note that the argument replace is true by default. Sampling without replacement can thus be done by specifying replace=false.)
>
>``` python
>np.random.choice(dif,size=(5,len(dif))) 
>array([[-4, 5, 0, -1, 7, -2, -2, 5, 0, -2, 3], [ 3, -1, 5, -2, 9, 13, -2, -1, 0, 13, 9], [ 6, -2, 22, 7, -4, 7, 7, 5, 9, 5, 22], [-1, 5, 6, -1, 5, -1, 7, 3, 3, 6, 6], [-4, 7, -2, -2, 3, 7, -2, -2, 9, 13, 22]])
>```
>Explanation: the first argument, dif, defines the sampling space, and the second argument, size=(5,len(dif)), defines the number of bootstrap samples, 5, and their respective sizes, len(dif). One can then run the following to get a 95% confidence interval for µ based on k = 100000:
>
>
>``` python
># Set the number of simulations 
>k = 100000 
>
># Simulate k samples each with 11 observations by 
># sampling with replacement from the data 
>simsamples = np.random.choice(dif,size=(k,len(dif))) 
>
># Compute the mean in each of the k samples 
>simmeans = simsamples.mean(axis=1) 
>
># Find the two relevant quantiles of the k generated meeans 
>print(np.quantile(simmeans,[0.025,0.975], method=’averaged_inverted_cdf’)) 
>
>[1.364 9.818]
>```
>
>Explanation: The np.random.choice-function is called 100.000 times and the results collected in an 11 × 100.000 matrix. Then in a single call the 100.000 averages are calculated and subsequently the relevant quantiles found. Note, that we use the similar three steps as above for the parametric bootstrap, with the only difference that the simulations are carried out by the re-sampling the given data rather than from some probability distribution.

****
## **One-sample confidence interval for any feature**

What we have just done can be more generally expressed as follows:

>[!method]+ 4.15 Confidence interval for any feature θ by nonparametric bootstrap
>
>![[Pasted image 20250623120432.png|600]]

>[!example]+ 4.16
>Let us find the 95% confidence interval for the median cigarette consumption change in the example from above:
> 
>``` python
># The 95% CI for the median change 
>k = 100000
>simsamples = pd.DataFrame(np.random.choice(dif,size=(k,len(dif)))) 
>simmedians = simsamples.median(axis=1) 
>  
>print(np.quantile(simmedians,[0.025,0.975], method=’averaged_inverted_cdf’)) 
>[-1.000 9.000]
> ```

****
## **Two-sample confidence intervals**

We now have two random samples: x1, . . . , xn1 and y1, . . . , yn2 . The 100(1 − α)% confidence interval for θ1 − θ2 determined by the non-parametric bootstrap is defined as:

>[!method]+ 4.17 Two-sample confidence interval for θ1 − θ2 by nonparametric bootstrap
>
>![[Pasted image 20250623120624.png|600]]

>[!example]+ 4.18 Teeth and bottle
>
>In a study it was explored whether children who received milk from bottle as a child had worse or better teeth health conditions than those who had not received milk from the bottle. For 19 randomly selected children it was recorded when they had their first incident of caries:
>
>![[Pasted image 20250623120649.png]]
>
>One can then run the following to obtain a 95 % confidence interval for µ1 − µ2 based on k = 100000:
>
>``` python
># Reading in "no bottle" group 
>x = np.array([9, 10, 12, 6, 10, 8, 6, 20, 12]) 
>
># Reading in "yes bottle" group 
>y = np.array([14,15,19,12,13,13,16,14,9,12]) 
>
># Number of simulations 
>k = 100000 
>
># Simulate each sample k times
>simxsamples = pd.DataFrame(np.random.choice(x,size=(k,len(x)))) 
>simysamples = pd.DataFrame(np.random.choice(y,size=(k,len(y)))) 
>
># Calculate the sample mean differences 
>simmeandifs = simxsamples.mean(axis=1) - simysamples.mean(axis=1) 
>
># Quantiles of the differences gives the CI 
>print(np.quantile(simmeandifs,[0.025,0.975], method=’averaged_inverted_cdf’)) 
>[-6.211 -0.122]
>```

>[!example]+ 4.19
>
>Let us make a 99% confidence interval for the difference of medians between the two groups in the tooth health example:
>
>``` python
># CI for the median differences 
>simmediandifs = simxsamples.median(axis=1) - simysamples.median(axis=1) 
>print(np.quantile(simmediandifs,[0.005,0.995], method=’averaged_inverted_cdf’)) 
>
>[-8.000 0.000]
>```

>[!note]+ Remark, 4.20 Warning: Bootstrapping may not always work well for small sample sizes!
>
>The bootstrapping idea was presented here rather enthusiastically as an almost magic method that can do everything for us in all cases. This is not the case. Some statistics are more easily bootstrapped than others and generally non-parametric bootstrap will not work well for small samples. The inherent lack of information with small samples cannot be removed by any magic trick. Also, there are more conceptually difficult aspects of bootstrapping for various purposes to improve on some of these limitations, see the next section. Some of the "naive bootstrap" CI interval examples introduced in this chapter is likely to not have extremely good properties – the coverage percentages might not in all cases be exactly at the aimed nominal levels.


