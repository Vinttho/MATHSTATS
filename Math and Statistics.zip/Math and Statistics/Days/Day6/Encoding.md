![[Pasted image 20250613130725.png|600]]

>[!example]+ 9.28, 
>
>![[Pasted image 20250613130750.png|600]]

