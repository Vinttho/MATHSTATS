![[Pasted image 20250613130535.png|600]]

>[!corollary]+ 9.27, One-sample t-test as a projection
>
>![[Pasted image 20250613130554.png|600]]

****
## **Assumptions and how to check them**

![[Pasted image 20250613130617.png|600]]

**** 
## **Checking lag-1 autocorrelation**

A notable case where independence can be checked is when the observations are taken with a clear ordering (typically in time), in this case the correlation between residuals should be checked. There is a extended theory on models that model correlation structures in time (time series analysis), which we will not treat here. We will however stress that the independence assumption should be checked for time series data, a simple check is to calculate the lag 1 autocorrelation (to stress the time dependence we have replaced i by t)

![[Pasted image 20250613130652.png|600]]
![[Pasted image 20250613130702.png|600]]

