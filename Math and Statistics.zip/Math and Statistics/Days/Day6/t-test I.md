# **Learning from one-sample quantitative data**

>[!example]+ Student heights
>In examples in Chapter 1 we did descriptive statistics on the following random sample of the heights of 10 students in a statistics class (in cm):
>
>**168 161 167 179 184 166 198 187 191 179**
>
>and we computed the sample mean and standard deviation to be
>
>$$\bar{x} = 178$$
>$$s = 12.21.$$
>
>The population distribution of heights will have some unknown mean µ and some unknown standard deviation σ. We use the sample values as point estimates for these population parameters
>
>$$\hat{µ} = 178$$
>$$\hat{σ} = 12.21$$
>
>Since we only have a sample of 10 persons, we know that the point estimate of 178 cannot with 100% certainty be exactly the true value µ (if we collected a new sample with 10 different persons height and computed the sample mean we would definitely expect this to be different from 178). The way we will handle this uncertainty is by computing an interval called the confidence interval for µ. The confidence interval is a way to handle the uncertainty by the use of probability theory. The most commonly used confidence interval would in this case be
>
>178 ± 2.26 · (12.21 / √ 10) ,
>
>which is 178 ± 8.74
>
>The number 2.26 comes from a specific probability distribution called the tdistribution, presented in Section 2.86. The t-distributions are similar to the standard normal distribution presented in Section 2.5.2: they are symmetric and centred around 0.
>
>The confidence interval interval 178 ± 8.74 = [169.3, 186.7], represents the plausible values of the unknown population mean µ in light of the data.

>[!info]
>
>So in this section we will explain how to estimate the mean of a distribution and how to quantify the precision, or equivalently the uncertainty, of our estimate. We will start by considering a population characterized by some distribution from which we take a sample x1, . . . , xn of size n. In the example above Xi would be the height of a randomly selected person and x1, . . . , x10 our sample of student heights. A crucial issue in the confidence interval is to use the correct probabilities, that is, we must use probability distributions that are properly representing the real life phenomena we are investigating. In the height example, the population distribution is the distribution of all heights in the entire population. So, this is what you would see if you sampled from a huge amount of heights, say n = 1000000, and then made a density histogram of these, see Example 1.25. Another way of saying the same is: the random variables Xi have a probability density function (pdf or f(x)) which describe exactly the distribution of all the values. Well, in our setting we have only a rather small sample, so in fact we may have to assume some specific pdf for Xi , since we don’t know it and really can’t see it well from the small sample. The most common type of assumption, or one could say model, for the population distribution is to assume it to be the normal distribution. This assumption makes the theoretical justification for the methods easier. In many cases real life phenomena actually indeed are nicely modelled by a normal distribution. In many other cases they are not. After taking you through the methodology based on a normal population distribution assumption, we will show and discuss what to do with the non-normal cases. Hence, we will assume that the random variable Xi follows a normal distribution with mean µ and variance σ 2 :

>[!note]+ Remark
>
>In all statistical analysis there must be an assumption of a model, which should be stated clearly in the presentation of the analysis. The model expressing that the sample was taken randomly from the population, which is normal distributed, can be written by Xi ∼ N(µ, σ^2 ) and i.i.d., where i = 1, . . . , n. (3-1) Hence we n random variables representing the sample and they are independent and identically distributed (i.i.d).

>[!note]
>
>Our goal is to learn about the mean of the population µ, in particular, we want to: 1. Estimate µ, that is calculate a best guess of µ based on the sample 2. Quantify the precision, or equivalently the uncertainty, of the estimate Intuitively, the best guess of the population mean µ is the sample mean µˆ = x¯ = 1 n n ∑ i=1 xi . Actually, there is a formal theoretical framework to support that this sort of obvious choice also is the theoretically best choice, when we have assumed that the underlying distribution is normal. The next sections will be concerned with answering the second question: quantifying how precisely x¯ estimates µ, that is, how close we can expect the sample mean x¯ to be to the true, but unknown, population mean µ. To answer this, we first, in Section 3.1.1, discuss the distribution of the sample mean, and then, in Section 3.1.2, discuss the confidence interval for µ, which is universally used to quantify precision or uncertainty

****

## Distribution of the sample mean

![[Pasted image 20250613121744.png|600]]

>[!theorem]+ 3.3, The distribution of the mean of normal random variables
>
>![[Pasted image 20250613121810.png|600]]

>[!important]
>
>![[Pasted image 20250613121845.png|600]]

>[!theorem]+ 3.4, The distribution of the σ-standardized mean of normal random variables
>
>![[Pasted image 20250613121910.png|600]]

However, to somehow use the probabilities to say something clever about how close the estimate x¯ is to µ, all these results have a flaw: the population standard deviation σ (true, but unknown) is part of the formula. And in most practical cases we don’t know the true standard deviation σ. The natural thing to do is to use the sample standard deviation s as a substitute for (estimate of) σ. However, then the theory above breaks down: the sample mean standardized by the sample standard deviation instead of the true standard deviation no longer has a normal distribution! But luckily the distribution can be found (as a probability theoretical result) and we call such a distribution a t-distribution with (n − 1) degrees of freedom (for more details see Section 2.10.2):

>[!theorem]+ 3.5, The distribution of the S-standardized mean of normal random variables
>
>![[Pasted image 20250613121950.png|600]]

A t-distribution, as any other distribution, has a probability density function, presented in Definition 2.86. It is similar in shape to the standard normal distribution: it is symmetric and centred around 0, but it has thicker tails as illustrated in the figure of Example 2.92. Also, the t-distributions are directly available in Python, via the SciPy package as seen also for the other probability distributions, see the overview of distributions in A.2.1. So we can easily work with t-distributions in practice. As indicated, there is a different t-distribution for each n: the larger the n, the closer the t-distribution is to the standard normal distribution.

>[!example]+ 3.6, Normal and t probabilities and quantile
>
>In this example we compare some probabilities from the standard normal distribution with the corresponding ones from the t-distribution with various numbers of degrees of freedom. Let us compare P(T > 1.96) for some different values of n with P(Z > 1.96)
>
>``` python
># The P(T>1.96) probability for n=10 
>print(1-stats.t.cdf(1.96,df=9)) 0.04082220273020831 
>
># The P(Z>1.96) probability 
>print(1-stats.norm.cdf(1.96)) 0.024997895148220484 
>
># The P(T>1.96) probability for n-values, 10, 20, ... ,50 
>print(1-stats.t.cdf(1.96,df=np.linspace(10, 50, 5)-1)) 
>[0.041 0.032 0.030 0.029 0.028] 
>
># The P(T>1.96) probability for n-values, 100, 200, ... ,500 
>print(1-stats.t.cdf(1.96,df=np.linspace(100, 500, 5)-1))
> [0.026 0.026 0.025 0.025 0.025]
>```
>
>Note how the t-probabilities approach the standard normal probabilities as n increases. Similarly for the quantiles:
>
>``` python
># The standard normal 97.5% quantile 
>print(stats.norm.ppf(0.975,loc=0,scale=1)) 
>1.959963984540054 
>
># The t-quantiles for n-values: 10, 20, ... ,50 
># (rounded to 3 decimal points) 
>print(stats.t.ppf(0.975,df=np.linspace(10, 50, 5)-1)) 
>[2.262 2.093 2.045 2.023 2.010] 
>
># The t-quantiles for n-values: 100, 200, ... ,500 # (rounded to 3 decimal points) print(stats.t.ppf(0.975,df=np.linspace(100, 500, 5)-1)) 
>[1.984 1.972 1.968 1.966 1.965]
>```

The sample version of the standard deviation of the sample mean s/√n is called the Standard Error of the Mean (and is often abbreviated SEM):

>[!definition]+ 3.7, Standard Error of the mean
>
>![[Pasted image 20250613122240.png|600]]

>[!note]+ Remark
>Using the phrase sampling distribution as compared to just the distribution of the mean bears no mathematical/formal distinction: formally a probability distribution is a probability distribution and there exist only one definition of that. It is merely used to emphasize the role played by the distribution of the sample mean, namely to quantify how the sample mean changes from (potential) sample to sample, so more generally, the sample mean has a distribution (from sample to sample), so most textbooks and e.g. Wikipedia would call this distribution a sampling distribution.

****
## **Quantifying the precision of the sample mean - the confidence interval**

As already discussed above, estimating the mean from a sample is usually not enough: we also want to know how close this estimate is to the true mean (i.e. the population mean). Using knowledge about probability distributions, we are able to quantify the uncertainty of our estimate even without knowing the true mean. Statistical practice is to quantify precision (or, equivalently, uncertainty) with a confidence interval (CI). In this section we will provide the explicit formula for and discuss confidence intervals for the population mean µ. The theoretical justification, and hence assumptions of the method, is a normal distribution of the population. However, it will be clear in a subsequent section that the applicability goes beyond this if the sample size n is large enough. The standard so-called one-sample confidence interval method is:

>[!info]+ Method 3.9 The one sample confidence interval for µ
>
>![[Pasted image 20250613122335.png|600]]

>[!example]+ 3.10, Student heights
>
>We can now use Method 3.9 to find the 95% confidence interval for the population mean height from the height sample from Example 3.1. We need the 0.975-quantile from the t-distribution with n − 1 = 9 degrees of freedom:
>
>``` python
># The t-quantiles for n=10: 
>print(stats.t.ppf(0.975,df=9)) 
>2.2621571628540993
>```
>
>![[Pasted image 20250613122433.png|600]]

The confidence interval is widely used to summarize uncertainty, not only for the sample mean, but also for many other types of estimates, as we shall see in later sections of this chapter and in following chapters. It is quite common to use 95% confidence intervals, but other levels, e.g. 99% are also used (it is presented later in this chapter what the precise meaning of “other levels” is).

>[!example]+ 3.11, Student heights
>
>Let us try to find the 99% confidence interval for µ for the height sample from Example 3.1. Now α = 0.01 and we get that 1− α/2 = 0.995, so we need the 0.995-quantile from the t-distribution with n − 1 = 9 degrees of freedom:
>
>``` python
># The t-quantiles for n=10: 
>print(stats.t.ppf(0.995,df=9))
>3.2498355415921254
>```
>
>![[Pasted image 20250613122533.png|600]]
>
>``` python
># The 99% confidence interval for the mean 
>x = np.array([168, 161, 167, 179, 184, 166, 198, 187, 191, 179]) 
>n = len(x) 
>
>print(x.mean() - stats.t.ppf(0.995,df=9) * x.std(ddof=1) / np.sqrt(n)) 
>165.45078999139582 
>
>print(x.mean() + stats.t.ppf(0.995,df=9) * x.std(ddof=1) / np.sqrt(n)) 
>190.54921000860418
>```
>
>Or using the function stats.t.interval from the SciPy package:
>
>``` python
># The 99% confidence interval for the mean 
>stats.t.interval(0.99,df=n-1,loc=x.mean(), 
>scale=x.std(ddof=1)/np.sqrt(n)) 
>(np.float64(165.45078999139582), np.float64(190.54921000860418))
>```

****
## **The language of statistics and the process of learning from data**

>[!info]
>
>- **Population**: The full set of items or individuals we want to learn about.
   > 
>- **Sample**: A subset taken from the population, used to infer information about it.
>    
>- **Distribution**: Describes how values in the population are spread (e.g., normal distribution).
 >   
>- **Parameter**: A fixed but unknown quantity describing the population (e.g., mean μ, variance σ²).
  >  
>- **Estimate**: A value calculated from the sample to approximate a parameter (e.g., sample mean x̄ estimates μ).
 >   
>- **Estimator**: A function or rule that generates an estimate (e.g., X̄ is the estimator of μ).
  >  
>- **Statistic**: Any function of the sample data. Can be:
  >  
    >- Fixed (e.g., x̄ from observed data), or
  >      
>- Random (e.g., X̄ before observation, has a distribution).
    >    
>- **Random Variable**: Denoted with capital letters (e.g., X), represents a yet unobserved outcome.
    >
>- **Observed Value (Realization)**: Denoted with lowercase (e.g., x), the actual observed value.
   > 
>- **Confidence Interval**: A range calculated from the sample that likely contains the true parameter.
   > 
>- **Random Sampling**: Ensures that the sample is representative of the population, which is crucial for valid inference.

>[!definition]+ 3.12, Random sample
>
>A random sample from an (infinite) population: A set of observations X1, ..., Xn constitutes a random sample of size n from the infinite population f(x) if: 
>- 1. Each Xi is a random variable whose distribution is given by f(x) 
>- 2. The n random variables are independent

>[!note]+ Remark
>Throughout previous sections and the rest of this chapter we assume infinite populations. Finite populations of course exists, but only when the sample constitutes a large proportion of the entire population, is it necessary to adjust the methods we discuss here. This occurs relatively infrequently in practice and we will not discuss such conditions.

****
## **When we cannot assume a normal distribution: the Central Limit Theorem**

The Central Limit Theorem (CLT) states that the sample mean of independent identically distributed (i.i.d.) random variables converges to a normal distribution:

>[!theorem]+ 3.14, Central Limit Theorem (CLT)
>
>![[Pasted image 20250613123319.png|600]]

>[!info]
>
>The **Central Limit Theorem (CLT)** says something really helpful:
>
>When your **sample is big enough**, the **average** (mean) of your sample behaves like it's from a **normal distribution** — even if the population it's from is not!
>
>This means:
>
>- You **don’t need to know** what the original data looks like (e.g., if it's skewed or uneven).
   > 
>- You can still make **good guesses about the population mean** using your sample mean.
  >  
>
>Also:
>
>- The **bigger** your sample, the **less your sample mean varies**.
 >   
>- So with a **larger sample**, your guess about the population mean becomes **more accurate**.

>[!example]+ 3.15, Central Limit Theorem in practice
>
>``` python
># Number of simulated samples 
>k = 1000 
>
># Number of observations in each sample 
>n = 1 
>
># Simulate k samples with n observations 
>Xbar1 = stats.uniform.rvs(0,1, size=(k,n)) 
>
># Increase the number of observations in each sample 
>n = 2 
>Xbar2 = pd.DataFrame(stats.uniform.rvs(0,1, size=(k,n))).mean(axis=1) 
>
># Increase the number of observations in each sample 
>n = 6 
>Xbar6 = pd.DataFrame(stats.uniform.rvs(0,1, size=(k,n))).mean(axis=1) 
>
># Increase the number of observations in each sample 
>n = 30 
>Xbar30 = pd.DataFrame(stats.uniform.rvs(0,1, size=(k,n))).mean(axis=1) 
>
># Plot the histograms 
>fig, axs = plt.subplots(2,2) 
>axs[0,0].hist(Xbar1, bins=50, range=[0,1], edgecolor=’black’, color=’blue’, alpha=0.7)
> 
>axs[0,1].hist(Xbar2, bins=50, range=[0,1], edgecolor=’black’, color=’blue’, alpha=0.7)
> 
>axs[1,0].hist(Xbar6, bins=50, range=[0,1], edgecolor=’black’, color=’blue’, alpha=0.7)
> 
>axs[1,1].hist(Xbar30, bins=50, range=[0,1], edgecolor=’black’, color=’blue’, alpha=0.7) 
>
>plt.tight_layout() 
>plt.show()
>```
>
>![[Pasted image 20250613123636.png|600]]

>[!info]
>**Confidence Intervals and the Central Limit Theorem**
>
>Thanks to the **Central Limit Theorem**, we can use the **normal distribution** to build confidence intervals when the sample size is large:
>
>$$\bar{x} \pm z_{1-\alpha/2} \cdot \frac{s}{\sqrt{n}}$$
>
>This is just a special case of the **t-based confidence interval**.
>
>- For **large samples**, the **normal and t-distributions are nearly the same**.
>- But the **t-distribution also works for small samples** (if the data is normal), so it's **safer to always use the t-based interval**.
>- You can always use `stats.t.interval` from SciPy — it works for all sample sizes.
>
>**How large is large enough?**
>As a rule of thumb, use **n ≥ 30** if the data isn’t clearly normal.
>
>**What if the sample is small and not normal?**
>- Then normal or t-based methods aren't reliable.
>- You'll need **non-parametric** or **simulation-based methods**, which are introduced in the next chapter.

****
## **Repeated sampling interpretation of confidence intervals**

In this section we show that 95% of the 95% confidence intervals we make will cover the true value in the long run. Or, in general 100(1 − α)% of the 100(1 − α)% confidence intervals we make will cover the true value in the long run. For example, if we make 100 95% CI we cannot guarantee that exactly 95 of these will cover the true value, but if we repeatedly make 100 95% CIs then on average 95 of them will cover the true value.

>[!example]+ 3.16, Simulating many confidence intervals
>
>To illustrate this with a simulation example, then we can generate 50 random N(1, 12 ) distributed numbers and calculate the t-based CI given in Method 3.9, and then repeated this 1000 times to see how many times the true mean µ = 1 is covered. The following code illustrates this:
>
>``` python
># Simulate 1000 samples each with 50 observations 
>x = pd.DataFrame(stats.norm.rvs(loc=1,scale=1,size=(1000,50)))
>
># Calculate a 95% CI from each sample 
>CIs = stats.t.interval(0.95,df=50-1,loc=x.mean(axis=1), scale=x.std(ddof=1,axis=1)/np.sqrt(50)) 
>
># Count how often 1 is covered 
>print(np.sum((CIs[0] <= 1) & (CIs[1] >= 1))) 
>954
>```
>
>Hence in 954 of the 1000 repetitions (i.e. 95.4%) the CI covered the true value. If we repeat the whole simulation over, we would obtain 1000 different samples and therefore 1000 different CIs. Again we expect that approximately 95% of the CIs will cover the true value µ = 1.

![[Pasted image 20250613123909.png|600]]

****
## **Confidence interval for the variance**

>[!info]
>**Confidence Intervals for Variance and Standard Deviation**
>
>So far, we’ve learned how to calculate confidence intervals for the **mean**.  
>This section focuses on confidence intervals for the **variance** and **standard deviation**.
>
>🔍 **Important assumption**:  
>These methods **require** that the data comes from a **normal distribution**.
>
>⚠️ Unlike confidence intervals for the mean (which can tolerate small deviations from normality),  
>**confidence intervals for variance are very sensitive** to this assumption.
>
>In short:  
>✅ Okay to use for variance **only if** the data is normally distributed.  
>🚫 Don’t use these methods if the data isn’t normal — they won’t be reliable.

>[!example]+ 3.17, Tablet production
>
>In the production of tablets, an active matter is mixed with a powder and then the mixture is formed to tablets. It is important that the mixture is homogeneous, such that each tablet has the same strength. We consider a mixture (of the active matter and powder) from where a large amount of tablets is to be produced. We seek to produce the mixtures (and the final tablets) such that the mean content of the active matter is 1 mg/g with the smallest variance possible. A random sample is collected where the amount of active matter is measured. It is assumed that all the measurements follow a normal distribution.

![[Pasted image 20250613124022.png|600]]

The χ 2 -distribution, as any other distribution, has a probability density function. It is a non-symmetric distribution on the positive axis. It is a distribution of squared normal random variables, for more details see Section 2.10.1. An example of a χ 2 -distribution is given in the following:

>[!example]+ 3.18, The χ^2 -distribution
>
>The density of the χ^2 -distribution with 9 degrees of freedom is:
>
>``` python
># The chi-square-distribution with 
>df=9 (the density) 
>x = np.linspace(0, 35, 1000) 
>plt.plot(x,stats.chi2.pdf(x,df=9)) 
>plt.ylabel(’Density’,fontsize=12) 
>plt.tight_layout() 
>plt.show()
>```
>
>![[Pasted image 20250613124116.png|600]]

>[!info]
>
>So, the χ 2 -distributions are directly available in Python, via the SciPy package as seen for the other probability distributions presented in the distribution overview, see Appendix A.3. Hence, we can easily work with χ 2 -distributions in practice. As indicated there is a different χ 2 -distribution for each n.

### Confidence interval for the variance/standard deviation
![[Pasted image 20250613124145.png|600]]

>[!note]
>
>The confidence intervals for the variance and standard deviations are generally non-symmetric as opposed to the t-based interval for the mean µ.

>[!example]+ 3.20, Tablet production
>
>A random sample of n = 20 tablets is collected and from this the mean is estimated to x¯ = 1.01 and the variance to s 2 = 0.072 . Let us find the 95%-confidence interval for the variance. To apply the method above we need the 0.025 and 0.975 quantiles of the χ 2 -distribution with ν = 20 − 1 = 19 degrees of freedom
>
>$$χ^2_0.025 = 8.907, χ^2_0.975 = 32.85,$$
>
>which we get from Python:
>
>``` python
># Quantiles of the chi-square distribution: 
>print(stats.chi2.ppf([0.025,0.975],df=19))
> [ 8.907 32.852]
>```
>
>![[Pasted image 20250613124342.png|600]]

****
## **Hypothesis testing, evidence, significance and the p-value**

>[!example]+ 3.21, Sleeping medicine
>
>In a study the aim is to compare two kinds of sleeping medicine A and B. 10 test persons tried both kinds of medicine and the following 10 DIFFERENCES between the two medicine types were measured (in hours):
>
>![[Pasted image 20250613124435.png|600]]
>![[Pasted image 20250613124448.png|600]]

>[!important]+ A way to interpret the evidence for a given p-value.
![[Pasted image 20250613124501.png|600]]

>[!definition]+ The p-value
>The p-value is the probability of obtaining a test statistic that is at least as extreme as the test statistic that was actually observed. This probability is calculated under the assumption that the null hypothesis is true.

>[!info]
>**Interpreting a p-value**
>
>A **p-value** helps us evaluate how compatible the data is with the **null hypothesis** (H₀), assuming it's true.
>
>There are two main interpretations:
>1. It measures the **evidence** against H₀.
>2. It reflects how **extreme or unusual** the observed data is under H₀.
>
>🡒 The **smaller** the p-value, the **stronger** the evidence against H₀.
>
>This interpretation is **general** and applies to all types of hypothesis tests.  
>Later sections will introduce more specific methods based on this idea.

### The one-sample t-test statistic and the p-value
![[Pasted image 20250613124621.png|600]]

>[!definition]+ 3.24, The hypothesis test
>
>We say that we carry out a hypothesis test when we decide against a null hypothesis or not, using the data. A null hypothesis is rejected if the p-value, calculated after the data has been observed, is less than some α, that is if the p-value < α, where α is some prespecified (so-called) significance level. And if not, then the null hypothesis is said to be accepted.

>[!note]+ Remark
>Often chosen significance levels α are 0.05, 0.01 or 0.001 with the former being the globally chosen default value.

>[!note]+ Remark
>
>A note of caution in the use of the word accepted is in place: this should NOT be interpreted as having proved anything: accepting a null hypothesis in statistics simply means that we could not prove it wrong! And the reason for this could just potentially be that we did not collect sufficient amount of data, and acceptance hence proofs nothing at its own right.

>[!example]+ 3.27, Sleeping medicine
>
>Continuing from Example 3.21, we now illustrate how to compute the p-value using Method 3.23.
>
>``` python
># Enter sleep difference observations 
>x = np.array([1.2, 2.4, 1.3, 1.3, 0.9, 1.0, 1.8, 0.8, 4.6, 1.4]) 
>n = len(x)
>
># Compute the tobs - the observed test statistic 
>tobs = (x.mean() - 0)/(x.std(ddof=1) / np.sqrt(n)) print(tobs) 
>4.671645978656775 
>
># Compute the p-value as a tail-probability in the t-distribution
>pvalue = 2 * (1-stats.t.cdf(abs(tobs),df=n-1)) 
>print(pvalue) 
>0.0011658764685527068
>```
>
>Naturally, a function in Python can do this for us (the results differ slightly due to numerical inaccuracies). This function can also be used to calculate confidence intervals:
>
>``` python
>stats.ttest_1samp(x,popmean=0).pvalue 
>np.float64(0.0011658764685528319) 
>
>stats.ttest_1samp(x,popmean=0).confidence_interval() 
>
>ConfidenceInterval(low=np.float64(0.8613337442036719), high=np.float64(2.47866625579632
>```

The confidence interval and the p-value supplements each other, and often both the confidence interval and the p-value are reported. The confidence interval covers those values of the parameter that we accept given the data, while the p-value measures the extremeness of the data if the null hypothesis is true.

>[!example]+ 3.28, Sleeping medicine
>
>In the sleep medicine example the 95% confidence interval is 
>$$[0.86, 2.48]$$
> , so based on the data these are the values for the mean sleep difference of Medicine B versus Medicine A that we accept can be true. Only if the data is so extreme (i.e. rarely occurring) that we would only observe it 5% of the time the confidence interval does not cover the true mean difference in sleep. The p-value for the null hypothesis µ = 0 was ≈ 0.001 providing strong evidence against the correctness of the null hypothesis. If the null hypothesis was true, we would only observe this large a difference in sleep medicine effect levels in around one out of a thousand times. Consequently we conclude that the null hypothesis is unlikely to be true and reject it.

### Statistical significance 
The word significance can mean importance or the extent to which something matters in our everyday language. In statistics, however, it has a very particular meaning: if we say that an effect is significant, it means that the p-value is so low that the null hypothesis stating no effect has been rejected at some significance level α

>[!definition]+ 3.29, Significant effect
>
>An effect is said to be (statistically) significant if the p-value is less than the significance level α^a
>
>a^Often, α = 0.05 is adopted

At this point an effect would amount to a µ-value different from µ0. In other contexts we will see later, effects can be various features of interest to us.

>[!example]+ 3.30, Statistical significance
>
>Consider the following two situations: 
>- 1. A researcher decides on a significance level of α = 0.05 and obtains p-value = 0.023. She therefore concludes that the effect is statistically significant 
>  
> - 2. Another researcher also adopts a significance level of α = 0.05, but obtains p-value = 0.067. He concludes that the effect was not statistically significant
>   
 From a binary decision point of view the two researchers couldn’t disagree more. However, from a scientific and more continuous evidence quantification point of view there is not a dramatic difference between the findings of the two researchers.

In daily statistical and/or scientific jargon the word ”statistically” will often be omitted, and when results then are communicated as significant further through media or other places, it gives the risk that the distinction between the two meanings gets lost. At first sight it may appear unimportant, but the big difference is the following: sometimes a statistically significant finding can be so small in real size that it is of no real importance. If data collection involves very big data sizes one may find statistically significant effects that for no practical situations matter much or anything at all.

### The null hypothesis
The null hypothesis most often expresses the status quo or that “nothing is happening”. This is what we have to believe before we perform any experiments and observe any data. This is what we have to accept in the absence of any evidence that the situation is otherwise. For example the null hypothesis in the sleep medicine examples states that the difference in sleep medicine effect level

![[Pasted image 20250613125150.png|600]]

Figure 3.1: The 95% critical value. If tobs falls in the pink area we would reject, otherwise we would accept is unchanged by the treatment: this is what we have to accept until we obtain evidence otherwise. In this particular example the observed data and the statistical theory provided such evidence and we could conclude a significant effect. The null hypothesis has to be falsifiable. This means that it should be possible to collect evidence against it.

### Confidence intervals, critical values and significance levels
A hypothesis test, that is, making the decision between rejection and acceptance of the null hypothesis, can also be carried out without actually finding the p-value. As an alternative one can use the so-called critical values, that is the values of the test-statistic which matches exactly the significance level, see Figure 3.1:

>[!definition]+ 3.31, The critical values
>
>The (1 − α)100% critical values for the one-sample t-test are the α/2- and 1 − α/2-quantiles of the t-distribution with n − 1 degrees of freedom 
>$$t_{α/2}$$ and $$t1_{−α/2}.$$

### The one-sample hypothesis test by the critical value
![[Pasted image 20250613125258.png|600]]

>[!theorem]+ 3.33, Confidence interval for µ
>
>![[Pasted image 20250613125334.png|600]]

![[Pasted image 20250613125347.png|600]]

### **The alternative hypothesis** 
Some times we may in addition to the null hypothesis, also explicitly state an alternative hypothesis. This completes the framework that allows us to control the rates at which we make correct and wrong conclusions in light of the alternative. The alternative hypothesis is H1 : µ 6= µ0. (3-30) This is sometimes called the two-sided (or non-directional) alternative hypothesis, because also one-sided (or directional) alternative hypothesis occur. However, the one-sided setup is not included in the book apart from a small discussion below.

![[Pasted image 20250613125423.png|600]]

A generic approach for tests of hypotheses is: 1. Formulate the hypotheses and choose the level of significance α (choose the "risk-level") 2. Calculate, using the data, the value of the test statistic 3. Calculate the p-value using the test statistic and the relevant sampling distribution, compare the p-value and the significance level α, and finally make a conclusion or Compare the value of the test statistic with the relevant critical value(s) and make a conclusion Combining this generic hypothesis test approach with the specific method boxes of the previous section, we can now below give a method box for the one sample t-test. This is hence a collection of what was presented in the previous section:

![[Pasted image 20250613125439.png|600]]

>[!info]
>**One-sided vs. Two-sided Hypothesis Tests**
>
>- **Two-sided tests** are used when we don't know the direction of the effect — we're testing whether something is **simply different** from a value.
>
>- **One-sided tests** are used when we expect a change in **one direction only** (e.g., *less than* or *greater than*).
>
>🔹 Example: In pharmacology, drug concentration might only decrease after a peak — so a **"less than"** hypothesis is appropriate.
>
>**Setup examples:**
>
>**One-sided (less than):**  
>H₀: μ ≥ μ₀  
>H₁: μ < μ₀  
>→ p-value = P(T < t_obs)
>
>**One-sided (greater than):**  
>H₀: μ ≤ μ₀  
>H₁: μ > μ₀  
>→ p-value = P(T > t_obs)
>
>➡ Reject H₀ if **p-value < α**, otherwise do not reject.  
>➡ Exercises do **not** involve one-sided tests.

### **Errors in hypothesis testing**

When testing statistical hypotheses, two kind of errors can occur: Type I: Rejection of H0 when H0 is true Type II: Non-rejection (acceptance) of H0 when H1 is true

![[Pasted image 20250613125532.png|600]]

>[!info]
>**Type I and Type II Errors in Hypothesis Testing**
>
>We can't completely avoid making errors when testing hypotheses — it's part of the trade-off:
>
>- **Type I error (α):** Rejecting a true null hypothesis (a false alarm).  
>   → Example: Concluding a treatment works when it actually doesn't.
>
>- **Type II error (β):** Failing to reject a false null hypothesis (a missed detection).  
>   → Example: Missing the chance to recognize that a treatment really works.
>
>Reducing the risk of **Type I errors** (by lowering α) increases the risk of **Type II errors** (β), **unless** we increase the sample size.
>
>✅ Only by increasing **n** (sample size) can we reduce **both** α and β — but this is often expensive or impractical.
>
>That’s why hypothesis testing exists: to **quantify and manage these risks** so decisions can be made with awareness of the trade-offs.
>
>Key definitions:
>
>‣ P(Type I error) = α  
>‣ P(Type II error) = β

>[!theorem]+ 3.39, Significance level and Type I error
>
>The significance level α in hypothesis testing is the overall Type I risk 
>$P("Type I error") = P("Rejection of H0 when H0 is true") = α. (3-41)$

So controlling the Type I risk is what is most commonly apparent in the use of statistics. Most published results are results that became significant, that is, the p-value was smaller than α, and hence the relevant risk to consider is the Type I risk. Controlling/dealing with the Type II risk, that is: how to conclude on an experiment/study in which the null hypothesis was not rejected (ı.e. no significant effect was found) is not so easy, and may lead to heavy discussions if the nonfindings even get to the public. To which extent is a non-finding an evidence of the null hypothesis being true? Well, in the outset the following very important saying makes the point:

![[Pasted image 20250613125637.png|600]]

The main thing to consider here is that non-findings (non-significant results) may be due to large variances and small sample sizes, so sometimes a nonfinding is indeed just that we know nothing. In other cases, if the sample sizes were high, a non-finding may actually, if not proving an effect equal to zero, which is not really possible, then at least indicate with some confidence that the possible effect is small or even very small. The confidence interval is a more clever method to use here, since the confidence interval will show the precision of what we know, whether it includes the zero effect or not. In Section 3.3 we will use a joint consideration of both error types to formalize the planning of suitably sized studies/experiments.

****
## **Assumptions and how to check them**

>[!info]
>**Assumptions Behind the t-Test**
>
>When using the t-test, there are two main assumptions about the data:
>
>1. **Independence** – Each observation must come from a different, unrelated source.  
>   → This ensures each data point provides unique information.  
>   → For example, measuring the heights of 20 people, but 15 of them are from the same family, would violate independence.
>
>2. **Normal Distribution** – The population the data comes from should be normally distributed.  
>   → This can be checked using plots (like histograms or Q-Q plots).
>
>Independence is mostly verified by knowing how the data was collected, while normality can be checked using the data itself.


![[Pasted image 20250613125717.png|600]]
![[Pasted image 20250613125727.png|600]]
![[Pasted image 20250613125745.png|600]]
![[Pasted image 20250613125757.png|600]]
![[Pasted image 20250613125809.png|600]]

![[Pasted image 20250613125819.png|600]]

>[!example]+ 3.43, Student heights
>An example of how the expected normal quantile is calculated in Python can be seen if we take the second smallest height 166. There are 2 observations ≤ 166, so 166 = x(2) can be said to be the observed 2−3/8 10.25 = 0.1585 quantile (where we use the formula for n ≤ 10). The 0.1585 quantile in the normal distribution is stats.norm.ppf(0.1585,loc=0,scale=1) = −1.00 and the point (−1.00, 166) can be seen on the q-q plot above

****
## **Transformation towards normality**

>[!info]
>**Handling Non-Normal Data with Transformations**
>
>If the data is not normally distributed, you can often make it more normal by transforming it.
>
>- For data with positive values and some very large numbers (a long tail), a **logarithmic transformation** (log(x)) is common.  
>  → This shrinks large values and spreads data across positive and negative values.
>
>- Other transformations include:  
>  • Square root (√x)  
>  • Reciprocal (1/x) to reduce large values  
>  • Squaring (x²) or cubing (x³) to increase large values
>
>After transforming, you perform analyses on the transformed data.  
>Remember, results like the mean or confidence intervals will be for the transformed scale and might need to be converted back to the original scale afterward.


![[Pasted image 20250613125940.png|600]]
![[Pasted image 20250613130004.png|600]]
![[Pasted image 20250613130025.png|600]]
![[Pasted image 20250613130038.png|600]]

>[!theorem]+ 3.45, Transformations and quantiles
>
>In general, the data transformations discussed in this section will preserve the quantiles of the data. Or more precisely, if f is a data transformation function (an increasing function), then
>
>The pth quantile of  $$f(Y) = f$$(The pth quantile of Y)

The consequence of this theorem is that confidence limits on one scale transform easily to confidence limits on another scale even though the transforming function is non-linear.



