![[Pasted image 20250610103623.png|600]]
![[Pasted image 20250610103635.png|600]]

``` python
S = dat.cov() 
mu = dat.mean() 

print(mu)
```
![[Pasted image 20250604123740.png]]
Hence average height is about 180 cm and the average weight is about 78 kg

``` python
R = dat.corr() 

sig_hat = np.sqrt(dat.var()) 
print(sig_hat)
```
![[Pasted image 20250604123812.png]]
The standard deviation is 7cm and 10kg

``` python
print(R)
```
![[Pasted image 20250604123856.png]]
And the correlation is about 0.66
