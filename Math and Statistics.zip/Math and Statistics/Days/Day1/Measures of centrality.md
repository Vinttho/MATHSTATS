
#### **Mean**
![[Pasted image 20250604111054.png|600]]
##### $\bar{x}$ : [[Introduction|Sample Mean]] 

#### **Median**
![[Pasted image 20250604111407.png|600]]

**Important** : **n = 2, 4, 6, ... n** then another formula is used. *(read above)*

![[Pasted image 20250604111603.png|600]]

#### **Quantiles and percentiles**
![[Pasted image 20250604111748.png|600]]
Often calculated percentiles are the so-called quartiles (splitting the sample in quarters, i.e. 0%, 25%, 50%, 75% and 100%):
**q0, q0.25, q0.50, q0.75 and q1**

![[Pasted image 20250604112034.png]]

![[Pasted image 20250604112239.png|600]]

#### **Sample variance**
![[Pasted image 20250604112429.png|600]]
We can see the sample mean inside the "*()*"

#### **Sample standard deviation**
![[Pasted image 20250604112614.png|600]]

The **sample standard deviation** and **sample variance** are important numbers that tell us **how much the values in a group (sample) vary** or spread out.

But if you want to **compare variation between different groups**, these numbers alone may not be enough—especially if the groups have very different averages.

In that case, it's better to use a **relative measure**. One common option is the **coefficient of variation**, which shows **how big the variation is compared to the average**.

#### **Coefficient of variation**
![[Pasted image 20250604112728.png|600]]

#### **Range**
![[Pasted image 20250604112801.png|600]]
**[[Introduction|IQR]]** : Can be found in introduction

![[Pasted image 20250604113156.png|600]]

## For finding the relation between two values:

![[Pasted image 20250604113412.png|600]]

#### **Sample covariance**
![[Pasted image 20250604113438.png|600]]

#### **Sample correlation**
![[Pasted image 20250604113458.png|600]]

![[Pasted image 20250604113648.png]]

> [!important]
> This is an important note!
> 
> ![[Pasted image 20250604113708.png]]

![[Pasted image 20250604113827.png|600]]

