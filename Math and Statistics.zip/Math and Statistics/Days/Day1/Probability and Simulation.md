## Random Variables

> [!info] Sample Space
> The sample space S is the set of all possible outcomes of an experiment.

> [!definition]+ Definition 2.1
> The *sample space* $S$ is the set of all possible outcomes of an experiment.

> [!example]+ Example 2.1
> Consider an experiment in which a person will throw two paper balls with the purpose of hitting a wastebasket. All the possible outcomes forms the sample space of this experiment as
> S = { (miss,miss),(hit,miss),(miss,hit),(hit,hit) }

> [!definition]+ Definition 2.3
> A random variable is a function which assigns a numerical value to each outcome in the sample space. In this book random variables are denoted with capital letters, e.g.

> [!example]
> ![[Pasted image 20250604130954.png|600]]

> [!info]+ Remark
> ![[Pasted image 20250604131317.png|600]]

****
## Discrete random variables

To exemplify, consider the outcome of one roll of a fair six-sided dice as the random variable X fair. It has six possible outcomes, each with equal probability. This is specified with the probability density function.

> [!definition]+ The pdf of a discrete random variable
> ![[Pasted image 20250604131506.png|600]]

> [!example]
> ![[Pasted image 20250604131540.png|600]]
> ![[Pasted image 20250604131552.png|600]]

> [!info]
> ![[Pasted image 20250604131618.png]]

****
#### **The cumulated distribution function (cdf)**
> [!definition]+ The cdf of a discrete random variable
> ![[Pasted image 20250604131702.png|600]]

The probability that the outcome of X is in a range is $P(a < X ≤ b) = F(b) − F(a).$

For the fair dice the probability of an outcome below or equal to 4 can be calculated
$F_{Xfair}(4) = 4 ∑ j=1 f_{Xfair}(xj) = 1 6 + 1 6 + 1 6 + 1 6 = 2 3 .$

> [!example]
> ![[Pasted image 20250604131847.png|600]]

****
## Simulations

#### **Simulation of rolling a dice**
> [!example]
> Let’s simulate the experiment of rolling a dice using the following
> 
> ``` python
> # Make a random draw from (1,2,3,4,5,6) with equal probability for each outcome 
> np.random.choice(range(1, 7), size=1)
> ```
> 
> The simulation becomes more interesting when the experiment is repeated many times, then we have a sample and can calculate the empirical density function (or empirical pdf or density histogram. as a discrete histogram and actually “see” the shape of the pdf
> 
> #### **Fair Dice**
> 
> ``` python
> # Simulate a fair dice 
> # Number of simulated realizations 
> n = 30 
> 
> # Draw independently from the set (1,2,3,4,5,6) with equal probability 
> xFair = np.random.choice(range(1, 7), size=n, replace=True) 
> 
> # Count the number of each outcome using the bincount function 
> counts = np.bincount(xFair) 
> 
> # Plot the pdf 
> fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(8,4)) ax1.bar(range(1,7), [1/6]*6, color=’red’) 
> 
> # Plot the empirical pdf 
> ax1.bar(range(1,7), counts[1:7]/n) 
> 
> # Plot the cdf 
> ax2.bar(range(1,7), np.cumsum([1/6]*6), color=’red’) 
> 
> # Add the empirical cdf 
> ax2.bar(range(1,7), np.cumsum(counts[1:7]/n))
> ```
> 
> ![[Pasted image 20250604132448.png|600]]
> 
> #### **Now the unfair dice**
> 
> ``` python
> # Simulate an unfair dice 
> # Number of simulated realizations 
> n = 30 
> 
> # Draw independently from the set (1,2,3,4,5,6) with higher 
> # probability for a six 
> probs = [1/7, 1/7, 1/7, 1/7, 1/7, 2/7] 
> xUnfair = np.random.choice(range(1, 7), size=n, replace=True, p=probs) counts = np.bincount(xUnfair) 
> 
> # Plot the pdf 
> fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(8,4)) ax1.bar(range(1,7), probs, color=’red’) 
> 
> # Plot the empirical pdf 
> ax1.bar(range(1,7), counts[1:7]/n) 
> 
> # Plot the cdf 
> ax2.bar(range(1,7), np.cumsum(probs), color=’red’) 
> 
> # Add the empirical cdf 
> ax2.bar(range(1,7), np.cumsum(counts[1:7]/n))
> ```
> 
> ![[Pasted image 20250604132649.png|600]]

>[!note]+ Using seed to get the same random generated numbers
>```python
># The random numbers generated depends on the seed 
># Set the seed 
>np.random.seed(127) 
>
># Generate a (pseudo) random sequence 
>print(np.random.rand(10)) 
>[0.524 0.040 0.186 0.773 0.552 0.086 0.441 0.716 0.671 0.473] 
>
># Generate again and see that new numbers are generated 
>print(np.random.rand(10)) 
>[0.906 0.105 0.175 0.089 0.650 0.071 0.460 0.907 0.094 0.633] 
>
># Set the seed and the same numbers as before just after the # seed was set are generated 
>np.random.seed(127) print(np.random.rand(10)) [0.524 0.040 0.186 0.773 0.552 0.086 0.441 0.716 0.671 0.473]
>```

****
### Mean and expected value

It is formally defined as a function E(X): the expected value of the random variable X.

> [!definition]+ Mean value
> ![[Pasted image 20250604133022.png|600]]

>[!example]
>![[Pasted image 20250604133103.png|600]]

> [!example]+ Simulate and estimate the mean
> 
> Carrying out the experiment more than one time an estimate of the mean, i.e. the sample mean, can be calculated. Simulate rolling the fair dice
> 
> ### **Fair dice**
> 
> ``` python
> # Number of realizations 
> n = 30 
> 
> # Simulate rolls with a fair dice 
> xFair = np.random.choice(range(1, 7), size=n, replace=True) 
> 
> # Calculate the sample mean 
> xFair.sum()/n np.float64(3.3333333333333335) 
> 
> # or xFair.mean() 
> np.float64(3.3333333333333335)
> ```
> 
> ### **Unfair Dice**
> ``` python
> # Simulate an unfair dice 
> # n realizations 
> probs = [1/7, 1/7, 1/7, 1/7, 1/7, 2/7] # Higher probability for a six 
>
> xUnfair = np.random.choice(range(1, 7), size=n, replace=True, p=probs) 
> 
> # Calculate the sample mean
> xUnfair.mean() 
> np.float64(4.166666666666667)
> ```

****
### Variance and standard deviation
The second most used population parameter is the variance (or standard deviation). It is a measure describing the spread of the distribution, more specifically the spread away from the mean.

>[!defintion]+ Variance
>![[Pasted image 20250604133547.png|600]]

>[!warning]
>Notice that the variance cannot be negative.

>[!example]
>![[Pasted image 20250604133628.png|600]]

>[!example]+ Simulate and estimate the variance
>
>Return to the simulations. First calculate the sample variance from n rolls of a fair dice
>
>``` python
># Simulate a fair dice and calculate the sample variance 
># Number of realizations 
>n = 30 
>
># Simulate 
>xFair = np.random.choice(range(1,7), size=n, replace=True) 
>
># Calculate the distance for each sample to the sample mean 
>distances = xFair - xFair.mean() 
>
># Calculate the average of the squared distances 
>sum(distances**2)/(n-1) 
>np.float64(2.791954022988505) 
>
># Or use the built in function xFair.var(ddof=1) 
>np.float64(2.7919540229885054)
>```
>
>Let us then try to play with variance in the dice example. Let us now consider a four-sided dice. The pdf is
>
>![[Pasted image 20250604133815.png]]
>
>Plot the pdf for both the six-sided dice and the four-sided dice
>
>``` python
># Plot the pdf of the six-sided dice and the four-sided dice 
>fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(8,4)) 
>ax1.bar(range(1, 7), [1/6] * 6, color=’red’) 
>ax2.bar(range(1, 5), [1/4] * 4, color=’blue’)
>```
>
>![[Pasted image 20250604133910.png|600]]
>
>``` python
># Calculate the means and variances of the dices 
># The means 
>muXSixsided = np.sum(np.array([1,2,3,4,5,6])*1/6) 
>muXFoursided = np.sum(np.array([1,2,3,4])*1/4) 
>
># The variances
>print(np.sum((np.array([1,2,3,4,5,6]) - muXSixsided)**2 * 1/6)) 2.916666666666667 
>print(np.sum((np.array([1,2,3,4]) - muXFoursided)**2 * 1/4)) 
>1.25
>```

****

## Discrete distributions

>[!note]
>![[Pasted image 20250604134406.png|600]]

### **Binomial distribution**

> [!definition]+ Binomial distribution
> ![[Pasted image 20250604134554.png|600]]

>[!definition]+ Mean and variance
>![[Pasted image 20250604134630.png|600]]


>[!example]+ Simulation with a binomial distribution
>
>The binomial distribution for 10 flips with a coin describe probabilities of getting x heads (or equivalently tails)
>
>``` python
># Simulate a binomial distributed experiment 
># Number of flips 
>nFlips = 10 
>
># The possible outcomes are (0,1,...,nFlips) 
>xSeq = list(range(0,nFlips)) 
>
># Use the binom.pmf() function which returns the pdf 
>pdfSeq = stats.binom.pmf(xSeq, nFlips, 0.5) 
>
># Plot the density 
>plt.bar(xSeq, pdfSeq, color=’black’, width=0.1)
>```
>
>![[Pasted image 20250604134754.png|600]]

> [!example]+ Simulate multiple successive dice rolls
> 
> In the previous examples successive rolls of a dice was simulated. If a random variable which counts the number of sixes obtained X six is defined, it follows a binomial distribution
> 
> ``` python
> # Simulate 30 successive dice rolls 
> Xfair = np.random.choice(range(1,7), size=30, replace=True) 
> 
> # Count the number sixes obtained 
> sum(Xfair==6) 
> np.int64(5) 
> 
> # This is equivalent to 
> stats.binom.rvs(n=30, p=1/6) 
> 
> 4
> ```

****
### **Hypergeometric distribution**

> [!definition]+ Hypergeometric distribution
> ![[Pasted image 20250604135109.png|600]]

> [!definition]+ Mean and variance
> ![[Pasted image 20250604135134.png|600]]

>[!example]+ Lottery probabilities using the hypergeometric distribution
>
>A lottery drawing is a good example where the hypergeometric distribution can be applied. The numbers from 1 to 90 are put in a bowl and randomly drawn without replacement (i.e. without putting back the number when it has been drawn). Say that you have the sheet with 8 numbers and want to calculate the probability of getting all 8 numbers in 25 draws.
>
>``` python
># The probability of getting x numbers of the sheet in 25 drawings 
># Number of successes in the population 
>a = 8 
>
># Size of the population 
>N = 90 
>
># Number of draws 
>n = 25 
>
># Plot the pdf, note: parameters names are different in the python-function (here using:)
>plt.bar(np.arange(0,9), stats.hypergeom.pmf(np.arange(0,9), N, a, n), color=’black’, white...)
>```
>
>![[Pasted image 20250604135256.png|600]]

****
### **Poisson distribution**

The Poisson distribution describes the probability of a given number of events occurring in a fixed interval if these events occur with a known average rate and independently of the distance to the last event. Often it is events in a time interval, but can as well be counts in other intervals, e.g. of distance, area or volume. In statistics the Poisson distribution is usually applied for analyzing for example counts of: arrivals, traffic, failures and breakdowns.

>[!definition]+ Poisson distribution
>![[Pasted image 20250604135412.png|600]]

>[!definition]+ Mean and variance
![[Pasted image 20250604135434.png|600]]

>[!example]
>![[Pasted image 20250604135453.png|600]]

>[!note]
>One important feature is that the rate can be scaled, such that probabilities of occurrences in other interval lengths can be calculated. Usually the rate is denoted with the interval length, for example the hourly rate is denoted as λ hour 
>
>and can be scaled to the minutely rate by
>
>**$λ minute = \frac{λ^{hour}}{60}$**
>
>such the probabilities of x events per minute can be calculated with the Poisson pdf with rate λ minute

>[!example]+ Rate Scaling
>
>You are enjoying a soccer match. Assuming that the scoring of goals per match in the league is Poisson distributed and on average 3.4 goals are scored per match. Calculate the probability that no goals will be scored while you leave the match for 10 minutes.
>
>Let **$λ^{90minutes} = 3.4$** be goals per match and scale this to the 10 minute rate by
>
>**$λ^{10 minutes} = \frac{λ^{90 minutes}}{9} = \frac{3.4}{9}$**
>
>![[Pasted image 20250604135801.png|600]]
>
>``` python
># Probability of no goals in 10 minutes 
># The Poisson pdf (using poisson.pmf() function) 
>stats.poisson.pmf(0, 3.4/9) 
>np.float64(0.6853827910309876)
>```

>[!example]+ Poisson distributed random variable
>
>Simulate a Poisson distributed random variable to see the Poisson distribution
>
>``` python
># Simulate a Poisson random variable 
># The mean rate of events per interval 
>lamb = 4 
>
># Number of realizations 
>n = 1000 
>
># Simulate 
>x = stats.poisson.rvs(lamb, size=n) 
>
># Plot the empirical pdf 
>values, counts = np.unique(x, return_counts=True) 
>plt.bar(values, counts/n, color=’black’, width=0.2, label=’Empirical pdf’) 
>
># Add the pdf to the plot 
>plt.bar(values, stats.poisson.pmf(values, lamb), color=’red’, width=0.05, label=’pdf’)
>plt.show()
>```
>
>![[Pasted image 20250604135950.png|600]]

>[!important]+ When to use the hypergeometric distribution:
>
>- **Sampling without replacement** — You pick items from a finite population, and **each draw affects the next** because you don't put the item back.
  >  
>- **Population is finite and divided into two groups** — For example:
>    
>    - Successes (like "defective items") = KKK
>        
>    - Failures (non-defective) = N−KN - KN−K  
>        where NNN is total population size.
>        
>- **You want the probability of drawing exactly kkk successes in nnn draws** (without replacement).

