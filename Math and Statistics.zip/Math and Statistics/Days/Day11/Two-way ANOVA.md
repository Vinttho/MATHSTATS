****
## **Data structure and model**

>[!info]
>![[Pasted image 20250620113145.png|600]]

>[!example]+ 8.19
>
>Lets assume that the data we used in the previous section was actually a result of a randomized block design and we could therefore write:
>
>![[Pasted image 20250620113230.png]]
>
>In this case we should of course keep track of the blocks as well as the treatments:
>
>``` python
>y = np.array([2.8, 3.6, 3.4, 2.3, 5.5, 6.3, 6.1, 5.7, 5.8, 8.3, 6.9, 6.1]) 
>treatm = pd.Categorical([1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3]) 
>block = pd.Categorical([1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4]) 
>
>D = pd.DataFrame({’y’: y, ’treatm’: treatm, ’block’: block})
>```
>
>Now we can calculate the parameter estimates ($\hat{µ}$ and $\hat{α_i}$ , and $\hat{β_j}$):
>
>``` python
>mu = np.mean(y) 
>alpha = D.groupby(’treatm’,observed=True)[’y’].mean() - mu 
>
>beta = D.groupby(’block’,observed=True)[’y’].mean() - mu 
>
>print(mu) 
>5.233333333333333 
>
>print(alpha) 
>treatm 
>1 -2.208333 
>2 0.666667 
>3 1.541667 
>
>Name: y, dtype: float64 
>
>print(beta) 
>block 
>1 -0.533333 
>2 0.833333 
>3 0.233333 
>4 -0.533333 
>
>Name: y, dtype: float64
>```
>
>so our estimates of the overall mean (µ) and αi remain the same while the estimated block effects are $\hat{β_1}$ = −0.53, $\hat{β_2}$ = 0.83, $\hat{β_3}$ = 0.23 and $\hat{β_4}$ = −0.53.

****
## **Decomposition of variability and the ANOVA table**
In the same way as we saw for the one-way ANOVA, there exists a decomposition of variation for the two-way ANOVA:

>[!theorem]+ 8.20 Variation decomposition
>
>![[Pasted image 20250620113732.png|600]]

![[Pasted image 20250620115151.png|600]]

>[!method]
>
>![[Pasted image 20250620115251.png|600]]
>
>![[Pasted image 20250620115300.png|600]]
>
>![[Pasted image 20250620115311.png|600]]
>
>![[Pasted image 20250620115320.png|600]]
>

>[!note]
>
>Note, how the SST and SS(Tr) are found exactly as in the one-way ANOVA. If one ignores the block-way of the table, the two-way data has exactly the same structure as one-way data (with the same number of observations in each group). Further, note how SS(Bl) corresponds to finding a “one-way SS(Tr)”, but on the other way of the table (and ignoring the treatment-way of the data table). So from a computational point of view, finding these three, that is, finding SST, SS(Tr) and SS(Bl) is done by known one-way methodology. And then the last one, SSE, could then be found from the decomposition theorem as
>
>$$SSE = SST − SS(Tr) − SS(Bl)$$

>[!example]+ 8.21
>
>Returning to the example we get (SST and SS(Tr) remain unchanged):
>
>``` python
>beta = beta.values 
>
># Converting to numpy array 
>SSBl = 3 * np.sum(beta**2) 
>SSE = SST - SSTr - SSBl 
>
>print(np.round([SST, SSE, SSTr, SSBl],3)) 
>[35.987 1.242 30.792 3.953]
>```
>

>[!info]
>Again, tests for treatment effects and block effects are done by comparing SS(Tr) or SS(Bl) with SSE:

>[!theorem]+ 8.22
>
>![[Pasted image 20250620114009.png|600]]

>[!example]+ 8.23
>
>Returning to our example we get:
>
>``` python
># Test statistics 
>Ftr = SSTr / (3-1) / ( SSE / ((3-1) * (4-1))) 
>Fbl = SSBl / (4-1) / ( SSE / ((3-1) * (4-1))) 
>
>print(Ftr, Fbl) 
>74.39597315436248 6.367785234899335 
>
># p-values 
>pv_tr = 1 - stats.f.cdf(Ftr, 3 - 1, (3 - 1) * (4 - 1)) 
>pv_bl = 1 - stats.f.cdf(Fbl, 4 - 1, (3 - 1) * (4 - 1)) 
>
>print(pv_tr, pv_bl) 
>5.823829718287765e-05 0.027048337827318747
>```
>
>or directly in Python:
>
>``` python
>fit = smf.ols(’y ~ treatm + block’, data=D).fit() 
>anova = sm.stats.anova_lm(fit) 
>
>print(anova)
>```
>![[Pasted image 20250620114142.png|600]]
>
>we see that the block effect is actually significant on a 5% confidence level, and also that the p-value for the treatment effect is changed (the evidence against H0,Tr is stronger) when we accounted for the block effect.

>[!table]+ Table
>
>| **Source of variation** | **Degrees of freedom**             | **Sums of squares**     | **Mean sums of squares**                             | **Test statistic \(F\)**                              | **\(p\)-value**             |
|-------------------------|------------------------------------|--------------------------|-------------------------------------------------------|--------------------------------------------------------|------------------------------|
| Treatment               | $$k - 1$$                          | $$SS(Tr)$$               | $$MS(Tr) = \frac{SS(Tr)}{k - 1}$$                      | $$F_{Tr} = \frac{MS(Tr)}{MSE}$$                         | $$P(F > F_{Tr})$$           |
| Block                   | $$l - 1$$                          | $$SS(Bl)$$               | $$MS(Bl) = \frac{SS(Bl)}{l - 1}$$                      | $$F_{Bl} = \frac{MS(Bl)}{MSE}$$                         | $$P(F > F_{Bl})$$           |
| Residual                | $$(l - 1)(k - 1)$$                 | $$SSE$$                  | $$MSE = \frac{SSE}{(k - 1)(l - 1)}$$                   |                                                        |                              |
| Total                   | $$n - 1$$                          | $$SST$$                  |                                                       |                                                        |                              |

****
## **Post hoc comparisons**

>[!info]
>
>The post hoc investigation is done following the same approach and principles as for one-way ANOVA with the following differences: 
>- 1. Use the MSE and/or SSE from the two-way analysis instead of the MSE and/or SSE from the one-way analysis 
>- 2. Use (l − 1)(k − 1) instead of n − k as degrees of freedom and as denominator for SSE 
>  
>With these changes the Method boxes 8.9 and 8.10 and the Remark 8.13 can be used for post hoc investigation of treatment differences in a two-way ANOVA.

>[!method]
>![[Pasted image 20250620120200.png|600]]

>[!example]+ 8.24
>
>Returning to our small example we now find the pairwise treatment confidence intervals within the two-way analysis. If the comparison of A and B was specifically planned before the experiment was carried out, we would find the 95%-confidence interval as:
>
>``` python
>print(muis[0] - muis[1] + np.array([-1,1]) * stats.t.ppf(0.975, (4-1)*(3-1)) * np.sqrt(SSE/((4-1) * (3-1))*(1/4 + 1/4)))
>
[-3.662 -2.088]
>```
>
>and we can hence also conclude that treatment A is different from B. The p-value supporting this claim is found as:
>
>``` python
>tobs = (muis[0] - muis[1]) / np.sqrt(SSE/6 * (1/4 + 1/4)) 
>
>print(2 * (1 - stats.t.cdf(abs(tobs), 6))) 
>
>0.0001094734143394227
>```
>
>If we do all three possible comparisons, M = 3 · 2/2 = 3, and we will use an overall α = 0.05, we do the above three times, but using each time αBonferroni = 0.05/3 = 0.017:
>
>``` python
>alpha = alpha.values 
>alpha_bonf = 0.05 / 3 
>
># A vs. B p
>rint(alpha[0] - alpha[1] + np.array([-1, 1]) * stats.t.ppf(1 - alpha_bonf/2, 6) * np.sqrt(SSE/6 * (1/4 + 1/4)))
>
>[-3.932 -1.818] 
>
># A vs. C 
>print(alpha[0] - alpha[2] + np.array([-1, 1]) * stats.t.ppf(1 - alpha_bonf/2, 6) * np.sqrt(SSE/6 * (1/4 + 1/4))) 
>
>[-4.807 -2.693] 
>
># B vs. C 
>
>print(alpha[1] - alpha[2] + np.array([-1, 1]) * stats.t.ppf(1 - alpha_bonf/2, 6) * np.sqrt(SSE/6 * (1/4 + 1/4))) 
>
>[-1.932 0.182]
>```
>
>and we conclude that treatment A is different from B and C, while we cannot reject that B and C are equal. The p-values for the last two comparisons could also be found, but we skip that.

****
## **Model control**

>[!info]
>Also model control runs almost exactly the same way for two-way ANOVA as for one-way: 
>
>- Use a q-q plot on residuals to check for the normality assumption 
>- Check variance homegenity by categorized box plots 
>
>The only difference is that the box plotting to investigate variance homogeneity should be done on the residuals - NOT on the actual data. And that we can investigate both potential treatment heterogeneity as block heterogeneity.

>[!example]+ 8.25
>
>First the residual normality plot:
>
>``` python
>sm.qqplot(fit.resid.values, line=’q’, a=1/2) 
>plt.tight_layout() 
>plt.show()
>```
>
>![[Pasted image 20250620115052.png|600]]
>
>Then the investigation of variance homogeneity:
>
>``` python
>D[’residuals’] = fit.resid.values 
>
># Add residuals to DataFrame 
>fig, ax = plt.subplots(ncols=2) 
>D.boxplot(column=’residuals’, by=’treatm’, ax=ax[0], grid=False) 
>
>ax[0].set_title(’Residuals by treatment’) 
>D.boxplot(column=’residuals’, by=’block’, ax=ax[1], grid=False,) 
>ax[1].set_title(’Residuals by block’) 
>
>plt.suptitle(’’) 
>plt.tight_layout() 
>plt.show()
>```
>
>![[Pasted image 20250620115428.png|600]]
>
>Actually, if we’ve had data with a higher number of observations for each block, we might have had a problem here as blocks 2 and 3 appears to be quite different on their variability, however since there are very few observations (3 in each block) it is not unlikely to get this difference in variance when there is no difference (but again: it is not very easy to know, exactly where the limit is between what is OK and what is not OK in a situation like this. It is important information to present and take into the evaluation of the results, and in the process of drawing conclusions).

****
## **A complete worked through example: Car tires**

>[!example]+ 8.26 Car tires
>
>In a study of 3 different types of **tires (“treatment”)** effect on the fuel economy, drives of 1000 km in 4 different **cars ("blocks")** were carried out. The results are listed in the following table in km/l.
>
>![[Pasted image 20250620115547.png|600]]
>
>Let us analyse these data with a two-way ANOVA model, but first some explorative plotting:
>
>``` python
># Collecting the data in a data frame 
>D = pd.DataFrame({ ’y’: [22.5, 24.3, 24.9, 22.4, 21.5, 21.3, 23.9, 18.4, 22.2, 21.9, 21.7, 17.9], ’car’: pd.Categorical([1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4]), ’tire’: pd.Categorical([1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3]), }) 
>
>fig, ax = plt.subplots(ncols=2) 
>D.boxplot(column=’y’, by=’tire’, ax=ax[0],grid=False) 
>ax[0].set_title(’Boxplots by tire’) 
>D.boxplot(column=’y’, by=’car’, ax=ax[1],grid=False) 
>ax[1].set_title(’Boxplots by car’) 
>
>plt.suptitle(’’) 
>plt.tight_layout() 
>plt.show()
>```
>
>![[Pasted image 20250620115652.png|600]]
>
>**Then the actual two-way ANOVA:**
>
>``` python
>fit = smf.ols(’y ~ car + tire’, data=D).fit() 
>anova = sm.stats.anova_lm(fit) 
>print(anova)
>```
>![[Pasted image 20250620115735.png|600]]
>
>Conclusion: Tires (treatments) are significantly different and Cars (blocks) are significantly different. And the model control (for the conclusions to be validated). First the residual normality plot:
>
>``` python
>sm.qqplot(fit.resid.values, line=’q’, a=1/2) 
>plt.tight_layout() 
>plt.show()
>```
>![[Pasted image 20250620115826.png|600]]
>
>Then the investigation of variance homogeneity:
>
>``` python
>D[’residuals’] = fit.resid.values 
>
># Add residuals to DataFrame 
>fig, ax = plt.subplots(ncols=2) 
>D.boxplot(column=’residuals’, by=’car’, ax=ax[0],grid=False) 
>ax[0].set_title(’Residuals by car’) 
>D.boxplot(column=’residuals’, by=’tire’, ax=ax[1],grid=False) 
>ax[1].set_title(’Residuals by tire’) 
>
>plt.suptitle(’’) 
>plt.tight_layout() 
>plt.show()
>```
>![[Pasted image 20250620115916.png|600]]
>
>It seems like the variance for Car 2 and Car 3 is difference, however, as in the previous example, there are very few observations (only 3) for each car, hence this difference in variation is not unlikely if there is no difference. Thus we find that there do not see any important deviations from the model assumptions. Finally, the post hoc analysis, first the treatment means:
>
>``` python
>print(D.groupby(’tire’,observed=True)[’y’].mean()) 
>
>tire 
>1 23.525 
>2 21.275 
>3 20.925 
>
>Name: y, dtype: float64
>```
>
>We can find the 0.05/3 (Bonferroni-corrected) LSD-value from the two-way version of Remark 8.13:
>
>``` python
>print(D.groupby(’tire’,observed=True)[’y’].mean()) 
>
>tire 
>LSD_bonf = stats.t.ppf(1-0.05/6, 6) * np.sqrt(2*1.19/4) 
>print(LSD_bonf) 
>
>2.5358194018640283
>```
>
>So tires are significantly different from each other if they differ by more than 2.54. A convenient way to collect the information about the 3 comparisons is by ordering the means from smallest to largest and then using the so-called compact letter display:
>
>![[Pasted image 20250620120031.png]]
>
>There is no significant difference between mean of Tire 2 and 3, and no significant difference between mean of 2 and 1, but there is significant difference between mean of 1 and 3.

****
****
# **Perspective:**

***We’ve seen that ANOVA, both one-way and two-way, can be performed in R using the `lm` function, which we also used for linear regression. That’s because ANOVA models are actually a type of linear model, and can be treated using the same theory and matrix notation as multiple linear regression.***

***This is useful when we move to more complex situations, such as combining categorical factors and continuous variables (covariates) in the same model. For example, a two-way ANOVA with all combinations of two factors (like 5 levels of A and 3 of B) and multiple observations per group is called a two-way ANOVA with replication. In contrast, when there is only one observation per combination, as in a randomized block design, it’s without replication.***

***As models grow more complex — with more than two factors, blocking, and covariates — we may use mixed models, which handle both fixed effects (like treatments) and random effects (like repeated measurements or nested structures across farms or regions). These are known as hierarchical or multilevel models.***

**LSD:**
**When you want to find out which specific group means differ significantly from each other.**