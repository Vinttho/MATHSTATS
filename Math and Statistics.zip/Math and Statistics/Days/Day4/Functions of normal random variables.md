
## **The t-distribution**

>[!info]
>
>The **t-distribution** is the **sampling distribution** of the **sample mean**, **standardized** with the **sample variation**. 
>It is valid for all sample sizes, however if sample is bigger than 30 (**n>30**) the difference between the **t-distribution** and the normal distribution is very small.

>[!definition]
>
>![[Pasted image 20250611084133.png|600]]

The relation between normal random variables and **χ 2** -distributed random variables are given in the following theorem:

>[!definition]+ Theorem
>Let $Z~N(0,1)$ and $Y~X^2(v)$ then
>$$X=\frac{Z}{\sqrt{Y/v}} ~ t(v)$$

>[!example]+ Relation between normal and $X^2$
>
>``` python
># Set simulate parameters 
>nu = 8; 
>k = 200 
>
># Generate the simulated realizations 
>z = stats.norm.rvs(size=k) 
>y = stats.chi2.rvs(size=k, df=nu) 
>x = z/np.sqrt(y/nu) 
>
># Plot 
>fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(8,4)) 
>ax1.hist(x, density=True, label=’epdf’) 
>ax1.plot(range(-4,5), stats.t.pdf(range(-4,5), df=nu), color="red", label=’pdf’) stats.ecdf(x).cdf.plot(ax2, label=’ecdf’, linewidth=3) 
>ax2.plot(range(-4,5), stats.t.cdf(range(-4,5), df=nu), color="red", label=’cdf’)
>```
>
>![[Pasted image 20250611084454.png|600]]

>[!info]
>
>The t-distribution arises when a sample is taken of a normal distributed random variable, then the sample mean standardized with the sample variance follows the t-distribution.

>[!definition]+ Theorem
>
>![[Pasted image 20250611085412.png|600]]

>[!example]+ Simulation of t-distribution
>
>``` python
># Simulate 
>n = 8; 
>k = 200; 
>mu = 1.0; 
>sigma = 2.0 
>
># Repeat k times the simulation of a normal dist. sample: 
># return the values in a (n x k) matrix 
>x = [stats.norm.rvs(loc=mu, scale=sigma, size=n) for _ in range(k)] 
>x = np.array(x) xbar = np.array([np.mean(i) for i in x]) 
>s = np.array([np.std(i) for i in x]) 
>tobs = (xbar - mu)/(s/np.sqrt(n)) 
>
># Plot fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(8,4)) 
>ax1.hist(tobs, density=True, label=’epdf’) 
>ax1.plot(np.arange(-4,4.01,0.01), stats.t.pdf(np.arange(-4,4.01,0.01), df=nu), color="red")
>stats.ecdf(tobs).cdf.plot(ax2, label=’ecdf’, linewidth=3)
>```
>
>![[Pasted image 20250611085626.png|600]]

>[!note]
>Imagine you want to know something about a large group (called the _population_), like the average height of people in a city. But you don’t measure everyone — you take a small _sample_, like 5 or 10 people, and use their heights to guess the average and spread (standard deviation) of the whole city.
>Now:
>
>- **X̄ (the sample mean)** is the average from your small group.
>- **S (the sample standard deviation)** measures how spread out the numbers in your small group are.
>	  
>Even though you haven’t taken your sample yet, we treat **X̄** and **S** as _random variables_ — they could change depending on which people you pick.
>
>When your sample is **small**, and you assume that the heights (or whatever you're measuring) follow a _normal distribution_, we use something called the **t-distribution**. This helps us figure out how likely it is that the average you get (X̄) falls within a certain range of the true average (µ).
>
>The t-distribution is kind of like the normal distribution but adjusted to handle the extra uncertainty that comes from working with a small sample.
>
>Here’s your note turned into clear bullet points:

>[!example]+ Electric car driving distance
>
>An electric car manufacture claims that their cars can drive on average **400** km on a full charge at a specified speed. From experience it is known that this full charge distance, denote it by **X**, is normal distributed. A test of **n = 10** cars was carried out, which resulted in a sample mean of **x¯** = **382** km and a sample deviation of **s = 14**. Now we can use the t-distribution to calculate the probability of obtaining this value of the sample mean or lower, if their claim about the mean is actually true:
>
>``` python
># Calculate the probability of getting the sample mean under the 
># conditions that the claim is actually the real mean 
># A test of 10 cars was carried out 
>n = 10 
>
># The claim is that the real mean is 400 km 
>muX = 400 
>
># From the sample the sample mean was calculated to 
>xMean = 393 
>
># And the sample deviation was 
>xSD = 14 
>
># Use the cdf to calculate the probability of obtaining this 
># sample mean or a lower value 
>stats.t.cdf((xMean-muX)/(xSD/np.sqrt(n)), df=n-1, loc=0, scale=1) np.float64(0.0741523536832797)
>```

>[!info]
>The t-distribution converges to the normal distribution as the simple size increases. For small sample sizes it has a higher spread than the normal distribution. For larger sample sizes with n > 30 observations the difference between the normal and the t-distribution is very small.

>[!example]+ t-distribution
>
>Generate plots to see how the t-distribution is shaped compared to the normal distribution.
>
>``` python
># Plot the t-distribution for different sample sizes 
># First plot the standard normal distribution 
>x = np.arange(-5,5,0.1) 
>plt.plot(stats.norm.pdf(x, loc=0, scale=1), label=’Norm’) 
>
># Add the t-distribution for 30 observations 
>plt.plot(stats.t.pdf(x, df=30-1, loc=0, scale=1), label=’n=30’) 
>
># Add the t-distribution for 15, 5 and 2 observations 
>plt.plot(stats.t.pdf(x, df=15-1, loc=0, scale=1), label=’n=15’) 
>plt.plot(stats.t.pdf(x, df=5-1, loc=0, scale=1), label=’n=5’) 
>plt.plot(stats.t.pdf(x, df=2-1, loc=0, scale=1), label=’n=2’) 
>
># Add a legend 
>plt.legend() 
>plt.show()
>```
>
>![[Pasted image 20250611091024.png|600]]

>[!note]
![[21d5e091-0d66-4111-94fb-930613f28ba6.jpg|300]]

>[!definition]+ Theorem, Mean and variance
>
>Let $X ∼ t(ν)$ then the mean and variance of **X** is
>$$E(X)=0 ; v > 1$$
>$$V(X)=\frac{v}{v-2} ; v > 2$$

We will omit the proof of this theorem, but it is easily checked with a symbolic calculation software (like e.g. Maple).

****

## **The F-distribution**

>[!definition]+ F-Distribution
>
>The F-distribution pdf is:
>
>
>
>$$f_F(x) = \frac{1}{B(\frac{v_1}{2}, \frac{v_2}{2})} * (\frac{v_1}{v_2})^{\frac{v_1}{2}} * x^{\frac{v_1}{2}-1} * (1+\frac{v_1}{v_2}*x)^{-\frac{v_1+v_2}{2}}$$
>
>where **ν1** an **ν2** are the degrees of freedom and **B(·, ·)** is the Beta function

>[!definition]+ Theorem
>
>![[Pasted image 20250611091915.png|600]]

>[!example]+ F-distribution
>
>``` python
># Simulate 
>nu1 = 8; nu2 = 10; k = 200 
>u = stats.chi2.rvs(size=k, df=nu1) 
>v = stats.chi2.rvs(size=k, df=nu2) 
>fobs = (u/nu1) / (v/nu2) 
>fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(8,4)) 
>ax1.hist(fobs, density=True, label=’epdf’) 
>ax1.plot(np.arange(0,5.01,0.01), stats.f.pdf(np.arange(0,5.01,0.01), dfn=nu1, dfd=nu2),
>stats.ecdf(fobs).cdf.plot(ax2, label=’ecdf’, linewidth=3) ax2.plot(np.arange(0,5.01,0.01), stats.f.cdf(np.arange(0,5.01,0.01), dfn=nu1, dfd=nu2),
>```
>
>![[Pasted image 20250611092100.png|600]]

>[!theorem|icon=book] My theorem
>![[Pasted image 20250611093411.png|600]]

>[!example]+ Relation between normal and F-distribution
>
>``` python
># Simulate 
>n1 = 8; n2 = 10; k = 200 
>mu1 = 2; mu2 = -1 
>sigma1 = 2; sigma2 = 4 
>
>s1 = np.array([np.std(stats.norm.rvs(size=n1, loc=mu1, scale=sigma1)) for _ in range(k...
>s2 = np.array([np.std(stats.norm.rvs(size=n2, loc=mu2, scale=sigma2)) for _ in range(k...
>
>fobs = (s1**2 / sigma1**2) / (s2**2 / sigma2**2) 
>
># Plot 
>fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(8,4)) 
>ax1.hist(fobs, density=True, label=’epdf’) 
>ax1.plot(np.arange(0,6.01,0.01), stats.f.pdf(np.arange(0,6.01,0.01), dfn=nu1-1, dfd=nu2...
>stats.ecdf(fobs).cdf.plot(ax2, label=’ecdf’, linewidth=3) 
>ax2.plot(np.arange(0,6.01,0.01), stats.f.cdf(np.arange(0,6.01,0.01), dfn=nu1-1, dfd=nu2...
>```
>
>![[Pasted image 20250611093627.png|600]]

>[!theorem]+ Mean and variance
>
>![[Pasted image 20250611093645.png|600]]
